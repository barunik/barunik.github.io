# Makes the LaTeX guts of the table for the paper
# setwd("/Users/tomaskrehlik/Documents/PHD/Jump Realized GARCH/Skripty/")
# In-sample fits
library(parallel)
library(jumprGARCH)
library(xts)

file_name = "RV_estimates_BP_W.csv"
data <- read_in_and_standardize_data(file_name)
j_indeces <- c("BPV", "MedRV", "JWTSRV")

out_n <- t(get_table_n(data[,"Logreturn"], data[,"RV5min"]))
out_t <- sapply(j_indeces, function(i) get_table_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_t <- sapply(j_indeces, function(i) get_table_MLE_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_n <- t(get_table_MLE_n(data[,"Logreturn"], data[,"RV5min"]))

table_BP_mle <- cbind(out_mle_t, RV5min = c(out_mle_n[1:(length(out_mle_n)-2)],NA,NA, out_mle_n[(length(out_mle_n)-1):length(out_mle_n)]))
table_BP_gas <- cbind(out_t, RV5min = c(out_n[1:(length(out_n)-2)],NA,NA, out_n[(length(out_n)-1):length(out_n)]))[-c(9,10),]
rownames(table_BP_gas) <- rownames(table_BP_mle)

table_mltpl_BP <- fit_rGARCH_multiple(data[,"Logreturn"], data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")])
errs_BP <- sqrt(diag(solve(table_mltpl_BP$output$hessian)))

out_GARCH_BP <- fit_GARCH_MLE_n(data[,"Logreturn"])
errs_GARCH_BP <- sqrt(diag(solve(out_GARCH_BP$output$hessian)))
names(errs_GARCH_BP) <- names(out_GARCH_BP$optim_vals)

output <- ""
output <- paste(output, "\\multirow{22}{*}{British pound} & ", sep = "")
for (i in c("ω", "β", "γ", "jumppar")) {
	output <- paste(output, i, sep = "")

	# GARCH(1,1)

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_BP$optim_vals[i]), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_BP$optim_vals[2]), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_BP_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_BP_mle[i,j]), " ", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_BP_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_BP_gas[i,j]), " ", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			output <- paste(output, paste(" ",sprintf("%.3f", table_mltpl_BP$optim_vals[j]), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_BP$optim_vals[i]), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_BP[i]), ")", sep=""), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_BP[2]), ")", sep=""), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_BP_mle)==i)
		if (is.na(table_BP_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_BP_mle[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_BP_gas)==i)
		if (is.na(table_BP_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_BP_gas[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			z <- which(names(table_mltpl_BP$optim_vals) == j)
			output <- paste(output, paste(" ",paste("(",sprintf("%.3f", errs_BP[z]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		z <- which(names(table_mltpl_BP$optim_vals) == i)
		output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_BP[z]), ")", sep=""), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")
}

for (i in c("d1","d2")) {
	output <- paste(output, i, sep = "")

	output <- paste(output, " & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	if (is.na(table_BP_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste(" ",sprintf("%.3f", table_BP_mle[i,j]), " ", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_BP$optim_vals[i]), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	z <- which(rownames(table_BP_mle)==i)
	# 	if (is.na(table_BP_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste("(",sprintf("%.3f", table_BP_mle[1+z,j]), ")", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	z <- which(names(table_mltpl_BP$optim_vals) == i)
	output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_BP[z]), ")", sep=""), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & ", sep="")
}

mult <- matrix(rep(NA), ncol = 6, nrow = 8)
j <- 1
for (i in 1:4) {
	mult[j,] <- t(table_mltpl_BP$rv_params)[i,]
	j <- j+1
	mult[j,] <- matrix(errs_BP[(5+6):(length(errs_BP))], ncol = 6)[i,]
	j <- j+1
}
rownames(mult) <- zip(rownames(t(table_mltpl_BP$rv_params)), rep(" ", 4))
colnames(mult) <- colnames(t(table_mltpl_BP$rv_params))

fin <- cbind(table_BP_mle[1:8,c(4,1:3)], table_BP_gas[1:8,c(4,1:3)], mult)

for (i in 1:8) {
	output <- paste(output, rownames(fin)[i], sep = "")
	output <- paste(output, " & ", sep = "")
	for (j in 1:14) {
		if (i%%2==1) {
			output <- paste(output, paste(" ",sprintf("%.3f", fin[i,j]), " ", sep=""), sep=" & ")
		} else {
			output <- paste(output, paste(" ", paste("(",sprintf("%.3f", fin[i,j]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	}
	output <- paste(output, "\\\\ \n & ", sep="")
}

mltpl <- unlist(LogLik_multiple(table_mltpl_BP$output$par, data[,"Logreturn"], h1 = 3.682308, data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")], report = T))
fin <- cbind(table_BP_mle[17:18, c(4,1:3)], table_BP_gas[17:18, c(4,1:3)])

for (i in 1:2) {
	output <- paste(output, rownames(fin)[i], sep = "")
	if (i != 1) {
		output <- paste(output, paste(" ",sprintf("%.0f", -out_GARCH_BP$output$value), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "   ", sep=" & ")
	}
	for (j in 1:ncol(fin)) {
		output <- paste(output, paste(" ",sprintf("%.0f", fin[i,j]), " ", sep=""), sep=" & ")
	}
	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.0f", mltpl[i]), "} ", sep=""), sep=" & ")
	output <- paste(output, "\\\\ \n & ", sep="")
}

output <- substr(output, 1, nchar(output)-2)
output <- paste(output, "\\midrule \n")

file_name = "RV_estimates_EUR_W.csv"
data <- read_in_and_standardize_data(file_name)
j_indeces <- c("BPV", "MedRV", "JWTSRV")

out_n <- t(get_table_n(data[,"Logreturn"], data[,"RV5min"]))
out_t <- sapply(j_indeces, function(i) get_table_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_t <- sapply(j_indeces, function(i) get_table_MLE_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_n <- t(get_table_MLE_n(data[,"Logreturn"], data[,"RV5min"]))

table_EUR_mle <- cbind(out_mle_t, RV5min = c(out_mle_n[1:(length(out_mle_n)-2)],NA,NA, out_mle_n[(length(out_mle_n)-1):length(out_mle_n)]))
table_EUR_gas <- cbind(out_t, RV5min = c(out_n[1:(length(out_n)-2)],NA,NA, out_n[(length(out_n)-1):length(out_n)]))[-c(9,10),]
rownames(table_EUR_gas) <- rownames(table_EUR_mle)

table_mltpl_EUR <- fit_rGARCH_multiple(data[,"Logreturn"], data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")])
errs_EUR <- sqrt(diag(solve(table_mltpl_EUR$output$hessian)))

out_GARCH_EUR <- fit_GARCH_MLE_n(data[,"Logreturn"])
errs_GARCH_EUR <- sqrt(diag(solve(out_GARCH_EUR$output$hessian)))
names(errs_GARCH_EUR) <- names(out_GARCH_EUR$optim_vals)

output <- paste(output, "\\multirow{22}{*}{Euro} & ", sep = "")
for (i in c("ω", "β", "γ", "jumppar")) {
	output <- paste(output, i, sep = "")

	# GARCH(1,1)

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_EUR$optim_vals[i]), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_EUR$optim_vals[2]), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_EUR_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_EUR_mle[i,j]), " ", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_EUR_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_EUR_gas[i,j]), " ", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			output <- paste(output, paste(" ",sprintf("%.3f", table_mltpl_EUR$optim_vals[j]), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_EUR$optim_vals[i]), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_EUR[i]), ")", sep=""), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_EUR[2]), ")", sep=""), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_EUR_mle)==i)
		if (is.na(table_EUR_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_EUR_mle[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_EUR_gas)==i)
		if (is.na(table_EUR_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_EUR_gas[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			z <- which(names(table_mltpl_EUR$optim_vals) == j)
			output <- paste(output, paste(" ",paste("(",sprintf("%.3f", errs_EUR[z]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		z <- which(names(table_mltpl_EUR$optim_vals) == i)
		output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_EUR[z]), ")", sep=""), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")
}

for (i in c("d1","d2")) {
	output <- paste(output, i, sep = "")

	output <- paste(output, " & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	if (is.na(table_EUR_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste(" ",sprintf("%.3f", table_EUR_mle[i,j]), " ", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_EUR$optim_vals[i]), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	z <- which(rownames(table_EUR_mle)==i)
	# 	if (is.na(table_EUR_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste("(",sprintf("%.3f", table_EUR_mle[1+z,j]), ")", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	z <- which(names(table_mltpl_EUR$optim_vals) == i)
	output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_EUR[z]), ")", sep=""), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & ", sep="")
}

mult <- matrix(rep(NA), ncol = 6, nrow = 8)
j <- 1
for (i in 1:4) {
	mult[j,] <- t(table_mltpl_EUR$rv_params)[i,]
	j <- j+1
	mult[j,] <- matrix(errs_EUR[(5+6):(length(errs_EUR))], ncol = 6)[i,]
	j <- j+1
}
rownames(mult) <- zip(rownames(t(table_mltpl_EUR$rv_params)), rep(" ", 4))
colnames(mult) <- colnames(t(table_mltpl_EUR$rv_params))

fin <- cbind(table_EUR_mle[1:8,c(4,1:3)], table_EUR_gas[1:8,c(4,1:3)], mult)

for (i in 1:8) {
	output <- paste(output, rownames(fin)[i], sep = "")
	output <- paste(output, " & ", sep = "")
	for (j in 1:14) {
		if (i%%2==1) {
			output <- paste(output, paste(" ",sprintf("%.3f", fin[i,j]), " ", sep=""), sep=" & ")
		} else {
			output <- paste(output, paste(" ", paste("(",sprintf("%.3f", fin[i,j]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	}
	output <- paste(output, "\\\\ \n & ", sep="")
}

mltpl <- unlist(LogLik_multiple(table_mltpl_EUR$output$par, data[,"Logreturn"], h1 = 3.682308, data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")], report = T))
fin <- cbind(table_EUR_mle[17:18,c(4,1:3)], table_EUR_gas[17:18,c(4,1:3)])

for (i in 1:2) {
	output <- paste(output, rownames(fin)[i], sep = "")
	if (i != 1) {
		output <- paste(output, paste(" ",sprintf("%.0f", -out_GARCH_EUR$output$value), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "   ", sep=" & ")
	}
	for (j in 1:ncol(fin)) {
		output <- paste(output, paste(" ",sprintf("%.0f", fin[i,j]), " ", sep=""), sep=" & ")
	}
	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.0f", mltpl[i]), "} ", sep=""), sep=" & ")
	output <- paste(output, "\\\\ \n & ", sep="")
}

output <- substr(output, 1, nchar(output)-2)
output <- paste(output, "\\midrule \n")

file_name = "RV_estimates_CHF_W.csv"
data <- read_in_and_standardize_data(file_name)
j_indeces <- c("BPV", "MedRV", "JWTSRV")

out_n <- t(get_table_n(data[,"Logreturn"], data[,"RV5min"]))
out_t <- sapply(j_indeces, function(i) get_table_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_t <- sapply(j_indeces, function(i) get_table_MLE_jump_n(data[,"Logreturn"], data[,i], data[,paste("JV", i, sep="")]))
out_mle_n <- t(get_table_MLE_n(data[,"Logreturn"], data[,"RV5min"]))

table_CHF_mle <- cbind(out_mle_t, RV5min = c(out_mle_n[1:(length(out_mle_n)-2)],NA,NA, out_mle_n[(length(out_mle_n)-1):length(out_mle_n)]))
table_CHF_gas <- cbind(out_t, RV5min = c(out_n[1:(length(out_n)-2)],NA,NA, out_n[(length(out_n)-1):length(out_n)]))[-c(9,10),]
rownames(table_CHF_gas) <- rownames(table_CHF_mle)

table_mltpl_CHF <- fit_rGARCH_multiple(data[,"Logreturn"], data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")])
errs_CHF <- sqrt(diag(solve(table_mltpl_CHF$output$hessian)))

out_GARCH_CHF <- fit_GARCH_MLE_n(data[,"Logreturn"])
errs_GARCH_CHF <- sqrt(diag(solve(out_GARCH_CHF$output$hessian)))
names(errs_GARCH_CHF) <- names(out_GARCH_CHF$optim_vals)

output <- paste(output, "\\multirow{22}{*}{Swiss franc} & ", sep = "")
for (i in c("ω", "β", "γ", "jumppar")) {
	output <- paste(output, i, sep = "")

	# GARCH(1,1)

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_CHF$optim_vals[i]), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ",sprintf("%.3f", out_GARCH_CHF$optim_vals[2]), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_CHF_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_CHF_mle[i,j]), " ", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		if (is.na(table_CHF_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste(" ",sprintf("%.3f", table_CHF_gas[i,j]), " ", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			output <- paste(output, paste(" ",sprintf("%.3f", table_mltpl_CHF$optim_vals[j]), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_CHF$optim_vals[i]), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")

	if (i %in% c("ω", "β")) {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_CHF[i]), ")", sep=""), " ", sep=""), sep=" & ")
	} else if (i == "γ") {
		output <- paste(output, paste(" ", paste("(",sprintf("%.3f", errs_GARCH_CHF[2]), ")", sep=""), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_CHF_mle)==i)
		if (is.na(table_CHF_mle[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_CHF_mle[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
		z <- which(rownames(table_CHF_gas)==i)
		if (is.na(table_CHF_gas[i,j])) {
			output <- paste(output, "       ", sep=" & ")
		} else {
			output <- paste(output, paste("(",sprintf("%.3f", table_CHF_gas[1+z,j]), ")", sep=""), sep=" & ")
		}
	}

	if (i == "γ") {
		for (j in c("γ_RV5min", "γ_JWTSRV_W1", "γ_JWTSRV_W2", "γ_JWTSRV_W3", "γ_JWTSRV_W4", "γ_JWTSRV_W5")) {
			z <- which(names(table_mltpl_CHF$optim_vals) == j)
			output <- paste(output, paste(" ",paste("(",sprintf("%.3f", errs_CHF[z]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	} else if (i %in% c("ω", "β")) {
		z <- which(names(table_mltpl_CHF$optim_vals) == i)
		output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_CHF[z]), ")", sep=""), "} ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "       ", sep=" & ")
	}

	output <- paste(output, "\\\\ \n & ", sep="")
}

for (i in c("d1","d2")) {
	output <- paste(output, i, sep = "")

	output <- paste(output, " & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	if (is.na(table_CHF_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste(" ",sprintf("%.3f", table_CHF_mle[i,j]), " ", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.3f", table_mltpl_CHF$optim_vals[i]), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & & ", sep="")

	# for (j in c("RV5min", "BPV", "MedRV", "JWTSRV")) {
	# 	z <- which(rownames(table_CHF_mle)==i)
	# 	if (is.na(table_CHF_mle[i,j])) {
	# 		output <- paste(output, "       ", sep=" & ")
	# 	} else {
	# 		output <- paste(output, paste("(",sprintf("%.3f", table_CHF_mle[1+z,j]), ")", sep=""), sep=" & ")
	# 	}
	# }

	output <- paste(output, " & & & & & & & & ", sep = "")

	z <- which(names(table_mltpl_CHF$optim_vals) == i)
	output <- paste(output, paste(" \\multicolumn{6}{c}{",paste("(",sprintf("%.3f", errs_CHF[z]), ")", sep=""), "} ", sep=""), sep=" & ")

	output <- paste(output, "\\\\ \n & ", sep="")
}

mult <- matrix(rep(NA), ncol = 6, nrow = 8)
j <- 1
for (i in 1:4) {
	mult[j,] <- t(table_mltpl_CHF$rv_params)[i,]
	j <- j+1
	mult[j,] <- matrix(errs_CHF[(5+6):(length(errs_CHF))], ncol = 6)[i,]
	j <- j+1
}
rownames(mult) <- zip(rownames(t(table_mltpl_CHF$rv_params)), rep(" ", 4))
colnames(mult) <- colnames(t(table_mltpl_CHF$rv_params))

fin <- cbind(table_CHF_mle[1:8,c(4,1:3)], table_CHF_gas[1:8,c(4,1:3)], mult)

for (i in 1:8) {
	output <- paste(output, rownames(fin)[i], sep = "")
	output <- paste(output, " & ", sep = "")
	for (j in 1:14) {
		if (i%%2==1) {
			output <- paste(output, paste(" ",sprintf("%.3f", fin[i,j]), " ", sep=""), sep=" & ")
		} else {
			output <- paste(output, paste(" ", paste("(",sprintf("%.3f", fin[i,j]), ")", sep=""), " ", sep=""), sep=" & ")
		}
	}
	output <- paste(output, "\\\\ \n & ", sep="")
}

mltpl <- unlist(LogLik_multiple(table_mltpl_CHF$output$par, data[,"Logreturn"], h1 = 3.682308, data[,c("RV5min", "JWTSRV_W1", "JWTSRV_W2", "JWTSRV_W3", "JWTSRV_W4", "JWTSRV_W5")], report = T))
fin <- cbind(table_CHF_mle[17:18,c(4,1:3)], table_CHF_gas[17:18,c(4,1:3)])

for (i in 1:2) {
	output <- paste(output, rownames(fin)[i], sep = "")
	if (i != 1) {
		output <- paste(output, paste(" ",sprintf("%.0f", -out_GARCH_CHF$output$value), " ", sep=""), sep=" & ")
	} else {
		output <- paste(output, "   ", sep=" & ")
	}
	for (j in 1:ncol(fin)) {
		output <- paste(output, paste(" ",sprintf("%.0f", fin[i,j]), " ", sep=""), sep=" & ")
	}
	output <- paste(output, paste(" \\multicolumn{6}{c}{",sprintf("%.0f", mltpl[i]), "} ", sep=""), sep=" & ")
	output <- paste(output, "\\\\ \n & ", sep="")
}

output <- substr(output, 1, nchar(output)-2)

cat(output)