grey=[0.6 0.6 0.6];
fig=figure(1000);
set (fig,'Position',[100 100 700 500],'Color',[1 1 1]) %
set (gca,'Layer','top','LineWidth',1.0) %;
set (gca,'FontSize',22,'fontweight','bold')

plot(dates,cdb,'k'); hold on;
h1=plot(dates,0.3304*ones(T,1),'k--'); hold on;
jbfill(dates',0.3582*ones(T,1)',0.3031*ones(T,1)',grey,grey,[],1); hold on;
set (gca,'Layer','bottom')
tmp=polyfit(dates(1:465),cdb(1:465),1);
yfit=polyval(tmp,dates(1:465)); 
plot(dates(1:465),yfit,'k','LineWidth',2);hold on;
tmp=polyfit(dates(523:end),cdb(523:end),1);
yfit=polyval(tmp,dates(523:end));
plot(dates(523:end),yfit,'k','LineWidth',2);hold on;
datetick('x')
hax=get(h1,'Parent')
set(hax,'Linewidth',3)
axis([dates(1) dates(end) 0.2 0.5])
legend('Normal-GAS','Constant CDB','90% CI')
title(['Conditional diversification benefits for DAX-PX (alpha=0.05)'])
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'Figures/CDB',pairs{pp},'.eps'],'psc2') %
