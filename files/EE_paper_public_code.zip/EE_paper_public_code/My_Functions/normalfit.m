function [params]=normalfit(data)
% Fit the normal distribution to data
% This form facilitates the working with parfor
% Krenar Avdulaj 12.02.2013
outNormalboot=fitdist(data,'normal'); % Normal dist.
[params]=outNormalboot.Params;