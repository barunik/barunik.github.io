function [data, rhot,ft] = bivnorm_tv_GAS_rnd(theta,T,rho0,RR,HESSnorm)
 
% Krenar Avdulaj 26 January 2013

 RBAR = 0.9999;  % can make this equal to 1, in theory, but issues occur very close to that boundary
    
    
    w = theta(1);
    a = theta(2);
    b = theta(3);
    
    h = 0.00001;  % step size to use when computing score

    % generating the time series of rho
    ft = nan(T,1);
    rhot = nan(T,1);
    data = nan(T,2);

    rhot(1) = rho0;
    ft(1) = log( (RBAR+rhot(1))/(RBAR-rhot(1)) );
    data(1,:) = normcdf(mvnrnd([0 0],[1 rhot(1);rhot(1) 1]));

for tt = 2:T
    
        %rhot(tt-1)
        It = interp1(RR,HESSnorm(:,1),rhot(tt-1));     % estimated hessian for rho. 
        % Values at intermediate points can be obtained by cubic spline interpolation or 
        % non-parametric kernel smoothing to ensure continuity of first and second 
        % derivatives of the likelihood function.
        DELTAt = (-NormalCopula_CLa(rhot(tt-1)+h,data(tt-1,:))--NormalCopula_CLa(rhot(tt-1),data(tt-1,:)))/h; % estimated score for rho. 
        % NOTE: NormalCopula_CL code returns the *neg* log-like, so need to undo that here

        
        drhodf = 2*RBAR*exp(-ft(tt-1))/((1+exp(-ft(tt-1)))^2);  % The derivative of: rho=(1 - Exp[-f])/(1 + Exp[-f]) wrt "f".
        Itildat = It / ( drhodf^2) ;                         % estimated hessian for f
        DELTAtildat = DELTAt / (  drhodf  );                    % estimated score for f
    
        Itildat = max(Itildat,1e-6);                            % imposing a min value here to stop the likelihood blowing up when Rho is very close to the boundary
        DELTAtildat = max(min(DELTAtildat,1e4),-1e4);           % imposing that this is inside (-1e6,1e6)

        ft(tt) = w + b*ft(tt-1) + a*DELTAtildat/sqrt(Itildat);
        
        ft(tt) = max(min(ft(tt),100),-100);                     % imposing that this is inside (-100,100)
        rhot(tt) = RBAR*(1-exp(-ft(tt)))/(1+exp(-ft(tt)));
        data(tt,:) = normcdf(mvnrnd([0 0],[1 rhot(tt);rhot(tt) 1]));

end

        

