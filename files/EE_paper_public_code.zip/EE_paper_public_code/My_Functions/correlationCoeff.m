function rho=correlationCoeff(f,a,b,c,d,varargin)
% Calculates the correlation based on double integration
[X1,w1]=lgwt(nodes,-1,1);
f=zeros(nodes);
nu=12.3;

for i=1:nodes
    for j=1:nodes
        A1=(X1(i)+1)*(b-a)/2+a;
        A2=(X1(j)+1)*(d-c)/2+c;
        if varargin==4
        f(i,j)=w1(i)*w1(j)*A1.*A2.*normpdf(A1,0,1).*normpdf(A2,nu).*NormalCopula_pdf(normcdf(A1),normcdf(A2),0.63);     
        else
        end
    end
end

Covariance=(b-a)*(d-c)/4*sum(sum(f));
rho=Covariance/sqrt(1*nu/(nu-2));