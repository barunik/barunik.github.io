function [CL, rhot,ft] = bivnorm_tv_GAS_CL(theta,data,rho0,RR,HESSnorm)

% I have adopted the code from Patton's t-GAS copula.
% Krenar Avdulaj 
% October 2012


 RBAR = 0.9999;  % can make this equal to 1, in theory, but issues occur very close to that boundary
if sum(isnan(theta))==0
    
    T = size(data,1);
    
    w = theta(1);
    a = theta(2);
    b = theta(3);
    
    h = 0.00001;  % step size to use when computing score

    % generating the time series of rho
    ft = nan(T,1);
    rhot = nan(T,1);
    rhot(1) = rho0;
    ft(1) = log( (RBAR+rhot(1))/(RBAR-rhot(1)) );
%     count = zeros(1,2);

    for tt = 2:T
    
        %rhot(tt-1)
        It = interp1(RR,HESSnorm(:,1),rhot(tt-1));     % estimated hessian for rho. 
        % Values at intermediate points can be obtained by cubic spline interpolation or 
        % non-parametric kernel smoothing to ensure continuity of first and second 
        % derivatives of the likelihood function.
        DELTAt = (-NormalCopulaCLa(rhot(tt-1)+h,data(tt-1,:))--NormalCopulaCLa(rhot(tt-1),data(tt-1,:)))/h; % estimated score for rho. 
        % NOTE: NormalCopula_CL code returns the *neg* log-like, so need to undo that here

        
        drhodf = 2*RBAR*exp(-ft(tt-1))/((1+exp(-ft(tt-1)))^2);  % The derivative of: rho=(1 - Exp[-f])/(1 + Exp[-f]) wrt "f".
        Itildat = It / ( drhodf^2) ;                         % estimated hessian for f
        DELTAtildat = DELTAt / (  drhodf  );                    % estimated score for f
    
        Itildat = max(Itildat,1e-6);                            % imposing a min value here to stop the likelihood blowing up when Rho is very close to the boundary
        DELTAtildat = max(min(DELTAtildat,1e4),-1e4);           % imposing that this is inside (-1e6,1e6)

        ft(tt) = w + b*ft(tt-1) + a*DELTAtildat/sqrt(Itildat);
        
        ft(tt) = max(min(ft(tt),100),-100);                     % imposing that this is inside (-100,100)
        rhot(tt) = RBAR*(1-exp(-ft(tt)))/(1+exp(-ft(tt)));
    end

        x = norminv(data(:,1));
        y = norminv(data(:,2));
        %bivariate normal likelihood
        CL = -1*(2*(1-rhot.^2)).^(-1).*(x.^2+y.^2-2*rhot.*x.*y);
        CL = CL + 0.5*(x.^2+y.^2);  
        CL = CL - 0.5*log(1-rhot.^2);
        CL = sum(CL);
        CL = -CL;
        
        if isnan(CL) || isinf(CL)
        CL = 1e8;
        end
        
else
        ft = nan(1,1);
        rhot = nan(1,1);
        CL = 1e7;
end
