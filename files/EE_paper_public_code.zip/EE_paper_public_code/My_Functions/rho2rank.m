function varargout=rho2rank(rho)
% Returns Kendall's tau ans Spearman's Rho for a certain value of linear 
% correlation rho for Normal Copula
% Krenar Avdulaj 19 Apr 2012

if any(abs(rho)>1)
    error('myApp:argChk', 'Correlation is not within bounds [-1 1]')
end

tau=2/pi*asin(rho); % Kendall's tau
rhoS=6/pi*asin(rho/2); % Spearmen's rho
%varargout=[tau rhoS];

if nargout==1 
    varargout(1)={tau};
elseif nargout==2
    varargout(1:2)={tau rhoS};
elseif nargout>2
    error('myApp:argChk', 'Big number of output arguments')
else
       varargout(1)={tau}; 
end

