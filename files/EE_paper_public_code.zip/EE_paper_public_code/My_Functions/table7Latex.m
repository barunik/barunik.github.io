function table7Latex(data,tabName,caption,label,prs)
    % This is a custom made function for constant copula parameters
    % Krenar Avdulaj 21 Feb 2013
    fid=fopen(tabName,'w');
    
    % LaTEX table header
    fprintf(fid,'%s \n', '\begin{table}');
    fprintf(fid,'%s \n','\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrr}\toprule');
    fprintf(fid,'%s ', '& \multicolumn{4}{c}{');
    fprintf(fid,'%s ',char(strcat({prs})));
    fprintf(fid,'%s \\\\ \n',char(strcat({'}'})));
    fprintf(fid,'%s \n','& \multicolumn{2}{c}{Parametric}& \multicolumn{2}{c}{Semiparametric}\\');
    fprintf(fid,'%s \n','\cmidrule{2-3} \cmidrule{4-5}');
    fprintf(fid,'%s \n','& Boot & Sim & Boot & Sim\\');
    fprintf(fid,'%s \n','\midrule');

    
    % Body of the table
%     fmt = '%10.4f';
%     fmt1 = '%10.2f';
    rnames = {'Normal-$\rho$','\emph{s.e.}','$\mathcal{\log L}$','Clayton-$\kappa$','\emph{s.e.}','$\mathcal{\log L}$','RotGumbel-$\kappa$','\emph{s.e.}','$\mathcal{\log L}$','Stud \emph{t}-$\rho$','\emph{s.e.}','Stud \emph{t}-$\nu^{-1}$','\emph{s.e.}','$\mathcal{\log L}$','SJC-$\tau^L$','\emph{s.e.}','SJC-$\tau^U$','\emph{s.e.}','$\mathcal{\log L}$'};
    
    for ROW=1:size(data,1)
            if strcmp(rnames{ROW},'\emph{s.e.}')
                fprintf(fid,'%s ',rnames{ROW});
                        for COL=1:size(data,2)
                            fprintf(fid,'& %3.4f ', data(ROW,COL)); 
                            if COL==size(data,2)
                            fprintf(fid,'%s \n', '\\');
                            else
                            end
                        end
            else
                fprintf(fid,'%s ',rnames{ROW});
                        %for COL=1:size(data,2)

                        fprintf(fid,'%s ',char(strcat({'&\multicolumn{2}{c}{'})));
                            if strcmp(rnames{ROW},'$\mathcal{\log L}$') % change number format for LL
                                fprintf(fid,'%s ',char(strcat({'\textbf{'}))); % bold LL value
                                fprintf(fid,' %10.2f ', data(ROW,1));
                                fprintf(fid,'%s ',char(strcat({'}'})));
                            else
                                fprintf(fid,' %3.4f ', data(ROW,1)); 
                            end
                        fprintf(fid,'%s ',char(strcat({'}'})));

                        fprintf(fid,'%s ',char(strcat({'&\multicolumn{2}{c}{'})));
                            if strcmp(rnames{ROW},'$\mathcal{\log L}$') % change number format for LL
                                fprintf(fid,'%s ',char(strcat({'\textbf{'}))); % bold LL value
                                fprintf(fid,' %10.2f ', data(ROW,3));
                                fprintf(fid,'%s ',char(strcat({'}'}))); 
                            else
                                fprintf(fid,' %3.4f ', data(ROW,3)); 
                            end
                        fprintf(fid,'%s \n',char(strcat({'}\\'})));
                        %end

            end
        
        
    end
    
    % LaTEX table footer
    fprintf(fid,'%s \n', '  \bottomrule ');
    fprintf(fid,'%s \n','\end{tabular*}  ');
    fprintf(fid,'%s ', '\caption{');
    fprintf(fid,'%s',char(strcat({caption})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s ', '\label{tab:');
    fprintf(fid,'%s',char(strcat({label})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s \n','\end{table}');
    fclose(fid);
    