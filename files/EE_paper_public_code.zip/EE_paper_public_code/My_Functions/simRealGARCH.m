function [ehat, xt] = simRealGARCH(T,ARparams,realGARCHparams,sigmau,varRet,zt)
%function [KSstats CvMstats] = dist_test_PEE(T,reps,ARparams,GARCHparams,SKEWTparams);
%
%  INPUTS:  T, a scalar, the sample size
%           reps, a scalar, the number of replications to use
%           ARparams, a p+1 x 1 vector, [phi0,phi1,...phiP] the AR(p) parameters for the mean
%           realGARCHparams, a 7x1 vector, [w,b,g,xi,phi,tau1,tau2] the parameters of the realGARCH model for the variance
%  OUTPUTS: ehat, returns series
%                   xt, realized volatility

    ARp = length(ARparams)-1; 
    mu = nan(T,1);
    rt = nan(T,1);
    et = nan(T,1);
    loght=nan(T,1);
    logxt=nan(T,1);
    ustd=normrnd(0,1,[T 1]);
    ut=ustd*sigmau; % because the assumption of the model is: (ut/sigma_u)~ iid N(0,1) p.884 Hansen's paper.
    loght0=log(varRet); % start at unconditional variance.
    
    omega=realGARCHparams(1);
    bet=realGARCHparams(2);
    gam=realGARCHparams(3);
    xi=realGARCHparams(4);
    phi=realGARCHparams(5);
    tau1=realGARCHparams(6);
    tau2=realGARCHparams(7);
    
    % starting values for series
    if ARp>0
        mu(1) = ARparams(1)/(1-sum(ARparams(2:end)));
    else
        mu(1) = ARparams(1);
    end
    
    if ~(isempty(realGARCHparams) && isempty(GARCHstartvals)) % it these 2 fields are empty then constant mean
        
        logxt(1)=xi+phi*loght0+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1); % log of the 1st element of RV. Given from the data.
        %loght(1)=log(GARCHstartvals(1));
        loght(1) =omega+bet*loght0+gam*logxt(1); %omega+gam*logxt(1))/(1-bet); %log((gam*xi*(1+phi*gam))/(1-phi^2*gam-bet*(1+phi^2*gam+phi*gam)));
        et(1) = sqrt(exp(loght(1)))*zt(1);
        %logxt(1)=xi+phi*loght(1)+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1);
        %logxt(1)= xi+phi*loght(1)+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1);%log(GARCHstartvals(2));
        rt(1) = mu(1) + et(1);

        % looping through rest of series
        for tt=2:T;
            loght(tt) = omega + bet*loght(tt-1) + gam*logxt(tt-1);
            et(tt) = sqrt(exp(loght(tt)))*zt(tt);
            logxt(tt)=xi+phi*loght(tt)+tau1*zt(tt)+tau2*(zt(tt)^2-1)+ut(tt);

            if tt<=ARp
                mu(tt) = mu(1);  % using unconditional mean for first ARp obs of conditional mean
            else
                mu(tt) = ARparams(1);
                if ARp>0
                    mu(tt) = mu(tt) + ARparams(2:end)'*rt(tt-1:-1:tt-ARp);
                end
            end
            rt(tt) = mu(tt) + et(tt);
        end
        xt=exp(logxt); % realized volatility
        % estimating mean model
        temp = ols(rt(ARp+1:end),[ones(T-ARp,1),mlag(rt(ARp+1:end),ARp,mu(1))]);
        ehat = [zeros(ARp,1);temp.resid]; % zero mean returns
        ehat=ehat/std(ehat);
    end
    
   
    