function [LL,muhat,hhat,uhat] = skewtdis_ARMA_RealGARCH_LL(theta,data,ARp,MAq,archP,garchQ);
% function skewtdis_ARMA_GJRGARCH_LL(theta,ar,ma,arch,tarch,garch,data);
%
%  Function to return the log-likelihood of the standardized residuals from
%  an ARMA-GJRGARCH model with Hansen's skew t residuals. 
%
%  This function is used to construct standard errors for the skew t dis parameters,
%  controlling for the estimation error from the mean and vol estimation
%
%  INPUTS:  theta, a 1+ARp+MAq+archP+garchQ+2 vector, containing all parameters
%           data, a Tx1 vector, the data
%           ARp, a scalar, the order of the AR part
%           MAq, a scalar, the order of the MA part
%           archP, a scalar, the order of the ARCH part
%           garchQ, a scalar, the order of the GARCH part
%
% OUTPUTS:  LL, the negative log-likelihood of this model
%           muhat, a Tx1 vector, the fitted conditional mean
%           hhat, a Tx1 vector, the fitted conditional variance
%           uhat, a Tx1 vector, the estimated prob integral transforms (needs to be FOURTH output to work in two-stage std error code)


theta1 = theta(1:1+ARp+MAq); % ARMA parameters
theta2 = theta(1+ARp+MAq+ 1:1+ARp+MAq+ 1+archP+garchQ); % cond. variance eq. parameters
%theta3 = theta(1+ARp+MAq+ 1+archP+garchQ+1:1+ARp+MAq+ 1+archP+garchQ+1+rvparam); % RV eq. parameters. In fact I do not need this.
theta4 = theta(end-1:end);
rvdata=data(:,2); % realized volatility

muhat = ARMA_mean(theta1,ARp,MAq,data(:,1));
resids = data(:,1) - muhat;
hhat = RealGARCH_vol(theta2,[resids rvdata]);
stdresids = resids./sqrt(hhat);

LL = skewtdis_LL(theta4, stdresids);

if nargout>3
    uhat = skewtdis_cdf(stdresids,theta4(1),theta4(2));
end

%% Helper function. Caclulates the 
function hhat=RealGARCH_vol(theta,data)
% data(:,1)=> zero mean returns
% data(:,2)=> realized measure of volatility
T = size(data,1);

logrvdata=log(data(:,2)/std(data(:,2))); % take the log
loghhat = nan(T,1);
loghhat(1)=log(var(data(:,1))); % start at unconditional variance
for tt= 2:T;
    loghhat(tt) = theta(1) + theta(2)*loghhat(tt-1)+theta(3)*logrvdata(tt-1);
end

hhat = exp(loghhat);