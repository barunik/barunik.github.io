function [rhot,ft] = bivnorm_tv_GAS_CL_one_step(theta,lag_rho,lag_U,RR,HESSnorm)
 
% Function to compute the one-step ahead parameter of the GAS model for a normal coupla with time-varying rho (useful for OOS forecasting studies of this
% model, faster than having to call the likelihood and compute rhot for the whole time series)

% Krenar Avdulaj 03.02.2013

RBAR = 0.9999;  % can make this equal to 1, in theory, but issues occur very close to that boundary
        
w = theta(1);
a = theta(2);
b = theta(3);

h = 0.00001;  % step size to use when computing score

% generating the time series of rho
lag_f = log( (RBAR+lag_rho)/(RBAR-lag_rho) );  % used below.

%rhot(tt-1)
It = interp1(RR,HESSnorm(:,1),lag_rho);     % estimated hessian for rho. 
% Values at intermediate points can be obtained by cubic spline interpolation or 
% non-parametric kernel smoothing to ensure continuity of first and second 
% derivatives of the likelihood function.
DELTAt = (-NormalCopula_CLa(lag_rho+h,lag_U)--NormalCopula_CLa(lag_rho,lag_U))/h; % estimated score for rho. 
% NOTE: NormalCopula_CL code returns the *neg* log-like, so need to undo that here


drhodf = 2*RBAR*exp(-lag_f)/((1+exp(-lag_f))^2);  % The derivative of: rho=(1 - Exp[-f])/(1 + Exp[-f]) wrt "f".
Itildat = It / ( drhodf^2) ;                         % estimated hessian for f
DELTAtildat = DELTAt / (  drhodf  );                    % estimated score for f

Itildat = max(Itildat,1e-6);                            % imposing a min value here to stop the likelihood blowing up when Rho is very close to the boundary
DELTAtildat = max(min(DELTAtildat,1e4),-1e4);           % imposing that this is inside (-1e6,1e6)

ft = w + b*lag_f + a*DELTAtildat/sqrt(Itildat);

ft = max(min(ft,100),-100);                     % imposing that this is inside (-100,100)
rhot = RBAR*(1-exp(-ft))/(1+exp(-ft));

  