function [CL, rhohat] = bivnorm_tv_GAS_CL2(theta,Zdata,rhobar)
% GAS(1,1) Time-varying Normal copula. Follows "GAS" model for Creal, Koopman and Lucas (2011, JAE) Eq. (25) 
%
%       INPUTS: theta= time-varying copula parameters ;
%				data = [U V];
%				rhobar = parameter of the Normal copula without time-variation
%       OUTPUT: CL-the negative likelihood
%               rhohat-time-varying correlation
%
% Krenar Avdulaj 25.01.2013

RBAR = 0.9999;  % can make this equal to 1, in theory, but issues occur very close to that boundary

T = size(Zdata,1);
x = norminv(Zdata(:,1),0,1);
y = norminv(Zdata(:,2),0,1);

ft=nan(T,1);
rhot = -999.99*ones(T,1);
rhot(1)=rhobar;
ft(1)= log( (RBAR+rhot(1))/(RBAR-rhot(1)) );			% this is the MLE of kappa in the time-invariant version of this model
for jj = 2:T
     
   ft(jj) = theta(1) + theta(2)*2/(1-rhot(jj-1)^2)*(x(jj-1)*y(jj-1) -rhot(jj-1)*rhot(jj-1)*(x(jj-1)^2+y(jj-1)^2 -2)/(1+rhot(jj-1)^2)) + theta(3)*ft(jj-1);
   
   ft(jj) = max(min(ft(jj),100),-100);                     % imposing that this is inside (-100,100)
   rhot(jj) = 1.998/(1+exp(-ft(jj)))-0.999;		% a modified logistic transformation
end
rhohat = rhot;  % time-path of conditional copula parameter

CL = -1*(2*(1-rhot.^2)).^(-1).*(x.^2+y.^2-2*rhot.*x.*y);
CL = CL + 0.5*(x.^2+y.^2);  
CL = CL - 0.5*log(1-rhot.^2);
CL = sum(CL);
CL = -CL;


if isnan(CL) || isinf(CL)
        CL = 1e8;
end
