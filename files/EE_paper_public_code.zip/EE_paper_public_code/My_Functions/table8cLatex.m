function table8cLatex(data,tabName,caption,label,prs)
    % This is a custom made function for tv copula parameters
    % Krenar Avdulaj 21 Feb 2013
    fid=fopen(tabName,'w');
    
    % LaTEX table header
    fprintf(fid,'%s \n', '\begin{table}');
    fprintf(fid,'%s \n','\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrr}\toprule');
    fprintf(fid,'%s ', '& & \multicolumn{4}{c}{');
    fprintf(fid,'%s ',char(strcat({prs})));
    fprintf(fid,'%s \\\\ \n',char(strcat({'}'})));
    fprintf(fid,'%s \n','& & \multicolumn{2}{c}{Parametric}& \multicolumn{2}{c}{Semiparametric}\\');
    fprintf(fid,'%s \n','\cmidrule{3-4} \cmidrule{5-6}');
    fprintf(fid,'%s \n','& & Boot & Sim & Boot & Sim\\');
    fprintf(fid,'%s \n','\midrule');

    
    % Body of the table
%     fmt = '%10.4f';
%     fmt1 = '%10.2f';
    rnames = {'\multirow{7}{2mm}{Rot $Gumb_{GAS}$}&$\hat{\omega}$','& ','&$\hat{\alpha}$','& ',...
        '&$\hat{\beta}$','& ','&$\log\mathcal{L}$','\multirow{7}{2mm}{$Normal_{GAS}$}&$\hat{\omega}$',...
        '& ','&$\hat{\alpha}$','& ','&$\hat{\beta}$','& ','&$\log\mathcal{L}$','\multirow{9}{2mm}{Student $t_{GAS}$}&$\hat{\omega}$',...
        '& ','&$\hat{\alpha}$','& ','&$\hat{\beta}$','& ','&$\hat\nu^{-1}$','& ','&$\log\mathcal{L}$'};

    
    for ROW=1:size(data,1)
            if strcmp(rnames{ROW},'& ')
                fprintf(fid,'%s ',rnames{ROW});
                        for COL=1:size(data,2)
                            fprintf(fid,'& %3.4f ', data(ROW,COL)); 
                            if COL==size(data,2)
                            fprintf(fid,'%s \n', '\\');
                            else
                            end
                        end
            else
                fprintf(fid,'%s ',rnames{ROW});

                        fprintf(fid,'%s ',char(strcat({'&\multicolumn{2}{c}{'})));
                            if strcmp(rnames{ROW},'&$\log\mathcal{L}$') % change number format for LL
                                fprintf(fid,'%s ',char(strcat({'\textbf{'}))); % bold LL value
                                fprintf(fid,' %10.2f ', data(ROW,1)); 
                                fprintf(fid,'%s ',char(strcat({'}'})));
                            else
                                fprintf(fid,' %3.4f ', data(ROW,1)); 
                            end
                        fprintf(fid,'%s ',char(strcat({'}'})));

                        fprintf(fid,'%s ',char(strcat({'&\multicolumn{2}{c}{'})));
                            if strcmp(rnames{ROW},'&$\log\mathcal{L}$') % change number format for LL
                                fprintf(fid,'%s ',char(strcat({'\textbf{'}))); % bold LL value
                                fprintf(fid,' %10.2f ', data(ROW,3)); 
                                fprintf(fid,'%s ',char(strcat({'}'})));                            else
                                fprintf(fid,' %3.4f ', data(ROW,3)); 
                            end
                        fprintf(fid,'%s \n',char(strcat({'}\\'})));

            end
        
        
    end
    
    % LaTEX table footer
    fprintf(fid,'%s \n', '  \bottomrule ');
    fprintf(fid,'%s \n','\end{tabular*}  ');
    fprintf(fid,'%s ', '\caption{');
    fprintf(fid,'%s',char(strcat({caption})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s ', '\label{tab:');
    fprintf(fid,'%s',char(strcat({label})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s \n','\end{table}');
    fclose(fid);
    