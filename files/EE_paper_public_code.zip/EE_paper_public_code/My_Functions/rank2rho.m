function rho=rank2rho(rank,type)
% Converts the rank to linear correlation for Normal Copula. 
% rank: the rank correlation that will be converted
% type: determines the type of your rank i.e. either "kendall" or
% "spearman". The "type" argument is NOT case sensitive.
% Krenar Avdulaj 19 Apr 2012

if nargin < 2
error('myApp:argChk','Too few input arguments')
end

if any(abs(rank)>1)
    error('myApp:argChk', 'Correlation is not within bounds [-1 1]')
end

if ischar(type)
    types={'kendall','spearman'};
    i=strcmpi(type,types);
    if sum(i) > 1
        error('myapp:InvalidType', ...
              'Ambiguous rank type: ''%s''.',type);
    elseif sum(i) == 1
        type = types{i};
    else
        error('myApp:InvalidType', ...
              'Unrecognized rank type: ''%s''',type);
    end
    
else
    error('TYPE must be a rank name.');
end

switch type
    case 'kendall'
        rho=sin(pi*rank/2);
        
    case 'spearman'
        rho=2*sin(rank*pi/6);
end
        