function table3Latex(data,tabName,caption,label)
    % This is a custom made function for constant copula parameters
    % Krenar Avdulaj 21 Feb 2013
    fid=fopen(tabName,'w');
    
    % LaTEX table header
    fprintf(fid,'%s \n', '\begin{table}');
    fprintf(fid,'%s \n','\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrr}\toprule');
    fprintf(fid,'%s \n','& \multicolumn{2}{c}{Gold}& \multicolumn{2}{c}{Crude Oil}& \multicolumn{2}{c}{SP500}\\');
    fprintf(fid,'%s \n','\midrule');

    
    rnames = {'$c$','$\alpha_1$','$\alpha_2$','$\omega$','$\beta$','$\gamma$','$\xi$','$\phi$','$\tau_1$','$\tau_2$','$\nu$','$\lambda$','$\mathcal{LL}_{r,x}$','$\mathcal{LL}_{r}$','$AIC_r$','$BIC_r$'};
    
    for ROW=1:size(data,1)            
            if  (strcmp(rnames{ROW},'$\mathcal{LL}_{r,x}$')||strcmp(rnames{ROW},'$\mathcal{LL}_{r}$')||strcmp(rnames{ROW},'$AIC_r$')||strcmp(rnames{ROW},'$BIC_r$'))
                fprintf(fid,'%s ',rnames{ROW});
              for COL=1:size(data,2) 
                if mod(COL,2)~=0
                fprintf(fid,'%s ',char(strcat({'&\multicolumn{2}{c}{'}))); % bold LL value
                fprintf(fid,' %10.2f ', data(ROW,COL));
                fprintf(fid,'%s ',char(strcat({'}'})));
                elseif COL==size(data,2)
                       fprintf(fid,'%s \n', '\\');
                else
                end
              end
            
            else
                fprintf(fid,'%s ',rnames{ROW});
                for COL=1:size(data,2) 
                         if isnan(data(ROW,COL)) 
                                fprintf(fid,'%s ','&-'); % replace NaNs                              
                                if COL==size(data,2)
                                fprintf(fid,'%s \n', '\\');
                                else
                                end
                         else
                               if mod(COL,2)==0
                                 fprintf(fid,'&(%4.2f)', data(ROW,COL));  
                               else
                                fprintf(fid,'& %3.4f ', data(ROW,COL));
                               end
                             
                                if COL==size(data,2)
                                fprintf(fid,'%s \n', '\\');
                                else
                                end
                            
                         end
                end
            end                
        
    end
    
    % LaTEX table footer
    fprintf(fid,'%s \n', '  \bottomrule ');
    fprintf(fid,'%s \n','\end{tabular*}  ');
    fprintf(fid,'%s ', '\caption{');
    fprintf(fid,'%s',char(strcat({caption})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s ', '\label{tab:');
    fprintf(fid,'%s',char(strcat({label})));
    fprintf(fid,'%s  \n',char(strcat({'}'})));
    fprintf(fid,'%s \n','\end{table}');
    fclose(fid);
    