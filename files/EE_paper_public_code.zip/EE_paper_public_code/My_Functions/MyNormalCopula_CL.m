
function CL=MyNormalCopula_CL(theta,data)
% This function estimates the d-dimensional Gaussian copula.

% INPUTS: -theta: a vector of correlations (or scalar)
%         -data: the PIT data.
% Krenar Avdulaj 17 April 2012
[m,n]=size(data);
x=nines(m,n);

for i=1:n
    x(:,i)=norminv(data(:,i),0,1);
end

rho=reshape(repmat(theta2rho(theta),1,m),n,n,m); % transform the vector of rho-s 
                                                 % into a correlation matrix form.
LL=zeros(m,1);

for t=1:m
    LL(t)=-0.5*log(det(rho(:,:,t)));
    LL(t)=LL(t)-0.5*x(t,:)*(inv(rho(:,:,t))-eye(n))*x(t,:)'; % check this part
end
LL=-LL;
CL=sum(LL);