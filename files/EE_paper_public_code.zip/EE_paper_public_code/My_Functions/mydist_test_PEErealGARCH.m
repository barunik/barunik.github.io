function out1 = mydist_test_PEErealGARCH(T,ARparams,realGARCHparams,SKEWTparams,GARCHstartvals,sigma_u,varRet,errorsDist);
%function [KSstats CvMstats] = dist_test_PEE(T,reps,ARparams,GARCHparams,SKEWTparams);
%
%  Function to simulate from an AR-realRGARCH-SKEWt time series model, estimate the parameters of each, then compute the Kolmogorov-Smirnov and
%  Cramer-von Mises test statistics on the estimated probability integral transforms. This gives us a simulated distribution of these test stats
%  taking into account the estimation error from the unknown parameters.
%
%  INPUTS:  T, a scalar, the sample size
%           reps, a scalar, the number of replications to use
%           ARparams, a p+1 x 1 vector, [phi0,phi1,...phiP] the AR(p) parameters for the mean
%           GARCHparams, a 7x1 vector, [w,b,g,xi,phi,tau1,tau2] the parameters of the realGARCH model for the variance
%           SKEWTparams, a 2x1 vector, [nu,lam], the parameters of the skewed t distribution
%           GARCHstartvals, a 7x1 vector, starting values for realGARCH estimation (default = [])
%           errors: "NORMAL","STUDENTST" or "GED" (see "multigarch" function). This line added by Krenar Avdulaj on 04.01.2013 
%  OUTPUTS: out1, a repsx2 matrix, [KSstats, CvMstats] the KS and CvM test stats on each of the simulated series
%
%  Modified by K.A (from Andrew Patton's code) to adjust for realized GARCH model
%  04 January 2013
% This version has slight changes to allow parallelizing from outside the
% function. i.e. i have removed "reps" from running within the function, I run it from outside instead.
ARp = length(ARparams)-1;
options = optimset('Display','off','TolCon',10^-12,'TolFun',10^-4,'TolX',10^-6,'Algorithm','interior-point','UseParallel','always');
T=T+2000;% because we will through away the first 2000 
% out1 = nan(reps,2);
% for rr=1:reps;
    if strcmp(errorsDist,'NORMAL')
        zt=normrnd(SKEWTparams(1),SKEWTparams(2),[T 1]); % Added by Krenar Avdulaj. The SKEWTparams name may be misleading, but
        % here represents the mean and variance of Normal distribution, I
        % was lazy to change the parameters names in this function.
    else    
        zt = skewtdis_rnd(SKEWTparams(1),SKEWTparams(2),T);  % simulating the standardized residuals
    end
    mu = nan(T,1);
    rt = nan(T,1);
    et = nan(T,1);
    loght=nan(T,1);
    logxt=nan(T,1);
    ut=normrnd(0,sigma_u,[T 1]); % because the assumption of the model is: (ut/sigma_u)~ iid N(0,1) p.884 Hansen's paper.
    
    omega=realGARCHparams(1);
    bet=realGARCHparams(2);
    gam=realGARCHparams(3);
    xi=realGARCHparams(4);
    phi=realGARCHparams(5);
    tau1=realGARCHparams(6);
    tau2=realGARCHparams(7);
    
    % starting values for series
    if ARp>0
        mu(1) = ARparams(1)/(1-sum(ARparams(2:end)));
    else
        mu(1) = ARparams(1);
    end
    
    if ~(isempty(realGARCHparams) && isempty(GARCHstartvals)) % it these 2 fields are empty then constant mean
        
        loght(1)=log(varRet); % start at unconditional variance.        
        %loght(1) =omega+bet*loght0+gam*logxt(1); %omega+gam*logxt(1))/(1-bet); %log((gam*xi*(1+phi*gam))/(1-phi^2*gam-bet*(1+phi^2*gam+phi*gam)));
        logxt(1)=xi+phi*loght(1)+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1); % log of the 1st element of RV. Given from the data.
        %loght(1)=log(GARCHstartvals(1));
        et(1) = sqrt(exp(loght(1)))*zt(1);
        %logxt(1)=xi+phi*loght(1)+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1);
        %logxt(1)= xi+phi*loght(1)+tau1*zt(1)+tau2*(zt(1)^2-1)+ut(1);%log(GARCHstartvals(2));
        rt(1) = mu(1) + et(1);

        % looping through rest of series
        for tt=2:T;
            loght(tt) = omega + bet*loght(tt-1) + gam*logxt(tt-1);
            et(tt) = sqrt(exp(loght(tt)))*zt(tt);
            logxt(tt)=xi+phi*loght(tt)+tau1*zt(tt)+tau2*(zt(tt)^2-1)+ut(tt);

            if tt<=ARp
                mu(tt) = mu(1);  % using unconditional mean for first ARp obs of conditional mean
            else
                mu(tt) = ARparams(1);
                if ARp>0
                    mu(tt) = mu(tt) + ARparams(2:end)'*rt(tt-1:-1:tt-ARp);
                end
            end
            rt(tt) = mu(tt) + et(tt);
        end
        xt=exp(logxt); % realized volatility
        % estimating mean model
        temp = ols(rt(ARp+1:end),[ones(T-ARp,1),mlag(rt(ARp+1:end),ARp,mu(1))]);
        ehat = [zeros(ARp,1);temp.resid]; % zero mean returns
        ehat=ehat/std(ehat);
        xt=xt(2001:T);
        ehat=ehat(2001:T);
        % estimating the realizedGARCH model
        [para, ~,~,hhat1,sig,u,~] = RealGARCHestimate([ehat xt],'SKEWT');
        epshat = ehat./sqrt(hhat1);
     
    end
    
    if strcmp(errorsDist,'NORMAL') % this part added by K.A. 04.01.2013
    outNormal=fitdist(epshat,'normal');% estimating Normal model
    outNormal=outNormal.Params;%
    Uhat=normcdf(epshat,outNormal(1),outNormal(2));%
    else
    % estimating skew t model
    lower = [2.1, -0.99];
    upper = [100, 0.99 ];
    theta0 = [6;0];
    theta = fmincon('skewtdis_LL',theta0,[],[],[],[],lower,upper,[],options,epshat);
    Uhat = skewtdis_cdf(epshat,theta(1),theta(2));
    end
    T=T-2000;
    % the test stats
    KSstat = max(abs(sort(Uhat) - (1:T)'/T));
    CvMstat = sum( (sort(Uhat)-(1:T)'/T).^2 );
    out1= [KSstat,CvMstat];
    