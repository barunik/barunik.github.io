% Clear the memory
clear all; close all;  clc
address='/Users/krenaravdulaj/PhD_IES/Working_Papers';
save_path = ([address,'/Patton_copula_toolbox/Results1/']);         % where you would like any output MAT files saved

load('CDB_all.mat')

% consCDB is obtained from simulations below
consCDB= [0.0010    0.7659    0.6343    0.8815;
    0.0050    0.6956    0.6281    0.7609;
    0.0100    0.6607    0.6089    0.7108;
    0.0500    0.5481    0.5214    0.5749;
    0.1000    0.4766    0.4569    0.4961;
    0.9000    0.0314    0.0298    0.0331;
    0.9500    0.0150    0.0140    0.0159;
    0.9900    0.0028    0.0025    0.0031];
grey1=[0.6 0.6 0.6];
grey2=[.8 .8 .8];
grey=[.4 .4 .4 ];
WW = [0;0.01;(0.05:0.05:0.95)';0.99;1];
QQ = [0.001;0.005;0.01;0.05;0.1;0.9;0.95;0.99]; 
weight= find(abs(WW-0.5)<eps); % get index for equal weight
T=size(CDB,1);

qq=4; % choose the quantile of interest
fig=figure(1000+qq);
set (fig,'Position',[100 100 700 350],'Color',[1 1 1]) %
set (gca,'FontSize',14) %;

cc=1;
h2=plot(dates,CDB(:,qq,cc),'Linestyle','-','Color',grey2); hold on;
h1=plot(dates,consCDB(qq,2)*ones(T,1),'k-'); hold on;
h3=plot(dates,consCDB(qq,3)*ones(T,1),'k--');
plot(dates,consCDB(qq,4)*ones(T,1),'k--');
% jbfill(dates',consCDB(qq,4)*ones(T,1)',consCDB(qq,3)*ones(T,1)',grey2,grey2,[],1);
% hold on; %remove plots above use jbfill to have filled CI
set (gca,'Layer','bottom')
cc=3;
h4=plot(dates,CDB_OOS(:,qq,cc),'k:');
cc=4;
h5=plot(dates,CDB_OOS(:,qq,cc),'k-.');
datetick('x')
axis([dates(1) dates(end) 0.2 0.8])
h_legend=legend([h2 h1 h3 h4 h5],{'Normal','Constant CDB','90% CI','Normal-GAS','t-GAS'},'Location','SouthWest');
set(h_legend,'FontSize',16);
title(['Conditional diversification benefits for Oil-SP500 (alpha=',num2str(QQ(qq),2),')'],'Fontsize',16)
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'CDB_Oil-SP500_',num2str(100*QQ(qq)),'_bw.eps'],'psc2') %


% clc
% WW = [0;0.01;(0.05:0.05:0.95)';0.99;1];  % getting lots of weights, as this part is cheap once we have the simulations
% QQ = [0.001;0.005;0.01;0.05;0.1;0.9;0.95;0.99];  % quantiles to look at
% 
nIndices=1;
T=10000;
sims = 5000;
outVARu2 = nan(T,4,length(WW),length(QQ),2,2,nIndices);
ES=nan(T,4,length(QQ),2,nIndices);
clear UUU
uu=2;
tStart=tic;
for pp=1%:nIndices;
for tt=1:T;
U2 = normcdf(mvnrnd(zeros(1,2),[[1,0.2899];[0.2899,1]],sims)); % 0.2899 is the unconditional correlations between Oil & SP500
YYY = [norminv(U2(:,1),0,1) norminv(U2(:,2),0,1)];
for cc=1%:4;
for qq=1:length(QQ);
temp124 = (YYY(:,1,cc)<=quantile(YYY(:,1,cc),QQ(qq)));  % observations below this quantile
if sum(temp124)>0
ES(tt,cc,qq,1,pp) = mean(YYY(temp124,1,cc));
end
temp124 = (YYY(:,2,cc)<=quantile(YYY(:,2,cc),QQ(qq)));  % observations below this quantile
if sum(temp124)>0
ES(tt,cc,qq,2,pp) = mean(YYY(temp124,2,cc));
end
end
for ww=1:length(WW);
w = WW(ww);
pf = w*YYY(:,1,cc) + (1-w)*YYY(:,2,cc);
outVARu2(tt,cc,ww,:,1,1,pp) = quantile(pf,QQ);                 % Value at Risk
for qq=1:length(QQ);
temp124 = (pf<=quantile(pf,QQ(qq)));  % observations below this quantile
if sum(temp124)>0
outVARu2(tt,cc,ww,qq,2,1,pp) = mean(pf(temp124));   % Expected Shortfall for simulated returns
end

end
end
end
if mod(tt,100)==0
[tt,toc(tStart)]
end
end
tEnd=toc(tStart);
fprintf('Finished simulation of parametric VaR and ES for pair. Number of simulations/day: %d \n',sims)
fprintf('Cumulative time %d minutes and %f seconds \n', floor(tEnd/60),rem(tEnd,60))
end

CDB=nan(T,length(QQ),1);
wstar = find(abs(WW-0.5)<eps); % doing WW==0.5 does not work ! ... because of floating point numbers
for cc=1%:4
for qq=1:length(QQ)
CDB(:,qq,cc)=(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,2,1,pp))./(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,1,1,pp));
figure;
plot(CDB(:,qq,cc))
fprintf('Constant CDB for quantile %.2f%% is %.4f with 90%% confidence interval [%.4f %.4f] \n',100*QQ(qq), mean(CDB(:,qq,cc)),quantile(CDB(:,qq,cc),[0.1 0.9]) ) % constant CDB at given quantile
consCDB(qq,:)=[QQ(qq) mean(CDB(:,qq,cc)) quantile(CDB(:,qq,cc),[0.1 0.9]) ];
end
end

% This is consCDB
%       QQ      mean        L ci    U ci
%     0.0010    0.7659    0.6343    0.8815
%     0.0050    0.6956    0.6281    0.7609
%     0.0100    0.6607    0.6089    0.7108
%     0.0500    0.5481    0.5214    0.5749
%     0.1000    0.4766    0.4569    0.4961
%     0.9000    0.0314    0.0298    0.0331
%     0.9500    0.0150    0.0140    0.0159
%     0.9900    0.0028    0.0025    0.0031

 
