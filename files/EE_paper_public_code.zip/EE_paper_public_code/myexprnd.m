function out=myexprnd(lambda,T,k)
% Generates a vector of size Txk from exponential distribution with rate parameter lambda.
% Inputs: lambda > 0 is the rate parameter
%         T is the length of output vector
% Krenar Avdulaj 29.09.2013
% Make sure the rate parameter is positive.
if nargin>3
    error('Too many arguments');
elseif nargin>2
    lambda(lambda<=0)=1;
elseif nargin>1
    k=1;
    lambda(lambda<=0)=1;
else
    T=100;
    lambda(lambda<=0)=1;
end

F=rand(T,k);
for i=1:length(lambda)
    out(:,:,i)=-(1/lambda(i)).*log(1-F);
end
% Remove unnecessary dimensions
out=squeeze(out);
end
