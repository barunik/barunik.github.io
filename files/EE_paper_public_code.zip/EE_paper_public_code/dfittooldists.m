function s = dfittooldists
%DFITTOOLDISTS Initialize dfittool with custom distributions.
%
%    S=DFITTOOLDISTS is called during the initialization of DFITTOOL to get
%    any custom distributions you may want to define.  This function should
%    appear somewhere on your MATLAB path.  You can edit it to define
%    distributions that you want to be available for fitting in DFITTOOL.
%    S is a structure or an array of structures with fields as defined below.
%
%    You can load this after initialization by using the menu item
%    File -> Import Custom Distributions.  In that case you are not
%    restricted to use the name DFITTOOLDISTS.
%
%    See also DFITTOOL.

%   Copyright 2001-2009 The MathWorks, Inc.
%   $Revision: 1.1.8.1 $  $Date: 2010/03/16 00:29:21 $

% Create a structure to receive distribution information
s = struct('name',{},'pnames',{},'pdescription',{},'cdffunc',{}, ...       
           'pdffunc',{},'invfunc',{},'fitfunc',{},'statfunc',{}, ...      
           'islocscale',{});
% ---------------------------------------------------------
% ---- Remove the following return statement to define the
% ---- Laplace distributon
% ---------------------------------------------------------
% return

% Laplace (double exponential) distribution definition
j = 1;                                     % custom distribution #1
s(j).name = 'Laplace';                     % name for display
s(j).pnames = {'mu' 'sigma'};              % names of parameters
s(j).pdescription = {'location' 'scale'};  % descriptions of parameters
s(j).cdffunc = @laplcdf;                   % function to compute cdf
s(j).pdffunc = @laplpdf;                   % function to compute density
s(j).invfunc = @laplinv;                   % function to compute inverse cdf
s(j).fitfunc = @laplfit;                   % function to do fit
s(j).statfunc = @laplstat;                 % function to compute mean and var
s(j).islocscale = true;                    % location/scale distribution?


% ----------------------------------------------------------------
% ---- To enter your own distribution below, remove the following
% ---- return statement and modify the other statements as necessary
% ----------------------------------------------------------------

% return

% Increment index
j = j+1;

% Enter a text string to display as distribution name
s(j).name = 'Skewed t'; % Hansen's (1994) 'skewed t' distribution

% Enter the names of the parameters
s(j).pnames = {'nu' 'lambda'};

% (optional) Enter a short description of each parameter (default empty)
s(j).pdescription = {'degrees of freedom' 'skewness parameter'};

% (optional) Enter a vector indicating whether each parameter must have
% its value specified (true) or if it can be estimated (false, default)
%s(j).prequired = [false false];

% Enter function handles to compute the cdf, pdf, and inverse cdf.  See the
% Laplace distribution functions below for examples.
s(j).cdffunc = @skewtdis_cdf;
s(j).pdffunc = @skewtdis_pdf;
s(j).invfunc = @skewtdis_inv;

% Define a function that can fit this distribution.  See the Laplace
% distribution functions below for an example.
s(j).fitfunc = @skewtdis_fit;

% (optional) Define a function that can compute the negative log likelihood
% (default none).
% s(j).likefunc = @skewtdis_LL;

% (optional) Enter a function handle to compute the mean and variance.  See
% the Laplace distribution functions below for an example.
s(j).statfunc = @skewtdis_stat;

% (optional) Enter a function handle to generate random values.
%s(j).randfunc = @(varargin) yourinv(rand(varargin{:}));

% (optional) Enter a function handle to check that the parameter values are
% valid.
%s(j).checkparam = @(p) p(2)>0;

% (optional) Enter a function handle to compute confidence intervals.  The
% function inputs are the parameter estimate, its covariance matrix, the
% alpha value defining the confidence level, and the data, censoring, and
% frequency vectors.
%s(j).cifunc = @(p,cov,a,x,c,f) statparamci(p,cov,a);

% (optional) Enter a two-element vector defining the range over which
% this distribution gives positive probability, such as:
%    [-Inf Inf]    The entire real line (default)
%    [0 Inf]       Positive values only
%    [-1 1]        Values between -1 and 1 only
%s(j).support = [-Inf Inf];

% (optional) Enter a two-element vector specifying whether a data value
% can be exactly at the boundary (true) or must be strictly within the
% boundary (false, default for both end points)
%s(j).closedbound = [false false];

% (optional) Is this a continuous distribution (true, default) or is it
% on the integers only (false)
%s(j).iscontinuous = true;

% (optional) Is this distribution a location/scale family (default false)
s(j).islocscale = true;

% (optional) Define functions that can compute the cdf and inverse cdf
% on the log scale, for example @normcdf and @norminv can do this for
% the lognormal distribution (default none)
%s(j).logcdffunc = @yourlogcdf;
%s(j).loginvfunc = @yourloginv;

% (optional) Do the cdf and inverse cdf functions return confidence bounds
% as additional outputs? (default false)
%s(j).hasconfbounds = false;

% (optional) Does the fit function support both censoring and
% frequency variables as 3rd and 4th inputs? (default false)
%s(j).censoring = false;

% (optional) Does the fit function return the fitted parameters as a
% single vector (true, default) or as separate scalars (false)
%s(j).paramvec = true;

% (optional) Should the probability plot be on the log scale? (default false)
%s(j).uselogpp = false;

% (optional) Enter a code name to use internally (default is lower case
% version of the distribution name)
%s(j).code = 'entercode';

% (optional) Does the fitting function accept an optim options structure?
% (default false)
%s(j).optimopts = false;

% (optional) Function to compute the distribution's support as functions
% of the parameters (default is the value of the support field
%s(j).supportfunc = @yoursupport

% ---------------------------------------------------
% ---- Define additional distributions similarly below
% ---------------------------------------------------
function paramEsts = skewtdis_fit(data,alpha,cens,freq,opts)
%skewtdis_FIT Fit the skew t distirbution

% The fitting function must take all five arguments.  ALPHA and OPTS are
% not used by DFITTOOL, and should be ignored in the code.  CENS and FREQ
% may safely be ignored in the code if a censoring or frequency vector is
% never used.  This example function does not support either.


% Starting values are needed:
theta0 = [6;0];

% Fit the Laplace distribution
paramEsts = mle(data, 'pdf',@skewtdis_pdf, 'cdf',@skewtdis_cdf, 'start',theta0)';

function pdf = skewtdis_pdf(x, nu, lambda)
% PURPOSE: returns the pdf at x of Hansen's (1994) 'skewed t' distribution
%---------------------------------------------------
% USAGE: pdf = skewtdis_pdf(x,nu,lambda)
% where: x  = a matrix, vector or scalar 
%        nu = a matrix or scalar degrees of freedom parameter 
%			  lambda = a maxtrix or scalar skewness parameter 
%---------------------------------------------------
% RETURNS:
%        a matrix of pdf at each element of x       
% --------------------------------------------------
% SEE ALSO: tdis_cdf, tdis_rnd, tdis_inv, tdis_prb, skewtdis_cdf
%---------------------------------------------------
%
% Based on tdis_pdf.m from the "Spatial Econometrics"
% toolbox of James P. LeSage
% http://www.spatial-econometrics.com/
%
%  Andrew Patton
%
%  25 June, 2001

% This code was used in: 
%
%	Patton, Andrew J., 2002, "On the Out-of-Sample 
% Importance of Skewness and Asymmetric Dependence for
% Asset Allocation", working paper, Department of Economics,
% University of California, San Diego.


[T,k] = size(x);
if size(nu,1)<T;
   nu = nu(1)*ones(T,1);
end
if size(lambda,1)<T;
   lambda = lambda(1)*ones(T,1);
end
c = gamma((nu+1)/2)./(sqrt(pi*(nu-2)).*gamma(nu/2));
a = 4*lambda.*c.*((nu-2)./(nu-1));
b = sqrt(1 + 3*lambda.^2 - a.^2);

pdf1 = b.*c.*(1 + 1./(nu-2).*((b.*x+a)./(1-lambda)).^2).^(-(nu+1)/2);
pdf2 = b.*c.*(1 + 1./(nu-2).*((b.*x+a)./(1+lambda)).^2).^(-(nu+1)/2);
pdf  = pdf1.*(x<(-a./b)) + pdf2.*(x>=(-a./b));

function cdf = skewtdis_cdf(x, nu, lambda)
% PURPOSE: returns the cdf at x of Hansen's (1994) 'skewed t' distribution
%---------------------------------------------------
% USAGE: cdf = skewtdis_cdf(x,nu,lambda)
% where: x  = a matrix, vector or scalar 
%        nu = a matrix or scalar degrees of freedom parameter 
%			  lambda = a maxtrix or scalar skewness parameter 
%---------------------------------------------------
% RETURNS:
%        a matrix of cdf at each element of x      
% --------------------------------------------------
% SEE ALSO: tdis_cdf, tdis_rnd, tdis_inv, tdis_prb, skewtdis_pdf
%---------------------------------------------------
%
% Based on tdis_cdf.m from the "Spatial Econometrics"
% toolbox of James P. LeSage
% http://www.spatial-econometrics.com/
%
%  Andrew Patton
%
%  25 June, 2001

% This code was used in: 
%
%	Patton, Andrew J., 2002, "On the Out-of-Sample 
% Importance of Skewness and Asymmetric Dependence for
% Asset Allocation", working paper, Department of Economics,
% University of California, San Diego.


[T,k] = size(x);
if size(nu,1)<T;
   nu = nu(1)*ones(T,1);
end
if size(lambda,1)<T;
   lambda = lambda(1)*ones(T,1);
end
c = gamma((nu+1)/2)./(sqrt(pi*(nu-2)).*gamma(nu/2));
a = 4*lambda.*c.*((nu-2)./(nu-1));
b = sqrt(1 + 3*lambda.^2 - a.^2);

y1 = (b.*x+a)./(1-lambda).*sqrt(nu./(nu-2));		
y2 = (b.*x+a)./(1+lambda).*sqrt(nu./(nu-2));

cdf = (1-lambda).*tdis_cdf(y1,nu).*(x<-a./b);
cdf = cdf + (x>=-a./b).*((1-lambda)/2 + (1+lambda).*(tdis_cdf(y2,nu)-0.5));

function inv = skewtdis_inv(u, nu, lambda)
% PURPOSE: returns the inverse cdf at u of Hansen's (1994) 'skewed t' distribution
%---------------------------------------------------
% USAGE: inv = skewtdis_inv(u,nu,lambda)
% where: U  = a matrix, vector or scalar in the unit interval
%        nu = a matrix or scalar degrees of freedom parameter 
%			  lambda = a maxtrix or scalar skewness parameter 
%---------------------------------------------------
% RETURNS:
%        a matrix of the inverse cdf at each element of u 
% --------------------------------------------------
% SEE ALSO: tdis_cdf, tdis_rnd, tdis_inv, tdis_prb, skewtdis_pdf
%---------------------------------------------------
%
% Based on tdis_inv.m from the "Spatial Econometrics"
% toolbox of James P. LeSage
% http://www.spatial-econometrics.com/
%
%  Andrew Patton
%
%  25 June, 2001

% This code was used in: 
%
%	Patton, Andrew J., 2002, "On the Out-of-Sample 
% Importance of Skewness and Asymmetric Dependence for
% Asset Allocation", working paper, Department of Economics,
% University of California, San Diego.

[T,k] = size(u);
if size(nu,1)<T;
   nu = nu(1)*ones(T,1);
end
if size(lambda,1)<T;
   lambda = lambda(1)*ones(T,1);
end
c = gamma((nu+1)/2)./(sqrt(pi*(nu-2)).*gamma(nu/2));
a = 4*lambda.*c.*((nu-2)./(nu-1));
b = sqrt(1 + 3*lambda.^2 - a.^2);

f1 = find(u<(1-lambda)/2);
f2 = find(u>=(1-lambda)/2);

inv1 = (1-lambda(f1))./b(f1).*sqrt((nu(f1)-2)./nu(f1)).*tdis_inv(u(f1)./(1-lambda(f1)),nu(f1))-a(f1)./b(f1);
inv2 = (1+lambda(f2))./b(f2).*sqrt((nu(f2)-2)./nu(f2)).*tdis_inv(0.5+1./(1+lambda(f2)).*(u(f2)-(1-lambda(f2))./2),nu(f2))-a(f2)./b(f2);
inv = -999.99*ones(T,1);
inv(f1) = inv1;
inv(f2) = inv2;

function [m,v] = skewtdis_stat(~,~)
%skewtdis_STAT Skew t distribution statistics of Hansen 1994.
% This distribution is normalized to have 0 mean and variance 1.
% the input is required in a function form, thus the "function" here.
% Krenar Avdulaj 30.12.2012

m = 0;
v = 1;

% -----------------------------------------------------------------------
% ---- Include any local functions required for your custom distributions
% -----------------------------------------------------------------------

function paramEsts = laplfit(data,alpha,cens,freq,opts)
%LAPLFIT Fit the Laplace distribution

% The fitting function must take all five arguments.  ALPHA and OPTS are
% not used by DFITTOOL, and should be ignored in the code.  CENS and FREQ
% may safely be ignored in the code if a censoring or frequency vector is
% never used.  This example function does not support either.

% Fitting for the Laplace distribution is simple:
%    mu = median(data);
%    sigma = mean(abs(data-mu));
%    p = [mu sigma];

% For illustration, though, the following lines use an iterative numerical
% fitting function that could also be used to fit other distributions

% Starting values are needed:
mu = mean(data);
sigma = std(data);

% Fit the Laplace distribution
paramEsts = mle(data, 'pdf',@laplpdf, 'cdf',@laplcdf, 'start',[mu, sigma]);


function f = laplpdf(x,mu,sigma)
%LAPLPDF Laplace distribution probability density function
if nargin<2, mu=0; end
if nargin<3, sigma=1; end
z = (x-mu)./sigma;
f = exp(-abs(z))/(2*sigma);


function F = laplcdf(x,mu,sigma)
%LAPLCDF Laplace distribution cumulative distribution function
if nargin<2, mu=0; end
if nargin<3, sigma=1; end
F = zeros(size(x));
z = (x-mu)./sigma;
t = (z<=0);
F(t) = exp(z(t))/2;
F(~t) = 1 - exp(-z(~t))/2;


function x = laplinv(p,mu,sigma)
%LAPLINV Laplace distribution inverse cumulative distribution function
if nargin<2, mu=0; end
if nargin<3, sigma=1; end
z = zeros(size(p));
t = (p<=.5);
z(t) = log(2*p(t));
z(~t) = -log(1-2*(p(~t)-.5));
x = mu + sigma*z;


function [m,v] = laplstat(mu,sigma)
%LAPLSTAT Laplace distribution statistics
m = mu;
v = 2 * sigma.^2;

