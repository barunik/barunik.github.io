function output = mylogdensity2info(logLL,param_mle,data)
% Compute the information matrix = Sum_{i=1}^n Score_i' Score_i
% Inputs: logLL -> +/- Log-likelihood function of bivariate copula (different types)
%         param_mle-> parameters estimate from MLE.
%         data-> [u v]
% May 2012
% Krenar Avdulaj (I have slightly modified the code provided by Ait
% Sahalia).
n = size(data,1) - 1;
output = 0;
for i=1:n
    tmpfun = @(theta)(logLL(theta,data(i,:)));
    score_i = gradest(tmpfun,param_mle); % This is a row vector
    output = output + score_i' * score_i;
end