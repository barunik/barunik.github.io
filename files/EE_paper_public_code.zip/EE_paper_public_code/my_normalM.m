function out=my_normalM(param,data)


T=size(data,1);
logLik=nan(T,1);

for i=1:T
logLik(i)= -0.5*(log(2*pi)+log(param(2)^2)+(data(i)-param(1)).^2/param(2)^2);
end
out=-sum(logLik);
            