% Clear the memory
clear all; close all;  clc

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SETTING THE PATHS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OSX path
address='/Users/krenaravdulaj/Desktop';
addpath(genpath([address,'/EE_paper/Ucsd_garch']));                 % adding the "UCSD GARCH" toolbox to the path directory. (This is needed for some parts of the code below.) You can skip this line if you already have this toolbox on your saved directory path
addpath(genpath([address,'/EE_paper/spatial']));            % adding the "Spatial Econometrics" toolbox to the path directory. (This is needed for some parts of the code below.) You can skip this line if you already have this toolbox on your saved directory path
addpath(genpath([address,'/EE_paper']));    % adding the path for *this* toolbox. Change this location to wherever you unzipped the toolbox.
data_path = ([address,'/EE_paper/']);        % where the data is saved
save_path = ([address,'/EE_paper/Results/']);         % where you would like any output MAT files saved

save_name = '01Nov15'; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% getting VaR and ES for a portfolio of these variables

% WARNING: THIS PART IS VERY SLOW (takes around 12 hours for 3 pairs and
% sims=5000)

WW = [0;0.01;(0.05:0.05:0.95)';0.99;1];  % getting lots of weights, as this part is cheap once we have the simulations
QQ = [0.001;0.005;0.01;0.05;0.1;0.9;0.95;0.99];  % quantiles to look at


% I am obtaining resids again here because the resids from previous are in
% fact standardized.
for ii=1:nIndices
    [theta1,sig21,vcv1,order1,resids1] = ARMAX_opt(rets1(:,ii),5,5,'BIC');  % takes about 6 seconds per variable
    mean_order(ii,1:2) = order1';
    mean_order(ii,3) = 1-sig21/cov(rets1(:,ii));
    resids(:,ii) = [zeros(max(order1),1);resids1];
end

muhat = rets1 - resids;  % conditional mean
% Full sample
sims = 5000;
outVARu2 = nan(T,4,length(WW),length(QQ),2,2,nIndices);
ES=nan(T,4,length(QQ),2,nIndices);
clear UUU
uu=2;
tStart=tic;
for pp=3%:nIndices;
    for tt=1:T;
        U2 = normcdf(mvnrnd(zeros(1,2),[[1,thetaALL(1,1,uu,pp)];[thetaALL(1,1,uu,pp),1]],sims));
        U3 = 1-Gumbel_rnd2_mex(kappatRotp(tt,pp),sims);
        U4 = normcdf(mvnrnd(zeros(1,2),[[1,rhotNormp(tt,pp)];[rhotNormp(tt,pp),1]],sims));
        U5 = tdis_cdf(mvtrnd([[1,rhotTp(tt,pp)];[rhotTp(tt,pp),1]],1/table8(21,1,pp),sims),thetaALL(8,1,uu,pp));
        UUU(:,:,1) = U2;
        UUU(:,:,2) = U3;
        UUU(:,:,3) = U4;
        UUU(:,:,4)=U5;
        EEE = nan(sims,2,2);
        YYY = nan(sims,2,2);
        for cc=1:4;
            for mm=1:2;
                EEE(:,mm,cc) = quantile(stdresids(:,pair(pp,mm)),UUU(:,mm,cc),1);
                YYY(:,mm,cc) = muhat(tt,pair(pp,mm)) + sqrt(hhat_ALL(tt,pair(pp,mm)))*EEE(:,mm,cc);  % simulated value for return
            end
            for qq=1:length(QQ);
                temp124 = (YYY(:,1,cc)<=quantile(YYY(:,1,cc),QQ(qq)));  % observations below this quantile
                if sum(temp124)>0
                    ES(tt,cc,qq,1,pp) = mean(YYY(temp124,1,cc));
                end
                temp124 = (YYY(:,2,cc)<=quantile(YYY(:,2,cc),QQ(qq)));  % observations below this quantile
                if sum(temp124)>0
                    ES(tt,cc,qq,2,pp) = mean(YYY(temp124,2,cc));
                end
            end
            for ww=1:length(WW);
                w = WW(ww);
                pf = w*YYY(:,1,cc) + (1-w)*YYY(:,2,cc);
                pf2 = w*EEE(:,1,cc) + (1-w)*EEE(:,2,cc);
                outVARu2(tt,cc,ww,:,1,1,pp) = quantile(pf,QQ);                 % Value at Risk
                outVARu2(tt,cc,ww,:,1,2,pp) = quantile(pf2,QQ);                 % Value at Risk of the std resids (useful for seeing where the copula matters)
                
                for qq=1:length(QQ);
                    temp124 = (pf<=quantile(pf,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,1,pp) = mean(pf(temp124));   % Expected Shortfall for simulated returns
                    end
                    temp124 = (pf2<=quantile(pf2,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,2,pp) = mean(pf2(temp124));   % Expected Shortfall for stdresids
                    end
                end
            end
        end
        if mod(tt,100)==0
            [tt,toc(tStart)]
        end
    end
    tEnd=toc(tStart);
    fprintf('Finished simulation of parametric VaR and ES for pair: %s . Number of simulations/day: %d \n',pairs{pp},sims)
    fprintf('Cumulative time %d minutes and %f seconds \n', floor(tEnd/60),rem(tEnd,60))
end
%toc  % takes about 3.88 hours for sims=5000
CDB=nan(T,length(QQ),4);

wstar = find(abs(WW-0.5)<eps); % doing WW==0.5 does not work ! ... because of floating point numbers
for cc=1:4
    for qq=1:length(QQ)
        CDB(:,qq,cc)=(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,2,1,pp))./(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,1,1,pp));
    end
end

%qq = find(abs(QQ-0.05)<eps);
grey=[0.4 0.4 0.4]; % define grey color

for qq=3:8
fig=figure(1000+pp+qq);
set (fig,'Position',[100 100 700 350],'Color',[1 1 1]) %
set (gca,'FontSize',14) %;
cc=1;
plot(dates,CDB(:,qq,cc),'Color',grey); hold on
cc=2;
plot(dates,CDB(:,qq,cc),'b');
cc=3;
plot(dates,CDB(:,qq,cc),'r');
cc=4;
plot(dates,CDB(:,qq,cc),'c');
datetick('x')
axis([dates(1) dates(end) 0 1])
legend('Normal','Gumbel-GAS','Normal-GAS','t-GAS',3)
title(['CDB for equal-weightet portfolio ',pairs{pp},' qq=',num2str(QQ(qq)),'(full sample)'])
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'CDB',pairs{pp},'_',100*QQ(qq),'.eps'],'psc2') %
end
% Export to csv.
csvwrite('CDB.csv',[CDB(:,:,1) CDB(:,:,2) CDB(:,:,3) CDB(:,:,4)])

%%
sims = 5000;
outVARu2 = nan(T,4,length(WW),length(QQ),2,2,nIndices);
ES=nan(T,4,length(QQ),2,nIndices);
clear UUU
uu=2;
tStart=tic;
for pp=3%:nIndices;
    for tt=1:T;
        U2 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,1,uu,pp)];[KAPPAhatOOS(tt,1,1,uu,pp),1]],sims));
        U3 = 1-Gumbel_rnd2_mex(KAPPAhatOOS(tt,1,6,uu,pp),sims);
        U4 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,7,uu,pp)];[KAPPAhatOOS(tt,1,7,uu,pp),1]],sims));
        U5 = tdis_cdf(mvtrnd([[1,KAPPAhatOOS(tt,1,8,uu,pp)];[KAPPAhatOOS(tt,1,8,uu,pp),1]],1/KAPPAhatIS(1,4,uu,pp),sims),1/KAPPAhatIS(1,4,uu,pp));
        UUU(:,:,1) = U2;
        UUU(:,:,2) = U3;
        UUU(:,:,3) = U4;
        UUU(:,:,4)=U5;
        EEE = nan(sims,2,2);
        YYY = nan(sims,2,2);
        for cc=1:4;
            for mm=1:2;
                EEE(:,mm,cc) = quantile(stdresidsOOS(:,pair(pp,mm)),UUU(:,mm,cc),1);
                YYY(:,mm,cc) = muhat(tt,pair(pp,mm)) + sqrt(VOL2hatOOS(tt,pair(pp,mm)))*EEE(:,mm,cc);  % simulated value for return
            end
            for qq=1:length(QQ);
                temp124 = (YYY(:,1,cc)<=quantile(YYY(:,1,cc),QQ(qq)));  % observations below this quantile
                if sum(temp124)>0
                    ES(tt,cc,qq,1,pp) = mean(YYY(temp124,1,cc));
                end
                temp124 = (YYY(:,2,cc)<=quantile(YYY(:,2,cc),QQ(qq)));  % observations below this quantile
                if sum(temp124)>0
                    ES(tt,cc,qq,2,pp) = mean(YYY(temp124,2,cc));
                end
            end
            for ww=1:length(WW);
                w = WW(ww);
                pf = w*YYY(:,1,cc) + (1-w)*YYY(:,2,cc);
                pf2 = w*EEE(:,1,cc) + (1-w)*EEE(:,2,cc);
                outVARu2(tt,cc,ww,:,1,1,pp) = quantile(pf,QQ);                 % Value at Risk
                outVARu2(tt,cc,ww,:,1,2,pp) = quantile(pf2,QQ);                 % Value at Risk of the std resids (useful for seeing where the copula matters)
                
                for qq=1:length(QQ);
                    temp124 = (pf<=quantile(pf,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,1,pp) = mean(pf(temp124));   % Expected Shortfall for simulated returns
                    end
                    temp124 = (pf2<=quantile(pf2,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,2,pp) = mean(pf2(temp124));   % Expected Shortfall for stdresids
                    end
                end
            end
        end
        if mod(tt,100)==0
            [tt,toc(tStart)]
        end
    end
    tEnd=toc(tStart);
    fprintf('Finished simulation of parametric VaR and ES for pair: %s . Number of simulations/day: %d \n',pairs{pp},sims)
    fprintf('Cumulative time %d minutes and %f seconds \n', floor(tEnd/60),rem(tEnd,60))
end
%toc  % takes about 3.88 hours for sims=5000
CDB_OOS=nan(T,length(QQ),4);

wstar = find(abs(WW-0.5)<eps); % doing WW==0.5 does not work ! ... because of floating point numbers
for cc=1:4
    for qq=1:length(QQ)
        CDB_OOS(:,qq,cc)=(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,2,1,pp))./(0.5*(ES(:,cc,qq,1,pp)+ES(:,cc,qq,2,pp))-outVARu2(:,cc,wstar,qq,1,1,pp));
    end
end

% qq = find(abs(QQ-0.05)<eps);
for qq=3:8
fig=figure(1010+pp+qq);
set (fig,'Position',[100 100 700 350],'Color',[1 1 1]) %
set (gca,'FontSize',14) %;
cc=1;
plot(dates,CDB_OOS(:,qq,cc),'Color',grey); hold on
cc=2;
plot(dates,CDB_OOS(:,qq,cc),'b');
cc=3;
plot(dates,CDB_OOS(:,qq,cc),'r');
cc=4;
plot(dates,CDB_OOS(:,qq,cc),'c');
datetick('x')
axis([dates(1) dates(end) 0 1])
legend('Normal','Gumbel-GAS','Normal-GAS','t-GAS',3)
title(['CDB for equal-weightet portfolio ',pairs{pp},' qq=',num2str(QQ(qq))])
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'CDB_OOS',pairs{pp},'_',100*QQ(qq),'.eps'],'psc2') %
end
% Export to csv.
csvwrite('CDB_OOS.csv',[CDB_OOS(:,:,1) CDB_OOS(:,:,2) CDB_OOS(:,:,3) CDB_OOS(:,:,4)])
% csvwrite('CDB_Normal_GAS.csv',CDB(:,:,2))
save('CDB_all.mat','CDB', 'CDB_OOS','dates')
