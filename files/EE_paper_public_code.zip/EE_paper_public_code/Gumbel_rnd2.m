function out1 = Gumbel_rnd2(kappa,T)


% Krenar Avdulaj: This function is a very mess, but I had to cope with it
% to create a mex file. July 2014

% function out1 = Gumbel_rnd(kappa,T,state)
%
% This program generates observations from
% a Gumbel copula
%
%  INPUTS:	kappa, a scalar or a Tx1 vector, the copula parameter
%					T,	a scalar, the number of obs in each sample
%					state, an integer to use to seed the random number generator
%
%  OUTPUT:	out1, a Tx2 matrix of data.
%
% Thursday, 8 November, 2001
%
%	Andrew Patton

% Written for the following papers:
%
% Patton, A.J., 2006, Modelling Asymmetric Exchange Rate Dependence, International Economic Review, 47(2), 527-556. 
% Patton, A.J., 2006, Estimation of Multivariate Models for Time Series of Possibly Different Lengths, Journal of Applied Econometrics, 21(2), 147-173.  
% Patton, A.J., 2004, On the Out-of-Sample Importance of Skewness and Asymmetric Dependence for Asset Allocation, Journal of Financial Econometrics, 2(1), 130-168. 
%
% http://fmg.lse.ac.uk/~patton


if size(kappa,1)~=T;		% stretching the input vectors to match each other
   kappa = kappa(1)*ones(T,1);
end

rng('default'); % deactivate the legacy number generator in case it is active

% if nargin<3
    rng('shuffle');	% setting RNG to new seed according to computer clock time.
% else
%    rng(state);
% end


out1 = -999.99*ones(T,2);
out1(1:T,2) = rand(T,1);			% transforms of Y
temp = rand(T,1);							% interim variable
for jj = 1:T;
   out1(jj,1) = GumbelUgivenV_inv2(out1(jj,2),temp(jj),kappa(jj));
end

function u = GumbelUgivenV_inv2(v,t,k)
% function u = GumbelUgivenV_inverse2(v,t,k)
%
% Computes the ivnerse value of the conditional Gumbel (U given V)
% copula cdf at a specified point
% 
% INPUTS:	t, a scalar uniform r.v.
%				v, a scalar r.v. G(Y[t])
%				k, a scalar of kappa
%
% Saturday, 28 July, 2001
%
% Andrew Patton
u=ones(size(v,1));

% info=struct('maxit',{100},'tol',{10^-6},'pflag',0);
[u,~] = bisecGumb_inv(10^-4,1-10^-4,v,t,k);


% % dealing with the extreme values that don't converge
% if junk==-999.99 		% then the zero of the function is very near to 0
%    [u,~] = bisec('GumbelUgivenV_t',10^-18,10^-4,v,t,k);
% elseif junk==999.99		% then the zero of the funciton is very near to 1
%    [u,~] = bisec('GumbelUgivenV_t',1-10^-4,1-10^-18,v,t,k);
% end

function [x,fval] = bisecGumb_inv(a,b,v,t,k)
% PURPOSE: Uses bisection to find root x of a univariate function on [a,b]
%          to tolerance tol, provided f(a) and f(b) have different signs
% ------------------------------------------------
% Usage:    [x,fval] = bisect(func,a,b,info,varargin)
%        or [x,fval] = bisect(func,a,b,[],varargin)
% Where : func = function of the form fval = func(x)
%            a = left endpoint of interval
%            b = right endpoint of interval
% info is a structure variable with:
%         .maxit = maximum # of iterations (default = 100)
%           .tol = convergence tolerance (default = sqrt(eps))   
%        .pflag  = 1 for printing during search (default = 0)    
%    varargin = arguments passed to func()
% ------------------------------------------------
% RETURNS:
%        x  = value at the root of func
%     fval  = function value at the root
%
% MODIFIED: 15 November, 2000 by Andrew Patton
% Changing the code so that it doesn't abort if
% the function has the same sign at the end points
% i.e., if I haven't chosen a wide enough interval
% to bound the zero...
 
% % set defaults
% maxit = 100;
 tol = sqrt(eps);
% pflag = 0;
% if length(info) > 0
%   if ~isstruct(info)
%     error('newton: options should be in a structure variable');
%   end;
% % parse options
% fields = fieldnames(info);
% nf = length(fields); ycheck = 0; xcheck = 0;
%   for i=1:nf
%     if strcmp(fields{i},'maxit')
%         maxit = info.maxit; 
%     elseif strcmp(fields{i},'tol')
%         tol = info.tol;
%     elseif strcmp(fields{i},'pflag')
%         pflag = info.pflag;
%     end;
%   end;
% else % case where we have no options
% % no input option, so we use default options

% end; % end of case where we have options

sa=0;
sb=0;

if a>b, error('b must exceed a'), end
sa = sign(GumbelUgivenV_t(a,v,t,k));
sb = sign(GumbelUgivenV_t(b,v,t,k));
%if sa==sb, error ('f has same sign at endpoints'), end   % original code

%modification:
if sa==sb
   if sa==-1   % then the zero is above the upper end-point
      x = b;	 % setting sol'n to upper end-point
      fval = +999.99;		% this is my 'error-code' telling me that it hasn't converged
   else
      x = a;
      fval = -999.99;		% this is my 'error-code' telling me that it hasn't converged
   end
else	% everything is OK so use original code
   x = (a+b)/2;
   d = (b-a)/2;
   while d>tol
      d = d/2;
      if sa == sign(GumbelUgivenV_t(x,v,t,k))
         x = x+d;
      else
         x = x-d;
      end 
%       if pflag == 1
%          mprint([sa d x],input);
%       end;
   end
   fval = sa;
end
