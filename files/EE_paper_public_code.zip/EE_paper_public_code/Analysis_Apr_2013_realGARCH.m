% This file is the new analysis of the dataset based on Patton's code
% from summer '12. http://public.econ.duke.edu/~ap172/
% This version: 6 April 2013.

% The number of loops has been reduced to 4 in many cases due to time
% consuption. Thus it should be changed according to number we mention in
% the paper "Are benefits from oil - stocks diversification gone? A new
% evidence from a dynamic copulas and high frequency data". e.g. change to
% 100, 1000 or 5000 depenfing on the step. ...sometimes graphs need rescaling.
% I have parallelized the code wherever I could and for geting the
% inference in the paper I have used computer with 12 i7 cores @ 2.8 GHz.
% (it took around 1 week to get the results). The bottleneck seems to be
% the time-arying t-copula, but not only. There are many functions which
% need to be written in C code to speed-up the process.

% This code is difficult to follow and includes also analysis for pairs
% "Gold-Oil", "Gold-SP500" in addition to "Oil-SP500". This might make the
% things more difficult. I will have to clean the code when i find the
% time. Some comments are from original A.P. code, some are mine.

% The last time this code was used was in April 2013, a couple of months before the paper was
% submitted to EE. I have tested the code in November 2015 on Matlab
% R2015a, Mac OSX 10.11.1 (El Capitan) with Intel i5 processor and it worked
% without a problem. Nevertheless, the user might need to compile some "c"
% funtions e.g. from the GARCH family. Please refer to UCSD package what
% you should do.
% Krenar Avdulaj, November 2015
% Clear the memory
clear all; close all;  clc

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SETTING THE PATHS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OSX path
address='/Users/krenaravdulaj/Desktop';
addpath(genpath([address,'/EE_paper/Ucsd_garch']));                 % adding the "UCSD GARCH" toolbox to the path directory. (This is needed for some parts of the code below.) You can skip this line if you already have this toolbox on your saved directory path
addpath(genpath([address,'/EE_paper/spatial']));            % adding the "Spatial Econometrics" toolbox to the path directory. (This is needed for some parts of the code below.) You can skip this line if you already have this toolbox on your saved directory path
addpath(genpath([address,'/EE_paper']));    % adding the path for *this* toolbox. Change this location to wherever you unzipped the toolbox.
data_path = ([address,'/EE_paper/']);        % where the data is saved
save_path = ([address,'/EE_paper/Results/']);         % where you would like any output MAT files saved

save_name = 'output_01Nov15'; 
%% Import Data
tic;
fprintf('Using univariate raw returns of commoditites. \n');
load ('Commodities1/raw_returns') %data obtained by Jozef
rvdata=importdata('realized_volatility.csv');

rets1=returns; % 
% rets1=100*rets1;

ret_str = {'Gold','Oil','SP500'};
pair=[1 2;1 3;2 3]; % here are different pairs combinations i.e. data columns combinations
pairs={'Gold-Oil' 'Gold-SP500' 'Oil-SP500'};
[T, nIndices] = size(rets1)  % 944,3

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BASIC SUMMARY STATISTICS AND FIGURES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Table 1
table1 = nan(4,3);
table1(1,:) = mean(rets1);
table1(2,:) = std(rets1);
table1(3,:) = skewness(rets1);
table1(4,:) = kurtosis(rets1);

% save path+file name
tabName=[save_path,save_name,'table1.tex'];
info.fid=fopen(tabName,'w');

% LaTEX table header
h1 = '\begin{table}';
h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrr}\toprule';
fprintf(info.fid,'%s \n',h1,h2);

info.fmt = '%10.3f';
info.cnames = strvcat('Gold','Crude Oil','SP500');
info.rnames = strvcat(' ','Mean','Std dev','Skewness','Kurtosis');
lprint_KA(table1,info)

% LaTEX table footer
t1 = '  \bottomrule ';
t2 = '\end{tabular*}  ';
t3 = '\caption{Summary statistics}';
t4 = '\label{tab:sumStat}';
t5 = '\end{table}';
fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5);

% Table 2
table2=nan(3,6);
table2(1,:) = [1 corrcoef12(rets1(:,1:2)) corrcoef12(rets1(:,[1 3])) 1 corrcoef12(empiricalCDF(rets1(:,1:2))) corrcoef12(empiricalCDF(rets1(:,[1 3])))];
table2(2,:) =[corrcoef12(rets1(:,1:2)) 1 corrcoef12(rets1(:,2:3)) corrcoef12(empiricalCDF(rets1(:,1:2))) 1 corrcoef12(empiricalCDF(rets1(:,2:3))) ];
table2(3,:) =[corrcoef12(rets1(:,[1 3])) corrcoef12(rets1(:,2:3)) 1 corrcoef12(empiricalCDF(rets1(:,[1 3]))) corrcoef12(empiricalCDF(rets1(:,2:3))) 1];

% save path+file name
tabName=[save_path,save_name,'table2.tex'];
info.fid=fopen(tabName,'w');

% LaTEX table header
h1 = '\begin{table}';
h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrr}\toprule';
h4 = '& \multicolumn{3}{c}{Linear correlation}& \multicolumn{3}{c}{Rank correlation}\\';
h5 = '\cmidrule{2-4} \cmidrule{5-7}';
fprintf(info.fid,'%s \n',h1,h2,h4,h5);

info.fmt = '%10.3f';
info.cnames = strvcat('Gold','Crude Oil','SP500','Gold','Crude Oil','SP500');
info.rnames = strvcat(' ','Gold','Crude Oil','SP500');
lprint_KA(table2,info)

% LaTEX table footer
t1 = '  \bottomrule ';
t2 = '\end{tabular*}  ';
t3 = '\caption{Linear and rank correlations among returns series.  }';
t4 = '\label{tab:correlations}';
t5 = '\end{table}';
fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5);

% Plot prices and rets1
prices = 100*exp(cumsum(rets1(:,1)/100));
prices(:,2) = 100*exp(cumsum(rets1(:,2)/100));
prices(:,3) = 100*exp(cumsum(rets1(:,3)/100));

fig=figure(101); 
set (fig,'Position',[100 100 700 350],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,prices(:,2),'k-');hold on;
plot(dates,prices(:,3),'r-'),legend('Crude Oil','SP500',2);grid on;
% plot(dates,prices(:,3),'r'),legend('Gold','Crude Oil','SP500',2);grid on;
datetick('x')
title('Prices of Crude Oil and SP500'),hold off;
axis([dates(1) dates(end) 0 100 ])
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'prices.eps'],'psc2') % for loops: saveas (gcf, ['My Figure' ,num2str (i), '.figuretype']);                                                    

pp=1; %Gold-Crude Oil 
fig=figure(102); 
set (fig,'Position',[100 100 600 500],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
plot([-0.05,0.05],[0,0],'k--',[0,0],[-0.05,0.05],'k--','LineWidth',2);hold on;
plot(rets1(:,1),rets1(:,2),'ko'),grid on;
xlabel('Gold return'),ylabel('Crude Oil return'),axis([-0.05,0.05,-0.05,0.05]),title('Daily rets on Gold and Crude Oil');
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'scatterRet',pairs{pp},'.eps'],'psc2') % 

pp=2;
fig=figure(103); 
set (fig,'Position',[100 100 600 500],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
plot([-0.05,0.05],[0,0],'k--',[0,0],[-0.05,0.05],'k--','LineWidth',2);hold on;
plot(rets1(:,1),rets1(:,3),'ko'),grid on;
xlabel('Gold return'),ylabel('SP500 return'),axis([-0.05,0.05,-0.05,0.05]),title('Daily rets on Gold and SP500');
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'scatterRet',pairs{pp},'.eps'],'psc2') % 

pp=3;
fig=figure(104); 
set (fig,'Position',[100 100 600 500],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
plot([-0.05,0.05],[0,0],'k--',[0,0],[-0.05,0.05],'k--','LineWidth',2);hold on;
plot(rets1(:,2),rets1(:,3),'ko'),grid on;
xlabel('Crude Oil return'),ylabel('SP500 return'),axis([-0.05,0.05,-0.05,0.05]),title('Daily rets on Crude Oil and SP500');
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'scatterRet',pairs{pp},'.eps'],'psc2') % 

% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_1.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_1.mat'';'];
evalin('base',temp_str);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OBTAINING MODELS FOR THE CONDITIONAL MEAN AND VARIANCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
% First: conditional mean
resids = nan(T,nIndices);
mean_order = nan(2,nIndices);
tic;
for ii=1:nIndices
    [theta1,sig21,vcv1,order1,resids1] = ARMAX_opt(rets1(:,ii),5,5,'BIC');  % takes about 6 seconds per variable
    mean_order(ii,1:2) = order1';
    mean_order(ii,3) = 1-sig21/cov(rets1(:,ii));
    resids(:,ii) = [zeros(max(order1),1);resids1];
    [ii,toc]
end
toc  % takes 15 seconds for each series
mean_order
% saving the parameters of the optimal model for use in the KS and CvM tests below
ARparams1 = mean(rets1(:,1)); 
ARparams2 = mean(rets1(:,2));
ARtstats=nan(max(1,max(mean_order(:,1))+1),nIndices);

% Get s.e. for mean model
temp1 = ols(rets1(:,1),ones(T,1));
ARtstats(1,1)=temp1.tstat;

temp1 = ols(rets1(:,2),ones(T,1));
ARtstats(1,2)=temp1.tstat;

temp1 = ols(rets1(3:end,3),[ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3)]);
ARparams3 = temp1.beta; 
ARtstats(:,3)=temp1.tstat;

% We test for autocorrelation and cross-correlation after fitting the
% models for mean and variance.
LL = [5;10];
LBpvals = nan(3,length(LL));
for ii=1:3;
        for ll=1:length(LL);
            temp1 = mlag(resids(:,ii),LL(ll));
            temp2 = nwest(resids(LL(ll)+1:end,ii),[ones(T-LL(ll),1),temp1(LL(ll)+1:end,:)]);
            LBpvals(ii,ll) = 1-chi2cdf( temp2.beta(2:end)'*inv(temp2.vcv(2:end,2:end))*temp2.beta(2:end) , LL(ll));
        end      
    figure(220+ii),sacf(resids(:,ii),20);title([ret_str{ii},': LB test p-values for L=5,10 ',num2str(LBpvals(ii,1),'%6.2f'),', ',num2str(LBpvals(ii,2),'%6.2f')]);
end
% There is no evidence of autocorrelation  from optimal models for the mean

% testing for significance of cross-variable lags
% sp500 optimal model is AR(2)

% Gold-Crude Oil up to 5lags
temp = nwest(rets1(:,1),[ones(T,1),mlag(rets1(:,2),5,0)]);
chi2stat = temp.beta'*inv(temp.vcv)*temp.beta
chi2pval = 1-chi2cdf(chi2stat,5)  %  0.47 OK
% Crude Oil-Gold up to 5 lags
temp = nwest(rets1(:,2),[ones(T,1),mlag(rets1(:,1),5,0)]);
chi2stat = temp.beta'*inv(temp.vcv)*temp.beta
chi2pval = 1-chi2cdf(chi2stat,5)  % 0.23 OK! 
% Gold-SP500 up to 5 lags
temp = nwest(rets1(3:end,1),[ones(T-2,1),rets1(2:end-1,1),rets1(1:end-2,1),mlag(rets1(3:end,3),5,0)]);
chi2stat = temp.beta(3:end)'*inv(temp.vcv(3:end,3:end))*temp.beta(3:end)
chi2pval = 1-chi2cdf(chi2stat,5)  % 0.25 OK
% SP500-Gold up to 5 lags
temp = nwest(rets1(3:end,3),[ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3),mlag(rets1(3:end,1),5,0)]);
chi2stat = temp.beta(3:end)'*inv(temp.vcv(3:end,3:end))*temp.beta(3:end)
chi2pval = 1-chi2cdf(chi2stat,5)  % 0.052 maybe not OK
% Crude Oil-SP500 up to 5 lags
temp = nwest(rets1(3:end,2),[ones(T-2,1),rets1(2:end-1,2),rets1(1:end-2,2),mlag(rets1(3:end,3),5,0)]);
chi2stat = temp.beta(3:end)'*inv(temp.vcv(3:end,3:end))*temp.beta(3:end)
chi2pval = 1-chi2cdf(chi2stat,5)  % 0.5 OK
% SP500-Crude Oil up to 5 lags
temp = nwest(rets1(3:end,3),[ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3),mlag(rets1(3:end,2),5,0)]);
chi2stat = temp.beta(3:end)'*inv(temp.vcv(3:end,3:end))*temp.beta(3:end)
chi2pval = 1-chi2cdf(chi2stat,5)  % 0.43 OK

% volatility models
hhat_ALL = nan(T,nIndices);
LogL=nan(2,nIndices);
% Gold GARCH(1,1)-t; Oil and SP500: GJR-GARCH(1,1)-t ; 
GARCHparams=nan(9,nIndices);

for ii=1:nIndices
        data(:,ii)=resids(:,ii)/std(resids(:,ii));
        datarv(:,ii)=rvdata(:,ii)/std(rvdata(:,ii));
        [parameters, LLF00,LLF10,hhat1,sigmau1(ii),u1,summary,tstats] = RealGARCHestimate([data(:,ii) datarv(:,ii)],'SKEWT');
        GARCHparams(:,ii) = parameters;               
        Tstatistics(:,ii)=tstats;
        %summary.RTstats
        hhat_ALL(:,ii)=hhat1;
        LogL(:,ii)=[LLF00; LLF10];
        AIC(ii)=-2*LLF10+2*length(parameters); % caclulating AIC wrt "r" in order to be able to compare with standard GARCH
        BIC(ii)=-2*LLF10+length(parameters)*log(T); % caclulating BIC wrt "r" in order to be able to compare with standard GARCH
end

varResids=var(resids);
resids=data;
stdresids = resids./sqrt(hhat_ALL); %standardize the resids
%GARCHparams=[GARCHparams1 GARCHparams2(1:3) GARCHparams3(1:3)];

table3 = nan(3+9+2,6);
table3(1,1) = ARparams1;
table3(1,3) = ARparams2;
table3(1:3,5) = ARparams3;
table3(1:3,[2 4 6]) = ARtstats;
table3(4:12,[1 3 5]) = GARCHparams;
table3(4:12,[2 4 6]) = Tstatistics;
table3(13:14,[1 3 5])=LogL;
table3(15:16,[1 3 5])=[AIC;BIC];


% save path+file name
tabName=[save_path,save_name,'table3.tex'];

caption = 'Estimated parameters from Realized GARCH(1,1) with innovations distributed \emph{skew-t}. In parenthesis \emph{t}-statistics.';
label = 'condVarModel';
table3Latex(table3,tabName,caption,label)  


for pp=1:size(pair,1);
fig=figure(200+pp); 
set (fig,'Position',[100 100 750 350],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
subplot(1,2,1),plot([-5,5],[0,0],'k--',[0,0],[-5,5],'k--','LineWidth',2);hold on;
plot(rets1(:,pair(pp,1)),rets1(:,pair(pp,2)),'bo'),grid on;
xlabel('Gold return'),ylabel('Crude Oil return'),axis([-5,5,-5,5]),title(['Daily returns on ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)}]);plot([-5,5],[0,0],'k--',[0,0],[-5,5],'k--','LineWidth',2);hold on;
subplot(1,2,2),plot([-5,5],[0,0],'k--',[0,0],[-5,5],'k--','LineWidth',2);hold on;
plot(stdresids(:,pair(pp,1)),stdresids(:,pair(pp,2)),'bo'),grid on;
xlabel('Gold stdresids'),ylabel('Crude Oil stdresids'),axis([-5,5,-5,5]),title(['Daily stdresids on ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)}]);plot([-5,5],[0,0],'k--',[0,0],[-5,5],'k--','LineWidth',2);hold on;
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'scatterRet',pairs{pp},'a.eps'],'psc2') % 
end

%There is NO evidence of cross-correlation.  
% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_2.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_2.mat'';'];
evalin('base',temp_str);

%% Margins models
options = optimset('Algorithm','interior-point','Display','off','TolCon',10^-12,'TolFun',10^-4,'TolX',10^-6,'DiffMaxChange',Inf,'DiffMinChange',0,'UseParallel','always');

% outNormal=fitdist(stdresids(:,1),'normal');
% outNormal=outNormal.Params;
outSKEWT = nan(1,2);  % params
lower = [2.1, -0.99];
upper = [Inf, 0.99 ];
theta0 = [6;0];
tic;
for ii=1:3;
    theta1 = fmincon('skewtdis_LL',theta0,[],[],[],[],lower,upper,[],options,stdresids(:,ii));
    outSKEWT(ii,:) = theta1';
end
toc
outSKEWT

Uedf = empiricalCDF(stdresids);  % prob integral transforms using the empirical cdf
Uparam = nan(T,3);
for ii=1:nIndices;
   
        Uparam(:,ii) = skewtdis_cdf(stdresids(:,ii),outSKEWT(ii,1),outSKEWT(ii,2));
 
end
Uall = Uedf;
Uall(:,:,2) = Uparam;    % so Uall contains nonparam U's first, then Normal and SKEWt U's
size(Uall)

for pp=1:size(pair,1);
fig=figure(310+pp); 
set (fig,'Position',[100 100 500 350],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
scatter(Uparam(:,pair(pp,1)),Uparam(:,pair(pp,2)),'ko');box on;
xlabel(ret_str{pair(pp,1)}),ylabel(ret_str{pair(pp,2)}),title(['Scatter plot of PIT on ',ret_str{pair(pp,1)},' and ',...
 ret_str{pair(pp,2)}]);
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'scatterPIT',pairs{pp},'a.eps'],'psc2') % 
end

% Plot of histogram of returns against fitted density, and QQ plot
fig=figure(301);
set (fig,'PaperUnits','points','Position',[100 100 1150 650],'Color',[1 1 1]) %  
set (gca,'FontSize',14) %
bins=50;
ee = (-5:0.01:5)';
ii=1;[temp1,temp2] = hist(stdresids(:,ii),bins);
subplot(2,3,1),bar(temp2,temp1/(T*(max(stdresids(:,ii))-min(stdresids(:,ii)))/bins),'facecolor',[0.4 0.4 0.4]);hold on;plot(ee,skewtdis_pdf(ee,outSKEWT(ii,1),outSKEWT(ii,2)),'r','LineWidth',2),title('Gold'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skewed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;
ii=2;[temp1,temp2] = hist(stdresids(:,ii),bins);
subplot(2,3,2),bar(temp2,temp1/(T*(max(stdresids(:,ii))-min(stdresids(:,ii)))/bins),'facecolor',[0.4 0.4 0.4]);hold on;plot(ee,skewtdis_pdf(ee,outSKEWT(ii,1),outSKEWT(ii,2)),'r-','LineWidth',2),title('Crude Oil'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skewed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;
ii=3;[temp1,temp2] = hist(stdresids(:,ii),bins);
subplot(2,3,3),bar(temp2,temp1/(T*(max(stdresids(:,ii))-min(stdresids(:,ii)))/bins),'facecolor',[0.4 0.4 0.4]);hold on;plot(ee,skewtdis_pdf(ee,outSKEWT(ii,1),outSKEWT(ii,2)),'r-','LineWidth',2),title('SP500'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skewed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;

ii=1;qq = sort(empiricalCDF(stdresids(:,ii)));
subplot(2,3,4),plot(skewtdis_inv(qq,outSKEWT(ii,1),outSKEWT(ii,2)),sort(stdresids(:,ii)),'ko');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;
ii=2;qq = sort(empiricalCDF(stdresids(:,ii)));
subplot(2,3,5),plot(skewtdis_inv(qq,outSKEWT(ii,1),outSKEWT(ii,2)),sort(stdresids(:,ii)),'ko');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;
ii=3;qq = sort(empiricalCDF(stdresids(:,ii)));
subplot(2,3,6),plot(skewtdis_inv(qq,outSKEWT(ii,1),outSKEWT(ii,2)),sort(stdresids(:,ii)),'ko');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;

set (gcf, 'PaperUnits','inches','PaperPosition',[0.05 0.15 11.5 7],'PaperSize',[8 4],'PaperOrientation','landscape')   % Use screen size
saveas (gcf,[save_path,save_name,'fittedMarginModels.eps'],'psc2') % 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% implementing a PEE-adjusted KS and CvM test for these three density models

% test statistics
KSstat1  = max(abs(sort(Uparam(:,1)) - (1:T)'/T))
CvMstat1 = sum(  (sort(Uparam(:,1)) - (1:T)'/T).^2 )
KSstat2  = max(abs(sort(Uparam(:,2)) - (1:T)'/T))
CvMstat2 = sum(  (sort(Uparam(:,2)) - (1:T)'/T).^2 )
KSstat3  = max(abs(sort(Uparam(:,3)) - (1:T)'/T))
CvMstat3 = sum(  (sort(Uparam(:,3)) - (1:T)'/T).^2 )
    
% using a simulation method to get critical values that account for parameter estimation error (PEE)
% WARNING: THIS PART IS PRETTY SLOW

reps=10; % at least 1000
tic;
parfor r=1:reps
out1a(r,:) = mydist_test_PEErealGARCH(T,ARparams1,GARCHparams(:,1),outSKEWT(1,:)',[],sigmau1(1),varResids(1),'STUDENTST');
end
toc
tic;
parfor r=1:reps
out1b(r,:) = mydist_test_PEErealGARCH(T,ARparams2,GARCHparams(:,2),outSKEWT(2,:)',[],sigmau1(2),varResids(2),'STUDENTST');
end
toc
tic;
parfor r=1:reps
out1c(r,:) = mydist_test_PEErealGARCH(T,ARparams3,GARCHparams(:,3),outSKEWT(3,:)',[],sigmau1(3),varResids(3),'STUDENTST');
end
toc

KSpval1 = mean(out1a(:,1)>=KSstat1)  % 0.276
CvMpval1 = mean(out1a(:,2)>=CvMstat1)  %  0.071
KSpval2 = mean(out1b(:,1)>=KSstat2)  %      0.608
CvMpval2 = mean(out1b(:,2)>=CvMstat2)  %      0.765
KSpval3 = mean(out1c(:,1)>=KSstat3)  %      0.975
CvMpval3 = mean(out1c(:,2)>=CvMstat3)  %      0.93

table4 = nan(2+2,nIndices); 
table4(1:2,:) =  outSKEWT';
table4(3:4,:) = [[KSpval1;CvMpval1],[KSpval2;CvMpval2],[KSpval3;CvMpval3]];

% save path+file name
tabName=[save_path,save_name,'table4.tex'];
info.fid=fopen(tabName,'w');

% LaTEX table header
h1 = '\begin{table}';
h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrr}\toprule';
fprintf(info.fid,'%s \n',h1,h2);

info.fmt = '%10.3f';
info.cnames = strvcat('Gold','Crude Oil','SP500');
info.rnames = strvcat(' ','$\nu$','$\lambda$','KS pval','CvM pval')
lprint_KA(table4,info)

% LaTEX table footer
t1 = '  \bottomrule ';
t2 = '\end{tabular*}  ';
t3 = '\caption{Model for the margins. Skew t density parameters and p-values for testing $H_0$: the data';
t4=[' comes from the specified distribution. Results are based on ',num2str(reps),' simulations.}'];
t5 = '\label{tab:marginsRGARCH}';
t6 = '\end{table}';
fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5,t6);


% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_3.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_3.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEPENDENCE SUMMARY STATISTICS 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% rank correlation and quantile dependence for each pair
inc = 0.025;
QQ = (inc:inc:1-inc)';
QQ2 = [(inc:inc:0.5)';(0.5:inc:1-inc)'];
bootreps=1000;

for pp=1:size(pair,1)
tic;[rhoShat(pp,:)] = rankcorrel(stdresids(:,pair(pp,:)),0.1,bootreps);toc  % 0.5 seconds for bootreps=1000
rhoShat(pp,:)'  % estimate and 90% confidence interval bounds
tic;[out1qq(:,:,pp),out2qq(:,:,pp),out3qq(:,:,pp)] = quantiledep(stdresids(:,pair(pp,1)),stdresids(:,pair(pp,2)),QQ,bootreps);toc % takes 2.83 seconds for bootreps=1000
fig=figure(400+pp);
set (fig,'Position',[100 100 650 700],'Color',[1 1 1]) %  
set (gca,'FontSize',14) %
subplot(2,1,1),plot(QQ2,out1qq(:,1,pp),'bo-',QQ2,out1qq(:,1,pp)+1.645*out1qq(:,2,pp),'r--',QQ2,out1qq(:,1,pp)-1.645*out1qq(:,2,pp),'r--','LineWidth',2)
    legend('quantile dep','90% CI'),xlabel('Quantile (q)'),ylabel('Quantile dep'),title(['Quantile dependence for ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)},' std resids']),...
    xlabel('quantile (q)');grid on;
temp = eye(length(QQ2)/2);
R = [-temp,temp(:,end:-1:1)];  % gives me upper tail minus lower tail, from smallest quantile to 0.5
temp2 = sqrt(diag(R*out2qq(:,:,pp)*R'));
subplot(2,1,2),plot(QQ2(1:end/2),R*out1qq(:,1,pp),'bo-',QQ2(1:end/2),R*out1qq(:,1,pp)+1.645*temp2,'r--',QQ2(1:end/2),R*out1qq(:,1,pp)-1.645*temp2,'r--','LineWidth',2);hold on;
plot([0,0.5],[0,0],'k--'),...
    title('Difference in upper and lower quantile dependence'),ylabel('Upper minus lower'),xlabel('quantile (q)'),legend('Estimate','90% CI',4);grid on; 
end

bootreps = 1000;
alpha=0.10;
tic;
for pp=1:size(pair,1)
[tauLUhjs(:,:,pp), ~, tauBOOThjs(:,:,pp)] = nonparam_tail_dep(Uedf(:,pair(pp,:)),[],bootreps,alpha,1);
fprintf(['Non-parmetric tail dependence estimates for ',pairs{pp},'\n'])
fprintf('Lower tail %4.4f  LB %4.4f   UB   %4.4f \n',tauLUhjs(:,1,pp)')  
fprintf('Upper tail %4.4f  LB %4.4f   UB   %4.4f \n',tauLUhjs(:,2,pp)')  

% testing for difference in upper and lower tail dep
A1(pp,:)=[tauLUhjs(1,2,pp)-tauLUhjs(1,1,pp),quantile(tauBOOThjs(:,2,pp)-tauBOOThjs(:,1,pp),[0.05,0.95])];  %  
fprintf('U-L %4.4f, U-L bootstrap estimates quantiles: 0.05=> %4.4f, 0.95=> %4.4f \n',A1(pp,:)) 
fprintf('t-stat %4.2f \n',(tauLUhjs(1,2,pp)-tauLUhjs(1,1,pp))/std(tauBOOThjs(:,2,pp)-tauBOOThjs(:,1,pp)))  % -0.7954
fprintf(['Testing H0: tail dep is equal for ',pairs{pp},' \n'])
fprintf('Bootstrap p-value= %2.2f \n',mean((tauLUhjs(1,2,pp)-tauLUhjs(1,1,pp))<(tauBOOThjs(:,2,pp)-tauBOOThjs(:,1,pp))))  % 0.595
end
toc  % takes 32 seconds for bootreps=1000

% now creating new figure using this estimate of tail dep
for pp=1:size(pair,1)
    fig=figure(410+pp);
    set (fig,'Position',[100 100 650 700],'Color',[1 1 1]) %
    set (gca,'FontSize',14) %
    subplot(2,1,1),plot(QQ2,out1qq(:,1,pp),'ko-',QQ2,out1qq(:,1,pp)+1.645*out1qq(:,2,pp),'r--','LineWidth',2); hold on
    plot([0,0],tauLUhjs(1,1,pp)*ones(1,2),'kp',[0,min(QQ2)],[tauLUhjs(1,1,pp),out1qq(1,1,pp)],'k:','LineWidth',2)
    plot([1,1],tauLUhjs(1,2,pp)*ones(1,2),'kp',[max(QQ2),1],[out1qq(end,1,pp),tauLUhjs(1,2,pp)],'k:','LineWidth',2)
    plot([0,min(QQ2)],[tauLUhjs(3,1,pp),out1qq(1,1,pp)+1.645*out1qq(1,2,pp)],'b:','LineWidth',2)
    plot([0,min(QQ2)],[tauLUhjs(2,1,pp),out1qq(1,1,pp)-1.645*out1qq(1,2,pp)],'b:','LineWidth',2)
    plot([max(QQ2),1],[out1qq(end,1,pp)+1.645*out1qq(end,2,pp),tauLUhjs(3,2,pp)],'b:','LineWidth',2)
    plot([max(QQ2),1],[out1qq(end,1,pp)-1.645*out1qq(end,2,pp),tauLUhjs(2,2,pp)],'b:','LineWidth',2)
    plot(QQ2,out1qq(:,1,pp)-1.645*out1qq(:,2,pp),'r--','LineWidth',2)
    legend('quantile dep','90% CI',3),xlabel('Quantile (q)'),ylabel('Quantile dep'),title(['Quantile dependence for ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)},' std resids']),...
        xlabel('quantile (q)');grid on;hold off;
    temp = eye(length(QQ2)/2);
    R = [-temp,temp(:,end:-1:1)];  % gives me upper tail minus lower tail, from smallest quantile to 0.5
    temp1 = R*out1qq(:,1,pp);
    temp2 = sqrt(diag(R*out2qq(:,:,pp)*R'));
    subplot(2,1,2),plot(QQ2(1:end/2),temp1,'ko-',QQ2(1:end/2),temp1+1.645*temp2,'r--',...
        [0,0],(tauLUhjs(1,2,pp)-tauLUhjs(1,1,pp))*ones(2,1),'kp',[0,min(QQ2)],[(tauLUhjs(1,2,pp)-tauLUhjs(1,1,pp)),temp1(1)],'k:',...
        [0,min(QQ2)],[quantile(tauBOOThjs(:,2,pp)-tauBOOThjs(:,1,pp),0.95),temp1(1)+1.645*temp2(1)],'b:',...
        [0,min(QQ2)],[quantile(tauBOOThjs(:,2,pp)-tauBOOThjs(:,1,pp),0.05),temp1(1)-1.645*temp2(1)],'b:',...
        QQ2(1:end/2),temp1-1.645*temp2,'r--','LineWidth',2);grid on;hold on;
    plot([0,0.5],[0,0],'k--'),...
        title('Difference in upper and lower quantile dependence'),ylabel('Upper minus lower'),xlabel('quantile (q)')
    legend('Estimate','90% CI',4);grid on;hold off;
    set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
    saveas (gcf,[save_path,'quantileDepNonParam',pairs{pp},'.eps'],'psc2') %
end

qstar = 0.025;
clear tauLhat tauUhat thetahatLhat thetahatUhat nobs outboot % dimension mismatch from previous steps.
bootreps=4; % change to 100
tic;
for pp=1:size(pair,1)
    [tauLhat(pp,:),tauUhat(pp,:),thetahatLhat,thetahatUhat,nobs,outboot(:,:,pp)] = tail_copula_Gumbel(Uedf(:,pair(pp,:)),qstar,bootreps);  % takes 36 seconds for bootreps=100. takes ?? seconds for bootreps=1000
    [tauLhat(pp,:),quantile(outboot(:,1,pp),[0.05,0.95])]  %      0.3839    0.3045    0.4608
    [tauUhat(pp,:),quantile(outboot(:,2,pp),[0.05,0.95])]  %      0.2098    0.1527    0.2712
    mean( abs(tauUhat(pp,:)-tauLhat(pp,:))>=abs(outboot(:,2,pp)-outboot(:,1,pp)) )  % 0.410 => fail to reject null that tail dep is equal
end
toc;


clear tauLhat tauUhat thetahatLhat thetahatUhat nobs outboot % dimension mismatch from previous steps.
bootreps=4; % change to 100
tic;
for pp=1:size(pair,1)
    [tauLhat(pp,:),tauUhat(pp,:),thetahatLhat(:,pp),thetahatUhat(:,pp),nobs,outboot(:,:,pp)] = tail_copula_t(Uedf(:,pair(pp,:)),qstar,bootreps);  % takes 1.24 hours for bootreps=100. SLOW!
    [tauLhat(pp,:),quantile(outboot(:,1,pp),[0.05,0.95])]  %          0.2657    0.2213    0.3489
    [tauUhat(pp,:),quantile(outboot(:,2,pp),[0.05,0.95])]  %        0.1491    0.0813    0.1698
    mean( abs(tauUhat(pp,:)-tauLhat(pp,:))>=abs(outboot(:,2,pp)-outboot(:,1,pp)) )  % 0.230 => fail to reject null that tail dep is equal
end

% tail dependence based on parametric copulas
QQ = (0.02:0.02:0.1)';
QQ = (0.005:0.005:0.2)';
% tauSKEWT = nan(length(QQ),6);
% tic;
% for pp=1:size(pair,1)
%     for qq=1:length(QQ);
%         [tauL,tauU,thetahatL,thetahatU,nobs] = tail_copula_Gumbel(Uparam(:,pair(pp,:)),QQ(qq));
%         tauSKEWT(qq,:,pp) = [tauL,tauU,thetahatL,thetahatU,nobs];
%         [qq,toc]
%     end
% end
% toc  % takes 14 seconds for length(QQ)=40
% [QQ,tauSKEWT(:,:,pp)]
% figure(123423),plot(QQ,tauSKEWT(:,1:2,pp),'o-'),legend('lower tail','upper tail',2),xlabel('quantile (q)'),ylabel('tail dependence'),title('Estimated tail dependence using Gumbel tail copula');
% % clear drift in estimate as we use more obs from the centre of the dist'n. similar to hill estimator. flat spot not immediately obvious, but appears
% % to be around 0.015 to 0.03 for lower tail, and around 0.025 to 0.035 for upper tail. Let's use 0.025 as that is in both ranges
% 
% qstar=0.025;
% for pp=1:size(pair,1)
%     tauLhat(pp,:) = tauSKEWT( (QQ==qstar), 1,pp)  %  0.38948
%     tauUhat(pp,:) = tauSKEWT( (QQ==qstar), 2,pp)  %  0.26853
%     thetaLhat(:,pp) = tauSKEWT( (QQ==qstar), 3,pp) %  1.4545
%     thetaUhat(:,pp) = tauSKEWT( (QQ==qstar), 4,pp)  %  1.2626
% end
% 
% bootreps=100;
% for pp=1:size(pair,1)
%     tic;[tauLhat(pp,:),tauUhat(pp,:),thetahatLhat(:,pp),thetahatUhat(:,pp),nobs,outboot(:,:,pp)] = tail_copula_Gumbel(Uparam(:,pair(pp,:)),qstar,bootreps);toc  % takes 36 seconds for bootreps=100. takes ?? seconds for bootreps=1000
%     [tauLhat(pp,:),quantile(outboot(:,1,pp),[0.05,0.95])]  %     0.3895    0.3213    0.4568
%     [tauUhat(pp,:),quantile(outboot(:,2,pp),[0.05,0.95])]  %     0.2685    0.1853    0.3543
% end
% 
% for pp=1:size(pair,1)
%     tic;[tauLhat(pp,:),tauUhat(pp,:),thetahatLhat(:,pp),thetahatUhat(:,pp),nobs,outboot(:,:,pp)] = tail_copula_Gumbel(Uedf(:,pair(pp,:)),qstar,bootreps);toc  % takes 36 seconds for bootreps=100. takes ?? seconds for bootreps=1000
%     [tauLhat(pp,:),quantile(outboot(:,1,pp),[0.05,0.95])]  %     0.3895    0.3213    0.4568
%     [tauUhat(pp,:),quantile(outboot(:,2,pp),[0.05,0.95])]  %     0.2685    0.1853    0.3543
% end

qstar = 0.025;
bootreps=4; % change to 100
clear outboot % dimension mismatch from previous steps.
tic;
for pp=1:size(pair,1)
    [tauLhat(pp,:),tauUhat(pp,:),thetahatLhat(:,pp),thetahatUhat(:,pp),nobs,outboot(:,:,pp)] = tail_copula_t(Uparam(:,pair(pp,:)),qstar,bootreps);  % takes 1.24 hours for bootreps=100. SLOW!
    fprintf('Lower tail %4.4f  LB %4.4f   UB   %4.4f \n',[tauLhat(pp,:),quantile(outboot(:,1,pp),[0.05,0.95])])  %          0.2657    0.2213    0.3489
    fprintf('Upper tail %4.4f  LB %4.4f   UB   %4.4f \n',[tauUhat(pp,:),quantile(outboot(:,2,pp),[0.05,0.95])])  %        0.1491    0.0813    0.1698
    fprintf(['t-copula tail dependence estimates for ',pairs{pp},'\n'])
    fprintf(['Testing H0: tail dep is equal for ',pairs{pp},' \n'])
    fprintf('Bootstrap p-value= %2.2f \n',mean( abs(tauUhat(pp,:)-tauLhat(pp,:))>=abs(outboot(:,2,pp)-outboot(:,1,pp))) )  % 0.230 => fail to reject null that tail dep is equal
end


for pp=1:size(pair,1)
    fig=figure(13101+pp);
    set (fig,'Position',[100 100 650 700],'Color',[1 1 1]) %
    set (gca,'FontSize',14) %
    subplot(2,1,1),plot(QQ2,out1qq(:,1,pp),'ko-',QQ2,out1qq(:,1,pp)+1.645*out1qq(:,2,pp),'r--','LineWidth',2); hold on;
        plot([0,0],tauLhat(pp,:)*ones(1,2),'kp',[0,min(QQ2)],[tauLhat(pp,:),out1qq(1,1,pp)],'k:','LineWidth',2)
        plot([1,1],tauUhat(pp,:)*ones(1,2),'kp',[max(QQ2),1],[out1qq(end,1,pp),tauUhat(pp,:)],'k:','LineWidth',2)
        plot([0,min(QQ2)],[quantile(outboot(:,1,pp),0.95),out1qq(1,1,pp)+1.645*out1qq(1,2,pp)],'b:','LineWidth',2)
        plot([0,min(QQ2)],[quantile(outboot(:,1,pp),0.05),out1qq(1,1,pp)-1.645*out1qq(1,2,pp)],'b:','LineWidth',2)
        plot([max(QQ2),1],[out1qq(end,1,pp)+1.645*out1qq(end,2,pp),quantile(outboot(:,2,pp),0.95)],'b:','LineWidth',2)
        plot([max(QQ2),1],[out1qq(end,1,pp)-1.645*out1qq(end,2,pp),quantile(outboot(:,2,pp),0.05)],'b:','LineWidth',2)
        plot(QQ2,out1qq(:,1,pp)-1.645*out1qq(:,2,pp),'r--','LineWidth',2)
        legend('quantile dep','90% CI',3),xlabel('Quantile (q)'),ylabel('Quantile dep'),title(['Quantile dependence for ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)},' std resids']),...
        xlabel('quantile (q)');grid on;
    temp = eye(length(QQ2)/2);
    R = [-temp,temp(:,end:-1:1)];  % gives me upper tail minus lower tail, from smallest quantile to 0.5
    temp1 = R*out1qq(:,1,pp);
    temp2 = sqrt(diag(R*out2qq(:,:,pp)*R'));
    subplot(2,1,2),plot(QQ2(1:end/2),temp1,'ko-',QQ2(1:end/2),temp1+1.645*temp2,'r--',...
        [0,0],(tauUhat(pp,:)-tauLhat(pp,:))*ones(2,1),'kp',[0,min(QQ2)],[(tauUhat(pp,:)-tauLhat(pp,:)),temp1(1)],'b:',...
        [0,min(QQ2)],[quantile(outboot(:,2,pp)-outboot(:,1,pp),0.95),temp1(1)+1.645*temp2(1)],'b:',...
        [0,min(QQ2)],[quantile(outboot(:,2,pp)-outboot(:,1,pp),0.05),temp1(1)-1.645*temp2(1)],'b:',...
        QQ2(1:end/2),temp1-1.645*temp2,'r--','LineWidth',2);grid on;hold on;
    plot([0,0.5],[0,0],'k--'),...
 title('Difference in upper and lower quantile dependence'),ylabel('Upper minus lower'),xlabel('quantile (q)')
    legend('Estimate','90% CI',4);grid on;hold off;
    set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
    saveas (gcf,[save_path,'quantileDepParam',pairs{pp},'.eps'],'psc2') %
end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% testing for asymmetric dependence 

bootreps=1000;
QQ3 = [0.025;0.05;0.10];
QQ3 = [QQ3;sort(1-QQ3)]

% test all pairs
for pp=1:size(pair,1)
[out1a,out2a] = quantiledep(stdresids(:,pair(pp,1)),stdresids(:,pair(pp,2)),QQ3,bootreps);
temp = eye(length(QQ3)/2);
R = [-temp,temp(:,end:-1:1)];  % gives me upper tail minus lower tail, from smallest quantile to 0.5
chi2stat = (R*out1a(:,1))'*inv(R*out2a*R')*R*out1a(:,1);  %     1.0928
chi2pval = 1-chi2cdf(chi2stat,length(QQ3)/2);  % 0.77
fprintf(['Testing H0: dependence structure is symmetric for pair ',pairs{pp},'\n'])
fprintf('Chi2 statistics= %4.2f and p-value= %2.2f \n',chi2stat,chi2pval)
% so not significantly different.
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% rolling window rank correlations

rolling_rank_correl = nan(T,3,nIndices);
window = 60;
bootreps=100;
tic;
for pp=1:size(pair,1); % consider the 3 pair combinations
          for tt=window:T;
           out1a = rankcorrel([stdresids(tt-window+1:tt,pair(pp,1)),stdresids(tt-window+1:tt,pair(pp,2))],0.1,bootreps);
           rolling_rank_correl(tt,:,pp) = out1a(1:3)';
          end
end
toc  % takes 127 seconds for bootreps=100

temp124 = ~isnan(rolling_rank_correl(:,1,1));
for pp=1:size(pair,1); % consider the 3 pair combinations
fig=figure(403+pp);
set (fig,'Position',[100 100 600 500],'Color',[1 1 1]) %  
set (gca,'FontSize',16) %
plot(dates,rolling_rank_correl(:,1,pp)','r-');hold on;
jbfill(dates(temp124)',rolling_rank_correl(temp124,2,pp)',rolling_rank_correl(temp124,3,pp)','k','k',[],0.2);hold on;
plot(dates,zeros(T,1),'k--') 
title(['60-day rolling rank correlation for ',ret_str{pair(pp,1)},' and ',ret_str{pair(pp,2)},' std resids']),legend('Rank correl','90% CI',4);grid on;hold off;
datetick('x')
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,'rollingRankCorr',pairs{pp},'.eps'],'psc2') % 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% testing for time-varying dependence
bootreps=1000;
tic;
fprintf('Testing H0: the alpha_i=0 for all i>=1 \n')
for pp=1:size(pair,1); % consider the 3 pair combinations
pval1(pp) = AR_test_rank_correl(Uedf(:,pair(pp,:)),1,bootreps);
pval2(pp) = AR_test_rank_correl(Uedf(:,pair(pp,:)),5,bootreps); 
pval3(pp) = AR_test_rank_correl(Uedf(:,pair(pp,:)),10,bootreps); 
end
toc
% takes 3.4 seconds for bootreps=1000
% save path+file name
tabName=[save_path,save_name,'table5.tex'];
info.fid=fopen(tabName,'w');

% LaTEX table header
h1 = '\begin{table}';
h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrr}\toprule';
fprintf(info.fid,'%s \n',h1,h2);

table5 = [pval1',pval2',pval3'];
info.fmt = '%10.3f';
info.cnames = strvcat('AR(1)','AR(5)','AR(10)')
info.rnames = strvcat(' ','Gold-Crude Oil',  'Gold-SP500', 'Crude Oil-SP500')
lprint_KA(table5,info)

% LaTEX table footer
t1 = '  \bottomrule ';
t2 = '\end{tabular*}  ';
t3 = '\caption{Tests for time-varying dependence (p-values).}';
t4 = '\label{tab:tvTests}';
t5 = '\end{table}';
fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5);



% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_4.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_4.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ESTIMATING CONSTANT COPULAS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

options = optimset('Algorithm','interior-point','Display','off','TolCon',10^-12,'TolFun',10^-6,'TolX',10^-6,'DiffMaxChange',Inf,'DiffMinChange',0);

thetaALL = nan(9,2,2);   % [ copula model] ; [parameters ] ;[EDF or SKEWT marginal dist]
LLALL = nan(9,2);   % [ copula model] ; [EDF or SKEWT marginal dist]
tauLUall = nan(9,2,2);
table7 = nan(7*2,4+4,size(pair,1));% storing the parameter estimates and std errors for Normal, Clayton, Rot Gumbel, SJC and Stud t

tic;
for pp=1:size(pair,1); % consider the 3 pair combinations
    for uu=1:2;  % uu=1 uses EDF for marginals, uu=2 uses SKEWT marginal dist
        if uu==1
            fprintf(['Empirical cdf, pair ',pairs{pp},'\n'])
        else
            fprintf(['Parametric cdf, pair ',pairs{pp},'\n'])
        end
        u= Uall(:,pair(pp,1),uu);
        v= Uall(:,pair(pp,2),uu);

        % 1. Normal Copula
        kappa1 = corrcoef12(norminv(u),norminv(v));
        LL1 = NormalCopula_CL(kappa1,[u,v]);
        thetaALL(1,1,uu,pp) = kappa1;

        % 2. Clayton's copula
        lower = 0.0001;
        theta0 = 1;
        [ kappa2 LL2] = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
        thetaALL(2,1,uu,pp) = kappa2;

        % 3. Rotated Clayton copula (with tail dep in upper tail instead of lower)
        lower = 0.0001;
        theta0 = 1;
        [ kappa3 LL3] = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,1-[u,v]);
        thetaALL(3,1,uu,pp) = kappa3;

        % 4. Plackett copula
        lower = 0.0001;
        theta0 = 1;
        [ kappa4 LL4] = fmincon('plackettCL',theta0,[],[],[],[],lower,[],[],options,[u,v]);
        thetaALL(4,1,uu,pp) = kappa4;

        % 5. Frank copula
        lower = 0.0001;
        upper = 9;  % need to put some loose upper bound here as LL goes to NaN when theta gets too big
        theta0 = 1;
        [ kappa5 LL5] = fmincon('frankCL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
        thetaALL(5,1,uu,pp) = kappa5;

        % 6. Gumbel copula
        lower = 1.1;
        upper = 5;
        theta0 = 2;
        [ kappa6 LL6] = fmincon('gumbelCL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
        thetaALL(6,1,uu,pp) = kappa6;

        % 7. Rotated Gumbel copula
        lower = 1.1;
        upper = 5;
        theta0 = 2;
        [ kappa7 LL7] = fmincon('gumbelCL',theta0,[],[],[],[],lower,upper,[],options,1-[u,v]);
        thetaALL(7,1,uu,pp) = kappa7;

        % 8. Student's t copula  (estimating nu_inv rather than nu)
        lower = [-0.9 , 1/100 ];
        upper = [ 0.9 , 1/2.1 ];
        theta0 = [kappa1;10];
        [ kappa8 LL8] = fmincon('tcopulaCL2',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
        thetaALL(8,1:2,uu,pp) = kappa8;

        % 9. Symmetrised Joe-Clayton copula
        lower = [0 , 0 ];
        upper = [ 1 , 1];
        theta0 = [0.4;0.4];
        [ kappa9 LL9] = fmincon('sym_jc_CL',theta0,[],[],[],[],lower,upper,[],options,[u,v]);
        thetaALL(9,1:2,uu,pp) = kappa9([2,1]);  % putting tauL before tauU

        LLALL(:,uu,pp) = -[LL1;LL2;LL3;LL4;LL5;LL6;LL7;LL8;LL9];
        opt_copula = find(LLALL(:,uu,pp)==max(LLALL(:,uu,pp)))

        % tail dependence implied by each of these copulas
        tauLUall(1,:,uu,pp) = [0,0];                 % Normal copula has zero tail dependence
        tauLUall(2,:,uu,pp) = [2^(-1/kappa2),0];     % Clayton copula has zero upper tail dependence
        tauLUall(3,:,uu,pp) = [0,2^(-1/kappa3)];     % Rotated Clayton copula has zero lower tail dependence
        tauLUall(4,:,uu,pp) = [0,0];                 % Plackett copula has zero tail dependence
        tauLUall(5,:,uu,pp) = [0,0];                 % Frank copula has zero tail dependence
        tauLUall(6,:,uu,pp) = [0,2-2^(1/kappa6)];    % Gumbel copula has zero lower tail dependence
        tauLUall(7,:,uu,pp) = [2-2^(1/kappa7),0];    % Rotated Gumbel copula has zero upper tail dependence
        tauLUall(8,:,uu,pp) = ones(1,2)*2*tdis_cdf(-sqrt((kappa8(2)+1)*(1-kappa8(1))/(1+kappa8(1))),kappa8(2)+1);  % Student's t copula has symmetric tail dependence
        tauLUall(9,:,uu,pp) = kappa9([2,1])';               % SJC copula parameters are the tail dependence coefficients, but in reverse order.
    
        % storing the parameter estimates and std errors for Normal, Clayton, Rot Gumbel, and Stud t
        table7(1,-4*(uu-1)+6,pp)  = thetaALL(1,1,uu,pp); % Normal
        table7(3,-4*(uu-1)+6,pp)  = thetaALL(2,1,uu,pp); % Clayton
        table7(5,-4*(uu-1)+6,pp)  = thetaALL(7,1,uu,pp); % Rot Gumbel
        table7(7,-4*(uu-1)+6,pp)  = thetaALL(8,1,uu,pp); % t- rho
        table7(9,-4*(uu-1)+6,pp)  = thetaALL(8,2,uu,pp); % t - nu
        table7(11,-4*(uu-1)+6,pp)  = thetaALL(9,1,uu,pp); % SJC tauL
        table7(13,-4*(uu-1)+6,pp)  = thetaALL(9,2,uu,pp); % SJC tauU     
    end
    LLALL
    tauLUall
    LLALLranks = ranks(LLALL(:,:,pp))

    table6 = nan(9,3+3);
    table6(:,[3,6]) = LLALL([1:7,9,8],[2,1],pp);
    table6(:,1:2) = thetaALL([1:7,9,8],1:2,2,pp);
    table6(:,4:5) = thetaALL([1:7,9,8],1:2,1,pp);
   
    % save path+file name
    tabName=[save_path,save_name,'table6',pairs{pp},'.tex'];
    info.fid=fopen(tabName,'w');
    
    % LaTEX table header
    h1 = '\begin{table}';
    h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrr}\toprule';
    h3 = ['& \multicolumn{6}{c}{',pairs{pp},'} \\ '];
    h4 = '& \multicolumn{3}{c}{Parametric}& \multicolumn{3}{c}{Semiparametric}\\';
    h5 = '\cmidrule{2-4} \cmidrule{5-7}';
    fprintf(info.fid,'%s \n',h1,h2,h3,h4,h5);
    
    % Body of the table
    info.fmt = strvcat('%10.3f','%10.3f','%10.1f','%10.3f','%10.3f','%10.1f');
    info.cnames = strvcat('param1','param2','$\mathcal{LL}$','param1','param2','$\mathcal{LL}$');
    info.rnames = strvcat(' ','Normal','Clayton','Rot Clayton','Plackett','Frank','Gumbel','Rot Gumbel','SJC','Student''s t');
    lprint_KA(table6,info)
    
    % LaTEX table footer
    t1 = '  \bottomrule ';
    t2 = '\end{tabular*}  ';
    t3 = ['\caption{Constant copula model parameter estimates for ',pairs{pp},'}'];
    t4 = ['\label{tab:consCopulaParam',pairs{pp},'}'];
    t5 = '\end{table}';
    fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5);
    
end
toc  % takes 108 seconds for 2 pairs and 2 types of U variables, so around 60 seconds per pair


% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_5.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_5.mat'';'];
evalin('base',temp_str);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD ERRORS FOR CONSTANT COPULAS - PARAMETRIC CASE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bootstrap std errors for two-stage param estimator

% WARNING: THIS PART IS VERY SLOW
bootreps = 4; % this should be at least 100, and better if it is 1000
block_length = 10; % empirically accepted choice of b for the moving block method is 10 see. Leger,Politis and Romano (1992).
bootdates = stat_bootstrap_function_21(T,bootreps,block_length);
kappa12boot = nan(bootreps,1+1+1+2+2);
tic;
for bb=1:bootreps
    rets1boot(:,:,bb) = rets1(bootdates(:,bb),:);
    rvdataboot(:,:,bb)=rvdata(bootdates(:,bb),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARALLEL COMPUTING HERE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parfor_progress(bootreps);
parfor bb=1:bootreps
    [~,~,~,resids_1boot(:,bb)] = ARMAX_2(rets1boot(:,1,bb),0,0);
    [~,~,~,resids_2boot(:,bb)] = ARMAX_2(rets1boot(:,2,bb),0,0);
    [~,~,~,resids_3boot(:,bb)] = ARMAX_2(rets1boot(:,3,bb),2,0);
    
    resids_1boot(:,bb)=resids_1boot(:,bb)/std(resids_1boot(:,bb));
    resids_2boot(:,bb)=resids_2boot(:,bb)/std(resids_2boot(:,bb));
    resids_3boot(:,bb)=resids_3boot(:,bb)/std( resids_3boot(:,bb));
    
    rvdataboot1(:,bb)=rvdataboot(:,1,bb)/std(rvdataboot(:,1,bb));
    rvdataboot2(:,bb)=rvdataboot(:,2,bb)/std(rvdataboot(:,2,bb));
    rvdataboot3(:,bb)=rvdataboot(:,3,bb)/std(rvdataboot(:,3,bb));

    [~, ~,~,hhat1boot(:,bb),~,~,~] = RealGARCHestimate([resids_1boot(:,bb) rvdataboot1(:,bb)],'SKEWT');
    [~, ~,~,hhat2boot(:,bb),~,~,~] = RealGARCHestimate([resids_2boot(:,bb) rvdataboot2(:,bb)],'SKEWT');
    [~, ~,~,hhat3boot(:,bb),~,~,~] = RealGARCHestimate([[zeros(2,1);resids_3boot(:,bb)] rvdataboot3(:,bb)],'SKEWT');
        
    stdresids1(:,bb) = resids_1boot (:,bb)./sqrt(hhat1boot(:,bb));
    stdresids2(:,bb) = resids_2boot (:,bb)./sqrt(hhat2boot(:,bb));
    stdresids3(:,bb) = [zeros(2,1);resids_3boot(:,bb)]./sqrt(hhat3boot(:,bb));
    
    lower = [2.1, -0.99]; upper = [Inf, 0.99 ];
    %warning off;
    skewt1boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (1,:)',[],[],[],[],lower,upper,[],options,stdresids1(:,bb));
    %warning off;
    skewt2boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (2,:)',[],[],[],[],lower,upper,[],options,stdresids2(:,bb));
    skewt3boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (3,:)',[],[],[],[],lower,upper,[],options,stdresids3(:,bb));
    parfor_progress;
end
parfor_progress(0);

 for bb=1:bootreps
    Uskewt1(:,bb) = skewtdis_cdf(stdresids1(:,bb),skewt1boot(1,bb),skewt1boot(2,bb));
    Uskewt2(:,bb) = skewtdis_cdf(stdresids2(:,bb),skewt2boot(1,bb),skewt2boot(2,bb));
    Uskewt3(:,bb) = skewtdis_cdf(stdresids3(:,bb),skewt3boot(1,bb),skewt3boot(2,bb));
    Uboot(:,:,bb)=[Uskewt1(:,bb) Uskewt2(:,bb) Uskewt3(:,bb)];
 end
 for pp=1:size(pair,1) % we should consider 3 series combinations
     parfor_progress(bootreps);
    parfor bb=1:bootreps
    uboot=Uboot(:,pair(pp,1),bb);
    vboot=Uboot(:,pair(pp,2),bb);
    % 1. Normal Copula
    kappa1b(:,bb) = corrcoef12(norminv(uboot),norminv(vboot));
    % 2. Clayton's copula -- getting this just in case I want to present it too
    lower = 0.0001;    warning off;
    kappa2b(:,bb) = fmincon('claytonCL',thetaALL(2,1,2),[],[],[],[],lower,[],[],options,[uboot,vboot]);
    % 7. Rotated Gumbel copula
    lower = 1.1;
    upper = 5;
    kappa7b(:,bb) = fmincon('gumbelCL',thetaALL(7,1,2),[],[],[],[],lower,upper,[],options,1-[uboot,vboot]);
    % 8. Student's t copula
    lower = [-0.9 , 0.01 ];
    upper = [ 0.9 , 0.45 ];
    kappa8b(:,bb) = fmincon('tcopulaCL2',thetaALL (8,:,2)',[],[],[],[],lower,upper,[],options,[uboot,vboot]);
    % 9. Symmetrised Joe-Clayton copula
    lower = [0 , 0 ];
    upper = [ 1 , 1];
    kappa9b(:,bb)  = fmincon('sym_jc_CL',thetaALL (9,:,2)',[],[],[],[],lower,upper,[],options,[uboot,vboot]);    
    parfor_progress;
    end
    parfor_progress(0);
    kappa12boot(:,:,pp) = [kappa1b',kappa2b',kappa7b',kappa8b',kappa9b([2,1],:)'];
end
fmtspec='Constant copula. Bootstrap std errors for two-stage param estimator took %10.0f seconds for %10.0f bootreps.  \n';
fprintf(fmtspec,toc,bootreps)

table7(2:2:14,3,:) = std(kappa12boot);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Simulation std errors for two-stage param estimator

% WARNING: THIS PART IS VERY SLOW
bootreps = 4; % this should be at least 100, and better if it is 1000
kappa12sim = nan(bootreps,1+1+1+2+2,size(pair,1));
GOFsim1 = nan(bootreps,2,5,size(pair,1));
GOFsim10 = nan(bootreps,2,5,size(pair,1));
tic;
for pp=1:size(pair,1) % we should consider 3 series combinations
    for bb=1:bootreps
        % First simulate from the copula
        U1 = normcdf(mvnrnd(zeros(1,2),[[1,thetaALL(1,1,2,pp)];[thetaALL(1,1,2,pp),1]],T));
        U2 = clayton_rnd(thetaALL(2,1,2,pp),T);
        U3 = 1-Gumbel_rnd(thetaALL(7,1,2,pp),T);
        U4 = tdis_cdf(mvtrnd([[1,thetaALL(8,1,2,pp)];[thetaALL(8,1,2,pp),1]],1/thetaALL(8,2,2,pp),T),1/thetaALL(8,2,2,pp));
        U5 = sym_jc_rnd(thetaALL(9,2,2,pp),thetaALL(9,1,2,pp),T);
        UUU(:,:,1,pp) = U1;
        UUU(:,:,2,pp) = U2;
        UUU(:,:,3,pp) = U3;
        UUU(:,:,4,pp) = U4;
        UUU(:,:,5,pp) = U5;
        % then obtain the std resids
        EEE = nan(size(UUU));
        for cc=1:5;
                   for mm=1:2;
                    EEE(:,mm,cc,pp) = skewtdis_inv(UUU(:,mm,cc,pp),outSKEWT(mm,1),outSKEWT(mm,2));
                   end
        end
        % next obtain the marginal dynamics
        HHH = nan(size(UUU));  % vol
        YYY = nan(size(UUU));  % simulated raw data
        for cc=1:5
            for mm=1:2;
                if pp==1 
                            if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                            else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                            end
                elseif pp==2       
                     if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                     else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                     end
                 else
                    if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                    else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                    end          
                end
            end
        end
        
        for cc=1:5;
            if pp==1
            % now estimate the models on the simulated data
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),0,0);
           
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            elseif pp==2
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            else
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            end
            stdresids1 = resids_1boot./sqrt(hhat1boot);
            stdresids2 = resids_2boot./sqrt(hhat2boot);
            lower = [2.1, -0.99]; upper = [Inf, 0.99 ];
            warning off;
            skewt1boot = fmincon('skewtdis_LL',outSKEWT(1,:)',[],[],[],[],lower,upper,[],options,stdresids1);
            warning off;
            skewt2boot = fmincon('skewtdis_LL',outSKEWT(2,:)',[],[],[],[],lower,upper,[],options,stdresids2);
            skewt1boot(1)=min(skewt1boot(1),200); % in case DoF>100 take 100 otherwise problems with t-dist
            skewt2boot(1)=min(skewt2boot(1),200); % in case DoF>100 take 100 otherwise problems with t-dist
            Uskewt1 = skewtdis_cdf(stdresids1,skewt1boot(1),skewt1boot(2));
            Uskewt2 = skewtdis_cdf(stdresids2,skewt2boot(1),skewt2boot(2));
            % later I will want to use a simualtion to obtain critical values for KS and CvM tests of these
            % copula models, so I will combine that step with this one (so that we only run one simulation)
            if cc==1;
                % 1. Normal Copula
                kappa1b = corrcoef12(norminv(Uskewt1),norminv(Uskewt2));
                [KSstat1, CVMstat1] = copula_GOF_stats([Uskewt1,Uskewt2],'NormalCopula_cdf',kappa1b);
                Vhat1 = Uskewt1;  % used in GOF test based on Rosenblatt transforms
                Vhat2 = normcdf(norminv(Uskewt2),kappa1b*norminv(Uskewt1),sqrt(1-kappa1b^2));  % conditional copula of V2 | V1
            elseif cc==2
                % 2. Clayton's copula -- getting this just in case I want to present it too
                lower = 0.0001;    warning off;
                kappa2b = fmincon('claytonCL',thetaALL(2,1,2,pp),[],[],[],[],lower,[],[],options,[Uskewt1,Uskewt2]);
                [KSstat1, CVMstat1] = copula_GOF_stats([Uskewt1,Uskewt2],'clayton_cdf',kappa2b);
                Vhat1 = Uskewt1;
                Vhat2 = ClaytonUgivenV_t(Uskewt2,Uskewt1,0,kappa2b);  % conditional distribution of U2 | U1
            elseif cc==3
                % 7. Rotated Gumbel copula
                lower = 1.1;
                upper = 5;
                kappa7b = fmincon('gumbelCL',thetaALL(7,1,2,pp),[],[],[],[],lower,upper,[],options,1-[Uskewt1,Uskewt2]);
                [KSstat1, CVMstat1] = copula_GOF_stats(1-[Uskewt1,Uskewt2],'gumbel_cdf',kappa7b);
                Vhat1 = 1-Uskewt1;
                Vhat2 = GumbelUgivenV_t(1-Uskewt2,1-Uskewt1,0,kappa7b);  % conditional distribution of U2 | U1
            elseif cc==4
                % 8. Student's t copula
                lower = [-0.9 , 0.01 ];
                upper = [ 0.9 , 0.45 ];
                kappa8b = fmincon('tcopulaCL2',thetaALL(8,:,2,pp)',[],[],[],[],lower,upper,[],options,[Uskewt1,Uskewt2]);
                [KSstat1, CVMstat1] = copula_GOF_stats([Uskewt1,Uskewt2],'tCopula_cdf_new',kappa8b);
                Vhat1 = Uskewt1;
                Vhat2 = mvt_cond_cdf( tinv(Uskewt2,1/kappa8b(2)) , tinv(Uskewt1,1/kappa8b(2)) , zeros(1,2) , [[1,kappa8b(1)];[kappa8b(1),1]] , 1/kappa8b(2));
            elseif cc==5
                % 9. Symmetrised Joe-Clayton copula
                lower = [0 , 0 ];
                upper = [ 1 , 1];
                kappa9b = fmincon('sym_jc_CL',thetaALL(9,:,2,pp)',[],[],[],[],lower,upper,[],options,[Uskewt1,Uskewt2]);
                kappa9b = kappa9b([2,1]);  % putting tauL before tauU
                [KSstat1, CVMstat1] = copula_GOF_stats([Uskewt1,Uskewt2],'sym_jc_cdf_new',kappa9b(2),kappa9b(1));
                Vhat1 = Uskewt1;  % used in GOF test based on Rosenblatt transforms
                Vhat2=sjcUgivenV_t(Uskewt2,Uskewt1,0,kappa9b(2),kappa9b(1)); % This part is incorrect used only to try the code. CHANGE IT LATER!!!
            end
            GOFsim1(bb,:,cc,pp) = [KSstat1 CVMstat1];
            [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2],'IndepCop_cdf');  % KS and CVM test on Rosenblatt transforms
            GOFsim10(bb,:,cc,pp) = [KSstat1 CVMstat1];
        end
        kappa12sim(bb,:,pp) = [kappa1b,kappa2b,kappa7b,kappa8b',kappa9b'];
        fmtspec='Loop %10.0f of %-10.0f \n';
        fprintf(fmtspec,bb,bootreps)  % takes about 34 sec per loop
    end
end
toc  % took 288 mins for bootreps=1000. Took 27 mins for botreps=10

% checking that simulated parameters are roughly around the estimated parameters
for pp=1:size(pair,1)
 fmtspec='%s =>> Comparison of estimated vs simulated parameters. \n';
 fprintf(fmtspec,pairs{pp})
 fprintf('Estimated  Sim:-> Mean      Median      Min      Max       Std \n')
 [thetaALL(1,1,2,pp),mean(kappa12sim(:,1,pp)),median(kappa12sim(:,1,pp)),min(kappa12sim(:,1,pp)),max(kappa12sim(:,1,pp)),std(kappa12sim(:,1,pp))]
 [thetaALL(2,1,2,pp),mean(kappa12sim(:,2,pp)),median(kappa12sim(:,2,pp)),min(kappa12sim(:,2,pp)),max(kappa12sim(:,2,pp)),std(kappa12sim(:,2,pp))]
 [thetaALL(7,1,2,pp),mean(kappa12sim(:,3,pp)),median(kappa12sim(:,3,pp)),min(kappa12sim(:,3,pp)),max(kappa12sim(:,3,pp)),std(kappa12sim(:,3,pp))]
 [thetaALL(8,:,2,pp)',mean(kappa12sim(:,4:5,pp))',median(kappa12sim(:,4:5,pp))',min(kappa12sim(:,4:5,pp))',max(kappa12sim(:,4:5,pp))',std(kappa12sim(:,4:5,pp))']
 [thetaALL(9,:,2,pp)',mean(kappa12sim(:,6:7,pp))',median(kappa12sim(:,6:7,pp))',min(kappa12sim(:,6:7,pp))',max(kappa12sim(:,6:7,pp))',std(kappa12sim(:,6:7,pp))']
end
 table7(2:2:14,4,:) = std(kappa12sim)

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD ERRORS FOR CONSTANT COPULAS - SEMIPARAMETRIC CASE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bootstrap std errors for two-stage SEMIPARAM estimator

uu=1;  % EDF margins

% WARNING: THIS PART IS PRETTY SLOW
bootreps = 4; % this should be at least 100, and better if it is 1000
bootdates = randint(1,T,T,bootreps);  % iid bootstrap, justified by Chen+Fan (2006) and Remillard (2010)
kappa1boot = nan(bootreps,1+1+1+2+2);
tic;

for pp=1:size(pair,1)
    fmtspec='Pair %s \n';
    fprintf(fmtspec,pairs{pp})
    parfor_progress(bootreps);
    parfor bb=1:bootreps
        Uboot = Uall(bootdates(:,bb),pair(pp,:),uu);
        % 1. Normal Copula
        kappa1b(:,bb) = corrcoef12(norminv(Uboot));
        % 2. Clayton's copula -- getting this just in case I want to present it too
        lower = 0.0001;    warning off;
        kappa2b(:,bb) = fmincon('claytonCL',thetaALL(2,1,uu,pp),[],[],[],[],lower,[],[],options,Uboot);
        % 7. Rotated Gumbel copula
        lower = 1.1;
        upper = 5;
        kappa7b(:,bb) = fmincon('gumbelCL',thetaALL(7,1,uu,pp),[],[],[],[],lower,upper,[],options,1-Uboot);
        % 8. Student's t copula
        lower = [-0.9 , 0.01 ];
        upper = [ 0.9 , 0.45 ];
        kappa8b(:,bb) = fmincon('tcopulaCL2',thetaALL(8,:,uu,pp)',[],[],[],[],lower,upper,[],options,Uboot);
        % 9. Symmetrised Joe-Clayton copula
        lower = [0 , 0 ];
        upper = [ 1 , 1];
        kappa9b(:,bb) = fmincon('sym_jc_CL',thetaALL(9,:,uu,pp)',[],[],[],[],lower,upper,[],options,Uboot);
        parfor_progress;
    end
    parfor_progress(0);
    kappa1boot(:,:,pp) = [kappa1b',kappa2b',kappa7b',kappa8b',kappa9b([2,1],:)'];
end
toc  % takes around 24.5 mins for bootreps=1000

table7(2:2:14,7,:) =  nanstd(kappa1boot);

% Simulation-based approach for the constant copulas - semi-parametric
% This is based on Remillard 2010

uu=1;  % nonparametric margins

bootreps = 4;  % should be at least 100
kappaGOFsim3 = nan(bootreps,1+1+1+2+2);
GOFsim3 = nan(bootreps,2,5);
GOFsim30 = nan(bootreps,2,5);
tic;
for pp=1:size(pair,1)
    for bb=1:bootreps
        % First simulate from the copula
        U1 = normcdf(mvnrnd(zeros(1,2),[[1,thetaALL(1,1,uu,pp)];[thetaALL(1,1,uu,pp),1]],T));
        U2 = clayton_rnd(thetaALL(2,1,uu,pp),T);
        U3 = 1-Gumbel_rnd(thetaALL(7,1,uu,pp),T);
        U4 = tdis_cdf(mvtrnd([[1,thetaALL(8,1,uu,pp)];[thetaALL(8,1,uu,pp),1]],1/thetaALL(8,2,uu,pp),T),1/thetaALL(8,2,uu,pp));
        U5 = sym_jc_rnd(thetaALL(9,2,uu,pp),thetaALL(9,1,uu,pp),T);
        UUU(:,:,1,pp) = U1;
        UUU(:,:,2,pp) = U2;
        UUU(:,:,3,pp) = U3;
        UUU(:,:,4,pp) = U4;
        UUU(:,:,5,pp) = U5;
        
        for cc=1:5;
            % then obtain the PITs of the *copula* simulation (seems weird, but this is using the EDF margin estimator)
            Uhat = empiricalCDF( UUU(:,:,cc,pp) );  % using EDF to estimate marginal distributions
            
            if cc==1;
                % 1. Normal Copula
                kappa1b = corrcoef12(norminv(Uhat));
                [KSstat1, CVMstat1] = copula_GOF_stats(Uhat,'NormalCopula_cdf',kappa1b);
                Vhat1 = Uhat(:,1);  % computing the rosenblatt transforms
                Vhat2 = normcdf(norminv(Uhat(:,2)),kappa1b*norminv(Uhat(:,1)),sqrt(1-kappa1b^2));  % conditional copula of V2 | V1
            elseif cc==2
                % 2. Clayton's copula -- getting this just in case I want to present it too
                lower = 0.0001;    warning off;
                theta0 = thetaALL(2,1,uu) + randn/100;
                kappa2b = fmincon('claytonCL',theta0,[],[],[],[],lower,[],[],options,Uhat);
                [KSstat1, CVMstat1] = copula_GOF_stats(Uhat,'clayton_cdf',kappa2b);
                Vhat1 = Uhat(:,1);
                Vhat2 = ClaytonUgivenV_t(Uhat(:,2),Uhat(:,1),0,kappa2b);  % conditional distribution of U2 | U1
            elseif cc==3
                % 7. Rotated Gumbel copula
                lower = 1.1;
                upper = 5;
                theta0 = thetaALL(7,1,uu) + randn/100;
                kappa7b = fmincon('gumbelCL',theta0,[],[],[],[],lower,upper,[],options,1-Uhat);
                [KSstat1, CVMstat1] = copula_GOF_stats(1-Uhat,'gumbel_cdf',kappa7b);
                Vhat1 = 1-Uhat(:,1);
                Vhat2 = GumbelUgivenV_t(1-Uhat(:,2),1-Uhat(:,1),0,kappa7b);  % conditional distribution of U2 | U1
            elseif cc==4
                % 8. Student's t copula
                lower = [-0.9 , 0.01 ];
                upper = [ 0.9 , 0.45 ];
                theta0 = thetaALL(8,:,uu)' + randn(2,1)/100;
                kappa8b = fmincon('tcopulaCL2',theta0,[],[],[],[],lower,upper,[],options,Uhat);
                [KSstat1, CVMstat1] = copula_GOF_stats(Uhat,'tCopula_cdf_new',kappa8b);
                Vhat1 = Uhat(:,1);
                Vhat2 = mvt_cond_cdf(tinv(Uhat(:,2),1/kappa8b(2)),tinv(Uhat(:,1),1/kappa8b(2)),zeros(1,2),[[1,kappa8b(1)];[kappa8b(1),1]],1/kappa8b(2));
            elseif cc==5
                % 9. Symmetrised Joe-Clayton copula
                lower = [0 , 0 ];
                upper = [ 1 , 1];
                kappa9b = fmincon('sym_jc_CL',thetaALL(9,:,2,pp)',[],[],[],[],lower,upper,[],options,Uhat);
                kappa9b = kappa9b([2,1]);  % putting tauL before tauU
                [KSstat1, CVMstat1] = copula_GOF_stats(Uhat,'sym_jc_cdf_new',kappa9b(2),kappa9b(1));
                Vhat1 = Uhat(:,1);  % used in GOF test based on Rosenblatt transforms
                Vhat2=sjcUgivenV_t(Uhat(:,2),Vhat1,0,kappa9b(2),kappa9b(1)); % This part is incorrect used only to try the code. CHANGE IT LATER!!!
            end
            GOFsim3(bb,:,cc,pp) = [KSstat1 CVMstat1];
            [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2],'IndepCop_cdf');
            GOFsim30(bb,:,cc,pp) = [KSstat1 CVMstat1];
        end
        kappaGOFsim3(bb,:,pp) = [kappa1b,kappa2b,kappa7b,kappa8b',kappa9b'];
        
        %[bb,toc]  % takes about 62 sec per loop, so about 100 mins for 100 replications
    end
end
toc  %

table7(2:2:14,8,:) = std(kappaGOFsim3);

table7a = nan(3+3+3+5+5,4+4,size(pair,1)); % insert LogL values for each model
table7a(1:2,:,:) = table7(1:2,:,:);
table7a(4:5,:,:) = table7(3:4,:,:);
table7a(7:8,:,:) = table7(5:6,:,:);
table7a(10:13,:,:) = table7(7:10,:,:);
table7a(15:18,:,:) = table7(11:14,:,:);
table7a([3,6,9,14,19],[3,6],:) = LLALL([1,2,7,8,9],[2,1],:);  % log likelihood values for these models
table7 = table7a;

%% MSML for full parameteric model
% I have added this part after obtained the final results. Careful! The code may have errors  
for pp=1:size(pair,1)
        if pp==1
            i=1;  j=2;
        elseif pp==2
            i=1;  j=3;
        else
            i=2;  j=3;
        end
%% first margin stuff
[theta1m,~,~,resids1] = ARMAX_2(rets1(:,i),mean_order(i,1),mean_order(i,2));
resids1 = [zeros(max(mean_order(i,1),mean_order(i,2)),1);resids1];
scores1m = LLgrad_1('ARMA_LLa',theta1m,mean_order(i,1),mean_order(i,2),rets1(:,i));
[theta1v, ~,~,hhat1,~,~,~,~,hess,scores1v]= RealGARCHestimate([data(:,i) datarv(:,i)],'SKEWT');
%[parameters, ~, hessinv1, robustSE1, hhat1, scores1v] 
hess1v =hess; 
stdresids1 = resids1./sqrt(hhat1);    
theta1s = outSKEWT(i,:)';
theta1 = [theta1m;theta1v;theta1s];
scores1s = LLgrad_1('skewtdis_LLa',theta1s,stdresids1);
scores1 = [scores1m, scores1v ,scores1s];
B1 = newey_west(scores1,floor(T^(1/3)));
H1 = zeros(size(scores1,2),size(scores1,2));
H1m = hessian('ARMA_LL',theta1m,mean_order(i,1),mean_order(i,2),rets1(:,i))/T;
H1v = hess1v;
H1s = hessian_2stage('skewtdis_ARMA_RealGARCH_LL',theta1,length(theta1s),[],[data(:,i) datarv(:,i)],mean_order(i,1),mean_order(i,2),1,1)/T;
H1(1:length(theta1m),1:length(theta1m)) = H1m;
H1(length(theta1m)+1:length(theta1m)+length(theta1v)  ,length(theta1m)+1:length(theta1m)+length(theta1v)) = H1v;
H1(end-1:end,:) = H1s;
V1 = inv(H1)*B1*(inv(H1)')/T;  % avar[thetahat] = Ainv*B*Ainv, so V[thetahat] ~~ Ainv*B*Ainv/T
[theta1,sqrt(diag(V1)),theta1./sqrt(diag(V1))]

%% second margin stuff
[theta2m,~,~,resids2] = ARMAX_2(rets1(:,j),mean_order(j,1),mean_order(j,2));
resids2 = [zeros(max(mean_order(j,1),mean_order(j,2)),1);resids2];
scores2m = LLgrad_1('ARMA_LLa',theta2m,mean_order(j,1),mean_order(j,2),rets1(:,j));
[theta2v, ~,~,hhat2,~,~,~,~,hess,scores2v]= RealGARCHestimate([data(:,j) datarv(:,j)],'SKEWT');
hess2v = hess;  % Kevin's code returns the inverse hessian - I convert it back to the hessian here, then divide by T
stdresids2 = resids2./sqrt(hhat2);    
theta2s = outSKEWT(j,:)';
theta2 = [theta2m;theta2v;theta2s];
scores2s = LLgrad_1('skewtdis_LLa',theta2s,stdresids2);
scores2 = [scores2m,scores2v,scores2s];
B2 = newey_west(scores2,floor(T^(1/3)));
H2 = zeros(size(scores2,2),size(scores2,2));
H2m = hessian('ARMA_LL',theta2m,mean_order(j,1),mean_order(j,2),rets1(:,j))/T;
H2v = hess2v;
H2s = hessian_2stage('skewtdis_ARMA_RealGARCH_LL',theta2,length(theta2s),[],[data(:,j) datarv(:,j)],mean_order(j,1),mean_order(j,2),1,1)/T;
H2(1:length(theta2m),1:length(theta2m)) = H2m;
H2(length(theta2m)+1:length(theta2m)+length(theta2v)  ,length(theta2m)+1:length(theta2m)+length(theta2v)) = H2v;
H2(end-1:end,:) = H2s;
V2 = inv(H2)*B2*(inv(H2)')/T;  % avar[thetahat] = Ainv*B*Ainv, so V[thetahat] ~~ Ainv*B*Ainv/T
[theta2,sqrt(diag(V2)),theta2./sqrt(diag(V2))]


%% copula stuff: constant
uu=2;  % parametric margins 

scoresc = LLgrad_1('NormalCopula_CLa',thetaALL(1,1,uu,pp),Uall(:,pair(pp,:),uu));
scoresALL = [scores1,scores2,scoresc];
BB = newey_west(scoresALL,floor(T^(1/3)));
thetac = thetaALL(1,1,uu,pp);
tic;
Hc = hessian_2stage('my_margin_margin_copula_CL1',...
   [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
   'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','NormalCopula_CL',...
   size(theta1,1),size(theta2,1),4,4,...
   mean_order(i,1),mean_order(i,2),1,1,...
   mean_order(j,1),mean_order(j,2),1,1 )/T;
toc  % 0.47 seconds
thetaALLmle = [theta1;theta2;thetac];
HH = zeros(length(thetaALLmle),length(thetaALLmle));
HH(1:length(theta1),1:length(theta1)) = H1;
HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
HH(end-length(thetac)+1:end,:) = Hc;
VALL = inv(HH)*BB*(inv(HH)')/T;
eig(VALL)
[theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
[theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
[thetaALLmle,sqrt(diag(VALL)),thetaALLmle./sqrt(diag(VALL))]
fprintf('se for constant Normal copula based on MSMLE is %10.4f \n',sqrt(diag(VALL(end,end))))
table7(2,2,pp)=sqrt(diag(VALL(end,end)));

% clayton
scoresc = LLgrad_1('claytonCLa',thetaALL(2,1,uu,pp),Uall(:,pair(pp,:),uu));
scoresALL = [scores1,scores2,scoresc];
BB = newey_west(scoresALL,floor(T^(1/3)));
thetac = thetaALL(2,1,uu,pp);
tic;
Hc = hessian_2stage('my_margin_margin_copula_CL1',...
   [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
   'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','claytonCL',...
   size(theta1,1),size(theta2,1),4,4,...
   mean_order(i,1),mean_order(i,2),1,1,...
   mean_order(j,1),mean_order(j,2),1,1 )/T;
toc  % 53 seconds
thetaALLmle = [theta1;theta2;thetac];
HH = zeros(length(thetaALLmle),length(thetaALLmle));
HH(1:length(theta1),1:length(theta1)) = H1;
HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
HH(end-length(thetac)+1:end,:) = Hc;
VALL = inv(HH)*BB*(inv(HH)')/T;
eig(VALL)
[theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
[theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
[thetaALLmle,sqrt(diag(VALL)),thetaALLmle./sqrt(diag(VALL))]
fprintf('se for constant Clayton copula based on MSMLE is %10.4f \n',sqrt(diag(VALL(end,end))))
table7(5,2,pp)=sqrt(diag(VALL(end,end)));

% Rot Gumbel copula
scoresc = LLgrad_1('gumbelCLa',thetaALL(7,1,uu,pp),1-Uall(:,pair(pp,:),uu));
scoresALL = [scores1,scores2,scoresc];
BB = newey_west(scoresALL,floor(T^(1/3)));
thetac = thetaALL(7,1,uu,pp);
tic;
Hc = hessian_2stage('my_margin_margin_copula_CL1',...
   [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
   'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','gumbelCL',...
   size(theta1,1),size(theta2,1),4,4,...
   mean_order(i,1),mean_order(i,2),1,1,...
   mean_order(j,1),mean_order(j,2),1,1 )/T;
toc  % 53 seconds
thetaALLmle = [theta1;theta2;thetac];
HH = zeros(length(thetaALLmle),length(thetaALLmle));
HH(1:length(theta1),1:length(theta1)) = H1;
HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
HH(end-length(thetac)+1:end,:) = Hc;
VALL = inv(HH)*BB*(inv(HH)')/T;
eig(VALL)
[theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
[theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
[thetaALLmle,sqrt(diag(VALL)),thetaALLmle./sqrt(diag(VALL))]
fprintf('se for constant Rotated Gumbel copula based on MSMLE is %10.4f \n',sqrt(diag(VALL(end,end))))
table7(8,2,pp)=sqrt(diag(VALL(end,end)));

 % t copula 
 scoresc = LLgrad_1('tcopulaCL2a',thetaALL(8,1:2,uu,pp)',Uall(:,pair(pp,:),uu));
scoresALL = [scores1,scores2,scoresc];
BB = newey_west(scoresALL,floor(T^(1/3)));
thetac = thetaALL(8,1:2,uu,pp)';
tic;
Hc = hessian_2stage('my_margin_margin_copula_CL1',...
   [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
   'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','tcopulaCL2',...
   size(theta1,1),size(theta2,1),4,4,...
   mean_order(i,1),mean_order(i,2),1,1,...
   mean_order(j,1),mean_order(j,2),1,1 )/T;
toc  % 53 seconds
thetaALLmle = [theta1;theta2;thetac];
HH = zeros(length(thetaALLmle),length(thetaALLmle));
HH(1:length(theta1),1:length(theta1)) = H1;
HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
HH(end-length(thetac)+1:end,:) = Hc;
VALL = inv(HH)*BB*(inv(HH)')/T;
eig(VALL)
[theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
[theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
[thetaALLmle,sqrt(diag(VALL)),thetaALLmle./sqrt(diag(VALL))]
fprintf('se for constant t copula based on MSMLE is for rho %10.4f and nu %10.4f\n',sqrt(diag(VALL(end-1:end,end-1:end))))
table7([11 13],2,pp)=sqrt(diag(VALL(end-1:end,end-1:end)));

% sjc copula 
 scoresc = LLgrad_1('sym_jc_CLa',thetaALL(9,[2 1],uu,pp)',Uall(:,pair(pp,:),uu));
scoresALL = [scores1,scores2,scoresc];
BB = newey_west(scoresALL,floor(T^(1/3)));
thetac = thetaALL(9,1:2,uu,pp)';% tauL, tauU
tic;
Hc = hessian_2stage('my_margin_margin_copula_CL1',...
   [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
   'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','sym_jc_CL',...
   size(theta1,1),size(theta2,1),4,4,...
   mean_order(i,1),mean_order(i,2),1,1,...
   mean_order(j,1),mean_order(j,2),1,1 )/T;
toc  % 1.4 seconds
thetaALLmle = [theta1;theta2;thetac];
HH = zeros(length(thetaALLmle),length(thetaALLmle));
HH(1:length(theta1),1:length(theta1)) = H1;
HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
HH(end-length(thetac)+1:end,:) = Hc;
VALL = inv(HH)*BB*(inv(HH)')/T;
eig(VALL)
[theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
[theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
[thetaALLmle,sqrt(diag(VALL)),thetaALLmle./sqrt(diag(VALL))]
fprintf('se for constant SJC copula based on MSMLE is for tauL %10.4f and tauU %10.4f (order of se should change)\n',[sqrt(diag(VALL(end,end))) sqrt(diag(VALL(end-1:end-1,end-1:end-1)))])
table7([16 18],2,pp)=[sqrt(diag(VALL(end,end))) sqrt(diag(VALL(end-1:end-1,end-1:end-1)))];
end

%% nonparam margins
uu=1;   
for pp=1:size(pair,1);
        if pp==1
            i=1;  j=2;
        elseif pp==2
            i=1;  j=3;
        else
            i=2;  j=3;
        end

uS = Uall(:,pair(pp,:),uu);
vS = Uall(:,pair(pp,:),uu);

% Normal copula
thetacS = thetaALL(1,1,uu,pp);
scorescS = LLgrad_1('NormalCopula_CLa',thetacS,[uS,vS]);
Hc1S = hessian('NormalCopula_CL',thetacS,[uS,vS])/T;  % used in naive VCV matrix for copula params. This is Bhat in Chen and Fan (2006)
Vc2S = inv(Hc1S)/T;  % naive sandwich VCV matrix for copula params. ignoring estimation error from the marginal distributions and from EDF
% now using Chen and Fan (2006) to get correct std errors for this estimate
tic;[sigmaS1,sigmaS2]= copula_deriv2_chen_fan('NormalCopula_CLa',thetacS,[uS,vS]);toc  % takes 2.8 seconds 
VcSa = inv(Hc1S)*sigmaS1*inv(Hc1S)/T;
VcSb = inv(Hc1S)*sigmaS2*inv(Hc1S)/T;
fprintf('Semiparametric Normal copula se. Pair %s \n',pairs{pp})
[thetacS,sqrt(diag(Vc2S)),sqrt(diag(VcSa)),sqrt(diag(VcSb))]
table7(2,6,pp) = sqrt(VcSa);

% Clayton copula
thetacS = thetaALL(2,1,uu,pp);
scorescS = LLgrad_1('claytonCLa',thetacS,[uS,vS]);
Hc1S = hessian('claytonCL',thetacS,[uS,vS])/T;  % used in naive VCV matrix for copula params. This is Bhat in Chen and Fan (2006)
Vc2S = inv(Hc1S)/T;  % naive sandwich VCV matrix for copula params. ignoring estimation error from the marginal distributions and from EDF
% now using Chen and Fan (2006) to get correct std errors for this estimate
tic;[sigmaS1,sigmaS2]= copula_deriv2_chen_fan('claytonCLa',thetacS,[uS,vS]);toc  % takes 2.8 seconds 
VcSa = inv(Hc1S)*sigmaS1*inv(Hc1S)/T;
VcSb = inv(Hc1S)*sigmaS2*inv(Hc1S)/T;
fprintf('Semiparametric Clayton copula se. Pair %s \n',pairs{pp})
[thetacS,sqrt(diag(Vc2S)),sqrt(diag(VcSa)),sqrt(diag(VcSb))]
table7(5,6,pp) = sqrt(VcSa);

% Rotated Gumbel copula
thetacS = thetaALL(7,1,uu,pp);
scorescS = LLgrad_1('gumbelCLa',thetacS,[uS,vS]);
Hc1S = hessian('gumbelCL',thetacS,[uS,vS])/T;  % used in naive VCV matrix for copula params. This is Bhat in Chen and Fan (2006)
Vc2S = inv(Hc1S)/T;  % naive sandwich VCV matrix for copula params. ignoring estimation error from the marginal distributions and from EDF
% now using Chen and Fan (2006) to get correct std errors for this estimate
tic;[sigmaS1,sigmaS2]= copula_deriv2_chen_fan('gumbelCLa',thetacS,[uS,vS]);toc  % takes 2.8 seconds 
VcSa = inv(Hc1S)*sigmaS1*inv(Hc1S)/T;
VcSb = inv(Hc1S)*sigmaS2*inv(Hc1S)/T;
fprintf('Semiparametric Rotated Gumbel copula se. Pair %s \n',pairs{pp})
[thetacS,sqrt(diag(Vc2S)),sqrt(diag(VcSa)),sqrt(diag(VcSb))]
table7(8,6,pp) = sqrt(VcSa);

% Student's t copula
thetacS = thetaALL(8,1:2,uu,pp)';
scorescS = LLgrad_1('tcopulaCL2a',thetacS,[uS,vS]);
Hc1S = hessian('tcopulaCL2',thetacS,[uS,vS])/T;  % used in naive VCV matrix for copula params. This is Bhat in Chen and Fan (2006)
Vc2S = inv(Hc1S)/T;  % naive sandwich VCV matrix for copula params. ignoring estimation error from the marginal distributions and from EDF
% now using Chen and Fan (2006) to get correct std errors for this estimate
tic;[sigmaS1,sigmaS2]= copula_deriv2_chen_fan('tcopulaCL2a',thetacS,[uS,vS]);toc  % takes 5.91 seconds 
VcSa = inv(Hc1S)*sigmaS1*inv(Hc1S)/T;
VcSb = inv(Hc1S)*sigmaS2*inv(Hc1S)/T;
fprintf('Semiparametric t copula se. Pair %s \n',pairs{pp})
[thetacS,sqrt(diag(Vc2S)),sqrt(diag(VcSa)),sqrt(diag(VcSb))]
table7([11,13],6,pp) = sqrt(diag(VcSa));

% SJC copula
thetacS = thetaALL(9,[2 1],uu,pp)';
scorescS = LLgrad_1('sym_jc_CLa',thetacS,[uS,vS]);
Hc1S = hessian('sym_jc_CL',thetacS,[uS,vS])/T;  % used in naive VCV matrix for copula params. This is Bhat in Chen and Fan (2006)
Vc2S = inv(Hc1S)/T;  % naive sandwich VCV matrix for copula params. ignoring estimation error from the marginal distributions and from EDF
% now using Chen and Fan (2006) to get correct std errors for this estimate
tic;[sigmaS1,sigmaS2]= copula_deriv2_chen_fan('sym_jc_CLa',thetacS,[uS,vS]);toc  % takes 5.91 seconds 
VcSa = inv(Hc1S)*sigmaS1*inv(Hc1S)/T;
VcSb = inv(Hc1S)*sigmaS2*inv(Hc1S)/T;
fprintf('Semiparametric SJC copula se. Pair %s \n',pairs{pp})
[thetacS,sqrt(diag(Vc2S)),sqrt(diag(VcSa)),sqrt(diag(VcSb))]
table7([18,16],6,pp) = sqrt(diag(VcSa)); % change the order to lower, upper
end


table7b=table7(:,[2:4 6:8],:); % I decided not to include the results for naive s.e. as well as MSML
% table7b([1 4 7 10 12 15 17],2,:)=table7b([1 4 7 10 12 15 17],1,:);
% table7b([1 3 4 6 7 9 10 12 14 15 17 19],5,:)=table7b([1 3 4 6 7 9 10 12 14 15 17 19],4,:);
% table7b=table7b(:,[2 3 5 6],:);
table7c=table7b(:,[1 3],:); % I decided to include only the results bootstrapping


for pp=1:size(pair,1)
    % save path+file name
    tabName=[save_path,save_name,'table7c',pairs{pp},'.tex'];
    caption = ['Constant copula model parameter estimates for ',pairs{pp},'. Number of simulations S=',num2str(bootreps),'.'];
    label = ['UnivConsCopulaParamSE',pairs{pp}];
    % use table7a for including s.e. from simulations.
    table7cLatex(table7c(:,:,pp),tabName,caption,label,pairs{pp})  
end

% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_6.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_6.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ESTIMATING TIME-VARYING COPULAS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I changed algorithm to "interior-point"
options = optimset('Algorithm','interior-point','Display','off','TolCon',10^-12,'TolFun',10^-6,'TolX',10^-8,'DiffMaxChange',Inf,'DiffMinChange',0);

% I will use the GAS(1,1) specification of Creal et al. (2011) to let the parameter vary through time

table8 = nan(7+7+9,3+2,size(pair,1));% 3*2+1 Normal and Rot gumbel params (i.e. params+se+Likel.)
                                     % for t: 4*(params+se)+Likel. 3 ways for param s.e. + 2 for semiparam.  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time-varying rotated Gumbel

% First, it is useful to get the expected Hessian for a range of values of kappa. Only need to do this once, and then can use this in estimation. 
% (See Appendix A of Creal et al. )
% Will do this using simulation

% WARNING: THIS PART IS PRETTY SLOW Takes 60 mins for the whole section.
reps = 10000;
% At KK below I added the values of kappa: 1.0001 and 1.001 etc because in my dataset I get kapp=1.0095 which gives NaN in "interp1"
% function when estimating the Rotgumbel_GAS_CL. K. Avdulaj
KK = [1.0001;1.0005;1.001;1.005;1.008;(1.1:0.1:3)';(3.25:0.25:5)';(6:10)'];  % values of kappa at which to evaluate the function
HESSgumbel = nan(length(KK),2);
tic;
parfor_progress(length(KK));
parfor ii=1:length(KK);
    Usim(:,:,ii) = Gumbel_rnd(KK(ii),reps);
    Usim1(:,:,ii) = 1-Usim(:,:,ii);  % rotating the data
    scoreSIM(:,ii) = LLgrad_1('gumbelCLa',KK(ii),Usim1(:,:,ii));
    HESSgumbel(ii,1) = mean(scoreSIM(:,ii).^2);   
    HESSgumbel1(ii,2) = corrcoef12(Usim1(:,:,ii));  % rank correlation
parfor_progress;
end
parfor_progress(0);
HESSgumbel(:,2)=HESSgumbel1(:,2);
toc  % took 71 seconds for 12 values of kappa and reps=10,000
% % took 198 seconds for 34 values of kappa and reps=10,000
figure(3423),plot(KK,HESSgumbel(:,1),'bo-')  % nice and smooth.
figure(34250),plot(KK,HESSgumbel(:,2),'bo-'),xlabel('Gumbel copula parameter'),ylabel('Rank correlation');


% Now estimating the GAS model for the Rotated Gumbel copula
lower = [-3 ; -3 ; 0 ];
upper = [ 3 ; 3 ; 0.999 ];

uu=2;  % skew t margins
theta0 = [log(thetaALL(7,1,uu)-1)*(1-0.05-0.93);0.05;0.93];
tic;
parfor_progress(size(pair,1));
parfor pp=1:size(pair,1)
[kappa7b3(:,pp), ~,~] = fmincon('Rotgumbel_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % 69 seconds
[CL(pp),kappatRotp(:,pp),ft(:,pp)] = Rotgumbel_GAS_CL(kappa7b3(:,pp),Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
parfor_progress;
end
parfor_progress(0);
toc
table8([1;3;5],2,:) = kappa7b3(:,:);
table8(7,2,:) = -CL;


figure(12311),plot(ft)
figure(12312),plot(kappatRotp)

uu=1;  % EDF margins
tic;
parfor_progress(3);
parfor pp=1:size(pair,1)
kappa7tvs(:,pp) = fmincon('Rotgumbel_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % 50 seconds
[CL(pp),kappatRote(:,pp),ft(:,pp)] = Rotgumbel_GAS_CL(kappa7tvs(:,pp),Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
parfor_progress;
end
parfor_progress(0);
toc
table8([1;3;5],4,:) = kappa7tvs;
table8(7,4,:) = -CL;

figure(12313),plot(ft)
figure(12314),plot(kappatRote)

% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time varying Normal GAS
RR = [-0.99;-0.75;-0.5;-0.25;-0.1;0;0.1;0.25;0.5;0.75;0.8;0.85;0.9;0.95;0.99];  % adding a few extra nodes for rho around 0.85, which seems to be a common value for this series
HESSnorm=nan(length(RR),2);
for rr=1:length(RR);
        temp = mvnrnd([0 0],[1,RR(rr);RR(rr),1],reps);
        U = normcdf(temp(:,1),0,1);
        V = normcdf(temp(:,2),0,1);
        scoreSIM = LLgrad_1('NormalCopula_CLa',RR(rr),[U,V]);
        HESSnorm(rr,1) = mean(scoreSIM.^2);
        HESSnorm(rr,2) = corrcoef12([U,V]);  % rank correlation
        [rr,toc]   % takes about 6 seconds per valuke of kappa, for reps=10,000   
end

uu=2;  % parametric margins
lower = [-3 ; -3 ; 0];
upper = [ 3 ; 3 ; 0.999];
theta0 = [log( (0.9999+thetaALL(1,1,uu,pp))/(0.9999-thetaALL(1,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8];
tic;
parfor_progress(3);
parfor pp=1:size(pair,1)
    theta1tv1(:,pp) = fmincon('bivnorm_tv_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts
    [CL(pp),rhotNormp(:,pp),~] = bivnorm_tv_GAS_CL(theta1tv1(:,pp),Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % 6.8 secs per function evaluation  
    parfor_progress;
end
parfor_progress(0);
table8([8;10;12],2,:) = theta1tv1;
table8(14,2,:) = -CL;
toc

uu=1;  % EDF margins
tic;
parfor_progress(3);
parfor pp=1:size(pair,1)
    theta1tvs1(:,pp) = fmincon('bivnorm_tv_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts
    [CL(pp),rhotNorme(:,pp),~] = bivnorm_tv_GAS_CL(theta1tvs1(:,pp),Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % 6.8 secs per function evaluation  
    parfor_progress;
end
parfor_progress(0);
table8([8;10;12],4,:) = theta1tvs1;
table8(14,4,:) = -CL;
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time-varying Student's t

% First, need to get the expected Hessian for a range of values of [rho,nu]. Only need to do this once, and then can use this in estimation. 
% (See Appendix A of Creal et al. )
% Will do this using simulation
reps = 10000/4;
NN = [2.1;3;4;6;10;20;100];
RR = [-0.99;-0.5;0;0.5;0.99];
RR = [-0.99;-0.75;-0.5;-0.25;-0.1;0;0.1;0.25;0.5;0.75;0.8;0.85;0.9;0.95;0.99];  % adding a few extra nodes for rho around 0.85, which seems to be a common value for this series
HESSstudt = nan(length(RR),length(NN),2,2,size(pair,1));
RHOSstudt = nan(length(RR),length(NN),1,size(pair,1));
tic;
for rr=1:length(RR);
    for nn=1:length(NN);
        temp = mvtrnd([1,RR(rr);RR(rr),1],NN(nn),reps);
        temp = [temp;-temp];  % imposing symmetry
        temp = [temp;[temp(:,2),temp(:,1)]];  % imposing exchangeability
        U = tdis_cdf(temp(:,1),NN(nn));
        V = tdis_cdf(temp(:,2),NN(nn));
        scoreSIM = LLgrad_1('tcopulaCLa',[RR(rr);NN(nn)],[U,V]);
        HESSstudt(rr,nn,1,1) = mean(scoreSIM(:,1).^2);
        HESSstudt(rr,nn,2,2) = mean(scoreSIM(:,2).^2);
        HESSstudt(rr,nn,1,2) = mean(scoreSIM(:,1).*scoreSIM(:,2));
        HESSstudt(rr,nn,2,1) = HESSstudt(rr,nn,1,2);
        RHOSstudt(rr,nn) = corrcoef12([U,V]);  % rank correlation
        [rr,nn,toc]   % takes about 6 seconds per valuke of kappa, for reps=10,000
    end
end
toc  % took 35 seconds for length(RR)*length(NN)=35 and reps=10,000

% Now estimating the GAS model for the Student's t copula
% WARNING: THIS PART IS VERY SLOW

uu=2;  % parametric margins
lower = [-3 ; -3 ; 0 ; 0.01];
upper = [ 3 ; 3 ; 0.999 ; 0.45];
theta0 = [log( (0.9999+thetaALL(8,1,uu,pp))/(0.9999-thetaALL(8,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8;thetaALL(8,2,uu,pp)];
tic;
parfor_progress(3);
parfor pp=1:size(pair,1)
    theta8tv2(:,pp) = fmincon('tcopula_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);  % about 30 minuts
    [CL(pp),rhotTp(:,pp),~] = tcopula_GAS_CL(theta8tv2(:,pp),Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);  % 6.8 secs per function evaluation
    parfor_progress;  
end
parfor_progress(0);
toc;

table8([15;17;19;21],2,:) = theta8tv2;
table8(23,2,:) = -CL;

uu=1;  % EDF margins
tic;
parfor_progress(3);
parfor pp=1:size(pair,1)
    theta8tvs(:,pp) = fmincon('tcopula_GAS_CL',theta0,[],[],[],[],lower,upper,[],options,Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);  % about 30 minuts
    [CL(pp),rhoTe(:,pp),~] = tcopula_GAS_CL(theta8tvs(:,pp),Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);  % 6.8 secs per function evaluation
    parfor_progress;    
end
parfor_progress(0);

toc;
table8([15;17;19;21],4,:) = theta8tvs;
table8(23,4,:) = -CL;


% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_7.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_7.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD ERRORS ON TIME-VARYING COPULAS - PARAMETRIC CASE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bootstrap std errors for param model 

uu=2;  % skew t margins

% WARNING: THIS PART IS VERY SLOW!
options = optimset('Algorithm','interior-point','Display','off','TolCon',10^-12,'TolFun',10^-4,'TolX',10^-6,'MaxIter',100,'DiffMaxChange',Inf,'DiffMinChange',0 );  % 24apr12: decreasing MaxIter here - it only goes above about 20 when there is a problem, so no need to keep it at default of 400.
bootreps = 4;  % should be at least 100
block_length = 60;  % need a longer block length here, given the persistence implied by the GAS parameters
bootdates = stat_bootstrap_function_21(T,bootreps,block_length);
kappa88boot = nan(bootreps,3+3+4,size(pair,1));  %  added 3 cols here to include the exit flags, to keep a check on how often there is a problem.
tic;
for bb=1:bootreps
    rets1boot(:,:,bb) = rets1(bootdates(:,bb),:);
    rvdataboot(:,:,bb)= rvdata(bootdates(:,bb),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARALLEL COMPUTING HERE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parfor_progress(bootreps);
parfor bb=1:bootreps
    [~,~,~,resids_1boot(:,bb)] = ARMAX_2(rets1boot(:,1,bb),0,0);
    [~,~,~,resids_2boot(:,bb)] = ARMAX_2(rets1boot(:,2,bb),0,0);
    [~,~,~,resids_3boot(:,bb)] = ARMAX_2(rets1boot(:,3,bb),2,0);
    
    resids_1boot(:,bb)=resids_1boot(:,bb)/std(resids_1boot(:,bb));
    resids_2boot(:,bb)=resids_2boot(:,bb)/std(resids_2boot(:,bb));
    resids_3boot(:,bb)=resids_3boot(:,bb)/std( resids_3boot(:,bb));
    
    rvdataboot1(:,bb)=rvdataboot(:,1,bb)/std(rvdataboot(:,1,bb));
    rvdataboot2(:,bb)=rvdataboot(:,2,bb)/std(rvdataboot(:,2,bb));
    rvdataboot3(:,bb)=rvdataboot(:,3,bb)/std(rvdataboot(:,3,bb));

    [~, ~,~,hhat1boot(:,bb),~,~,~] = RealGARCHestimate([resids_1boot(:,bb) rvdataboot1(:,bb)],'SKEWT');
    [~, ~,~,hhat2boot(:,bb),~,~,~] = RealGARCHestimate([resids_2boot(:,bb) rvdataboot2(:,bb)],'SKEWT');
    [~, ~,~,hhat3boot(:,bb),~,~,~] = RealGARCHestimate([[zeros(2,1);resids_3boot(:,bb)] rvdataboot3(:,bb)],'SKEWT');
        
    stdresids1(:,bb) = resids_1boot (:,bb)./sqrt(hhat1boot(:,bb));
    stdresids2(:,bb) = resids_2boot (:,bb)./sqrt(hhat2boot(:,bb));
    stdresids3(:,bb) = [zeros(2,1);resids_3boot(:,bb)]./sqrt(hhat3boot(:,bb));
    
    
    lower = [2.1, -0.99]; upper = [Inf, 0.99 ];
    %warning off;
    skewt1boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (1,:)',[],[],[],[],lower,upper,[],options,stdresids1(:,bb));
    %warning off;
    skewt2boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (2,:)',[],[],[],[],lower,upper,[],options,stdresids2(:,bb));
    skewt3boot(:,bb) = fmincon('skewtdis_LL',outSKEWT (3,:)',[],[],[],[],lower,upper,[],options,stdresids3(:,bb));
    parfor_progress;
end
parfor_progress(0);

 for bb=1:bootreps
    Uskewt1(:,bb) = skewtdis_cdf(stdresids1(:,bb),skewt1boot(1,bb),skewt1boot(2,bb));
    Uskewt2(:,bb) = skewtdis_cdf(stdresids2(:,bb),skewt2boot(1,bb),skewt2boot(2,bb));
    Uskewt3(:,bb) = skewtdis_cdf(stdresids3(:,bb),skewt3boot(1,bb),skewt3boot(2,bb));
    Uboot1(:,:,bb)=[Uskewt1(:,bb) Uskewt2(:,bb) Uskewt3(:,bb)];
 end
 Uboot=Uboot1;
 theta0G = [log(thetaALL(7,1,uu)-1)*(1-0.05-0.93);0.05;0.93];
 theta0N = [log( (0.9999+thetaALL(1,1,uu,pp))/(0.9999-thetaALL(1,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8];
 theta0t = [log( (0.9999+thetaALL(8,1,uu,pp))/(0.9999-thetaALL(8,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8;thetaALL(8,2,uu,pp)];

for pp=1:size(pair,1) % we should consider 3 series combinations
    fprintf('Pair: %s',pairs{pp}) 
    parfor_progress(bootreps);
    parfor bb=1:bootreps
    uboot=Uboot(:,pair(pp,1),bb);
    vboot=Uboot(:,pair(pp,2),bb);
    %  Rotated Gumbel GAS copula
    lower = [-3 ; -3 ; 0 ];
    upper = [ 3 ; 3 ; 0.999 ];
    [kappa7b3b(:,bb),~,~] = fmincon('Rotgumbel_GAS_CL',theta0G,[],[],[],[],lower,upper,[],options,[uboot,vboot],thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
    
    % Normal GAS copula
    [theta1tv1b(:,bb),~,~] = fmincon('bivnorm_tv_GAS_CL',theta0N,[],[],[],[],lower,upper,[],options,[uboot,vboot],thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts
    
    % Student's t copula
    lower1 = [-3 ; -3 ; 0     ; 0.01];
    upper1 = [ 3 ;  3 ; 0.999 ; 0.45];
    [theta8tv2b(:,bb),~,~] = fmincon('tcopula_GAS_CL',theta0t,[],[],[],[],lower1,upper1,[],options,[uboot,vboot],thetaALL(8,1,uu,pp),RR,NN,HESSstudt); 
    parfor_progress;
    end
    parfor_progress(0);
    kappa88boot(:,:,pp) = [kappa7b3b',theta1tv1b',theta8tv2b'];
end



toc  % took 34 hours for bootreps=100.  SLOOOOOOOOOW!
table8([2;4;6],2,:) = std(kappa88boot(:,1:3,:));
table8([9;11;13],2,:) = std(kappa88boot(:,4:6,:));
table8([16;18;20;22],2,:) = std(kappa88boot(:,7:10,:));
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation std errors for param model 

% WARNING: THIS PART IS VERY SLOW!

uu=2;  % parametric margins

bootreps = 4;
kappa88sim = nan(bootreps,3+3+4,size(pair,1));
GOFsim100 = nan(bootreps,2,3,size(pair,1));  % will also get info for GOF test that we'll use later (rather than run another slow simulation separately)
tic;
for pp=1:size(pair,1) % we should consider 3 series combinations
    for bb=1:bootreps
        % First simulate from the copula
        U1 = Rotgumbel_GAS_rnd(table8([1;3;5],2,pp),T,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
        U2 = bivnorm_tv_GAS_rnd(table8([8;10;12],2,pp),T,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1)); 
        U3 = tcopula_GAS_rnd(table8([15;17;19;21],2,pp),T,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
        UUU(:,:,1,pp) = U1;
        UUU(:,:,2,pp) = U2;
        UUU(:,:,3,pp) = U3;
       % then obtain the std resids
        EEE = nan(size(UUU));
        for cc=1:3;
                   for mm=1:2;
                    EEE(:,mm,cc,pp) = skewtdis_inv(UUU(:,mm,cc,pp),outSKEWT(mm,1),outSKEWT(mm,2));
                   end
        end
        % next obtain the marginal dynamics
        HHH = nan(size(UUU));  % vol
        YYY = nan(size(UUU));  % simulated raw data
        for cc=1:3
            for mm=1:2;
                if pp==1 
                            if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                            else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                            end
                elseif pp==2       
                     if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                     else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                     end
                 else
                    if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                    else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                    end          
                end
            end
        end
        
        for cc=1:3;
            if pp==1
            % now estimate the models on the simulated data
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),0,0);
           
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            elseif pp==2
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            else
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            end
            stdresids1 = resids_1boot./sqrt(hhat1boot);
            stdresids2 = resids_2boot./sqrt(hhat2boot);
            lower = [2.1, -0.99]; upper = [Inf, 0.99 ];
            warning off;
            skewt1boot = fmincon('skewtdis_LL',outSKEWT(1,:)',[],[],[],[],lower,upper,[],options,stdresids1);
            warning off;
            skewt2boot = fmincon('skewtdis_LL',outSKEWT(2,:)',[],[],[],[],lower,upper,[],options,stdresids2);
            skewt1boot(1)=min(skewt1boot(1),200); % in case DoF>100 take 100 otherwise problems with t-dist
            skewt2boot(1)=min(skewt2boot(1),200); % in case DoF>100 take 100 otherwise problems with t-dist
            Uskewt1 = skewtdis_cdf(stdresids1,skewt1boot(1),skewt1boot(2));
            Uskewt2 = skewtdis_cdf(stdresids2,skewt2boot(1),skewt2boot(2));

            if cc==1
                % 7. Rotated Gumbel GAS copula
                lower = [-3 ; -3 ; 0 ];
                upper = [ 3 ; 3 ; 0.999 ];
                kappa8b3s = fmincon('Rotgumbel_GAS_CL',theta0G,[],[],[],[],lower,upper,[],options,[Uskewt1,Uskewt2],thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);

                % getting the Rosenblatt transformations to use in GOF tests
                [CL,kappat,ft] = Rotgumbel_GAS_CL(kappa8b3s,[Uskewt1,Uskewt2],thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % getting the time path of the copula parameter
                Vhat1 = 1-Uskewt1;
                Vhat2 = GumbelUgivenV_t(1-Uskewt2,1-Uskewt1,0,kappat);  % conditional distribution of U2 | U1
            elseif cc==2
                % Normal copula
                lower = [-3 ; -3 ; 0     ];
                upper = [ 3 ;  3 ; 0.999 ];
                theta1tv1s = fmincon('bivnorm_tv_GAS_CL',theta0N,[],[],[],[],lower,upper,[],options,[Uskewt1,Uskewt2],thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts
                
                % getting the Rosenblatt transformations to use in GOF tests
                [CL,rho1t,ft] = bivnorm_tv_GAS_CL(theta1tv1s,[Uskewt1,Uskewt2],thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));
                Vhat1 = Uskewt1;
                Vhat2 = nan(T,1);
                for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                Vhat2(tt) = normcdf(norminv(Uskewt2(tt)),rho1t(tt)*norminv(Uskewt1(tt)),sqrt(1-rho1t(tt)^2));  % conditional copula of V2 | V1
                end
            else
                % 8. Student's t copula
                lower = [-3 ; -3 ; 0     ; 0.01];
                upper = [ 3 ;  3 ; 0.999 ; 0.45];
                theta8tv2s = fmincon('tcopula_GAS_CL',theta0t,[],[],[],[],lower,upper,[],options,[Uskewt1,Uskewt2],thetaALL(8,1,uu,pp),RR,NN,HESSstudt);

                % getting the Rosenblatt transformations to use in GOF tests
                [CL,rhot,ft] = tcopula_GAS_CL(theta8tv2s,[Uskewt1,Uskewt2],thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
                Vhat1 = Uskewt1;
                Vhat2 = nan(T,1);
                for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                    Vhat2(tt) = mvt_cond_cdf(tinv(Uskewt2(tt),1/theta8tv2s(end)),tinv(Uskewt1(tt),1/theta8tv2s(end)),zeros(1,2),[[1,rhot(tt)];[rhot(tt),1]],1/theta8tv2b(end));
                end
            end
            [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2],'IndepCop_cdf');
            GOFsim100(bb,:,cc,pp) = [KSstat1 CVMstat1];
            fmtspec='Simulation std errors for param model: Loop %10.0f of %-10.0f, pair %s \n';
            fprintf(fmtspec,bb,bootreps,pairs{pp})  % takes about 34 sec per loop
        end
        kappa88sim(bb,:,pp) = [kappa8b3s',theta1tv1s',theta8tv2s'];
    end 
end
table8([2;4;6],3,:) = std(kappa88sim(:,1:3,:));
table8([9;11;13],3,:) = std(kappa88sim(:,4:6,:));
table8([16;18;20;22],3,:) = std(kappa88sim(:,7:10,:));

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bootstrap std errors for semiparam model 

% WARNING: THIS PART IS VERY SLOW!

uu=1;  % EDF margins

bootreps = 4;  % should be at least 100
block_length = 60;
bootdates = stat_bootstrap_function_21(T,bootreps,block_length);
kappa88Sboot = nan(bootreps,3+3+4,size(pair,1));
tic;
for bb=1:bootreps
  rets1boot(:,:,bb) = rets1(bootdates(:,bb),:);
  rvdataboot(:,:,bb)= rvdata(bootdates(:,bb),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARALLEL COMPUTING HERE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parfor_progress(bootreps);
parfor bb=1:bootreps
      [~,~,~,resids_1boot(:,bb)] = ARMAX_2(rets1boot(:,1,bb),0,0);
    [~,~,~,resids_2boot(:,bb)] = ARMAX_2(rets1boot(:,2,bb),0,0);
    [~,~,~,resids_3boot(:,bb)] = ARMAX_2(rets1boot(:,3,bb),2,0);
    
    resids_1boot(:,bb)=resids_1boot(:,bb)/std(resids_1boot(:,bb));
    resids_2boot(:,bb)=resids_2boot(:,bb)/std(resids_2boot(:,bb));
    resids_3boot(:,bb)=resids_3boot(:,bb)/std( resids_3boot(:,bb));
    
    rvdataboot1(:,bb)=rvdataboot(:,1,bb)/std(rvdataboot(:,1,bb));
    rvdataboot2(:,bb)=rvdataboot(:,2,bb)/std(rvdataboot(:,2,bb));
    rvdataboot3(:,bb)=rvdataboot(:,3,bb)/std(rvdataboot(:,3,bb));

    [~, ~,~,hhat1boot(:,bb),~,~,~] = RealGARCHestimate([resids_1boot(:,bb) rvdataboot1(:,bb)],'SKEWT');
    [~, ~,~,hhat2boot(:,bb),~,~,~] = RealGARCHestimate([resids_2boot(:,bb) rvdataboot2(:,bb)],'SKEWT');
    [~, ~,~,hhat3boot(:,bb),~,~,~] = RealGARCHestimate([[zeros(2,1);resids_3boot(:,bb)] rvdataboot3(:,bb)],'SKEWT');
        
    stdresids1(:,bb) = resids_1boot (:,bb)./sqrt(hhat1boot(:,bb));
    stdresids2(:,bb) = resids_2boot (:,bb)./sqrt(hhat2boot(:,bb));
    stdresids3(:,bb) = [zeros(2,1);resids_3boot(:,bb)]./sqrt(hhat3boot(:,bb));
  
    parfor_progress;
end
parfor_progress(0);

 for bb=1:bootreps
    UbootS(:,:,bb) = empiricalCDF([stdresids1(:,bb),stdresids2(:,bb),stdresids3(:,bb)]);  
 end
 
 theta0G = [log(thetaALL(7,1,uu)-1)*(1-0.05-0.93);0.05;0.93];
 theta0N = [log( (0.9999+thetaALL(1,1,uu,pp))/(0.9999-thetaALL(1,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8];
 theta0t = [log( (0.9999+thetaALL(8,1,uu,pp))/(0.9999-thetaALL(8,1,uu,pp)) )*(1-0.05-0.8);0.05;0.8;thetaALL(8,2,uu,pp)];
tic;
for pp=1:size(pair,1) % we should consider 3 series combinations
    fprintf('Pair: %s',pairs{pp}) 
    parfor_progress(bootreps);
        parfor bb=1:bootreps
        uboot=UbootS(:,pair(pp,1),bb);
        vboot=UbootS(:,pair(pp,2),bb);
        %  Rotated Gumbel GAS copula
        lower = [-3 ; -3 ; 0 ];
        upper = [ 3 ; 3 ; 0.999 ];
        [kappa7b3b(:,bb),~,~] = fmincon('Rotgumbel_GAS_CL',theta0G,[],[],[],[],lower,upper,[],options,[uboot,vboot],thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);

        % Normal GAS copula
        [theta1tv1b(:,bb),~,~] = fmincon('bivnorm_tv_GAS_CL',theta0N,[],[],[],[],lower,upper,[],options,[uboot,vboot],thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts

        % Student's t copula
        lower1 = [-3 ; -3 ; 0     ; 0.01];
        upper1 = [ 3 ;  3 ; 0.999 ; 0.45];
        [theta8tv2b(:,bb),~,~] = fmincon('tcopula_GAS_CL',theta0t,[],[],[],[],lower1,upper1,[],options,[uboot,vboot],thetaALL(8,1,uu,pp),RR,NN,HESSstudt); 
        parfor_progress;
        end
    parfor_progress(0);
    kappa88Sboot(:,:,pp) = [kappa7b3b',theta1tv1b',theta8tv2b'];
end
toc  % took 27.8 hours for 100 reps. SLOW!!

table8([2;4;6],4,:) = std(kappa88Sboot(:,1:3,:));
table8([9;11;13],4,:) = std(kappa88Sboot(:,4:6,:));
table8([16;18;20;22],4,:) = std(kappa88Sboot(:,7:10,:));

% REMOVE THIS CASE: IT IS A MISTAKE!!! (K.A.). NO SIMULATION METHOD FOR TV
% COPULA.
% Simulation-based approach for the tv copulas - semi-parametric
%  
uu=1;  % nonparametric margins

bootreps = 4;  % should be at least 100
kappaGOFsim300 = nan(bootreps,3+3+4);
GOFsim300 = nan(bootreps,2,10);
UUU=nan(T,2,3,bootreps,size(pair,1));
tic;
for pp=1:size(pair,1)
    parfor bb=1:bootreps
        % First simulate from the copula
        U1(:,:,bb) = Rotgumbel_GAS_rnd(table8([1;3;5],2,pp),T,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
        U2(:,:,bb) = bivnorm_tv_GAS_rnd(table8([8;10;12],2,pp),T,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1)); 
        U3(:,:,bb) = tcopula_GAS_rnd(table8([15;17;19;21],2,pp),T,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);      
    end
    UUU(:,:,1,:,pp)=U1;
    UUU(:,:,2,:,pp)=U2;
    UUU(:,:,3,:,pp)=U3;
end

tic;
for pp=1:size(pair,1)
    parfor_progress(bootreps);
    parfor bb=1:bootreps
            for cc=1:3;
            % then obtain the PITs of the *copula* simulation (seems weird, but this is using the EDF margin estimator)
            Uhat = empiricalCDF( UUU(:,:,cc,bb,pp) );  % using EDF to estimate marginal distributions

                if cc==1
                    % 7. Rotated Gumbel GAS copula
                    lower = [-3 ; -3 ; 0 ];
                    upper = [ 3 ; 3 ; 0.999 ];
                    kappa8b3b(:,bb) = fmincon('Rotgumbel_GAS_CL',theta0G,[],[],[],[],lower,upper,[],options,Uhat,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);

                elseif cc==2
                    % Normal copula
                    lower1 = [-3 ; -3 ; 0     ];
                    upper1 = [ 3 ;  3 ; 0.999 ];
                    theta1tv1b(:,bb) = fmincon('bivnorm_tv_GAS_CL',theta0N,[],[],[],[],lower1,upper1,[],options,Uhat,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts

                else
                    % 8. Student's t copula
                    lower2 = [-3 ; -3 ; 0     ; 0.01];
                    upper2 = [ 3 ;  3 ; 0.999 ; 0.45];
                    theta8tv2b(:,bb) = fmincon('tcopula_GAS_CL',theta0t,[],[],[],[],lower2,upper2,[],options,Uhat,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
                end
            end
    parfor_progress;    
    end
    parfor_progress(0);
    kappaGOFsim300(:,:,pp) = [kappa8b3b',theta1tv1b',theta8tv2b' ];
end
toc  %

table8([2;4;6],5,:) = std(kappaGOFsim300(:,1:3,:));
table8([9;11;13],5,:) = std(kappaGOFsim300(:,4:6,:));
table8([16;18;20;22],5,:) = std(kappaGOFsim300(:,7:10,:));

table8=table8(:,2:5,:); % remove the first column which was reserved for sandwich method

table8a = nan(7+7+9,3+2,size(pair,1));% I am creating this new table because I do not want to change the code that refer to table8 in later steps
table8a(:,2:5,:)=table8;

for pp=1:size(pair,1)
    if pp==1
        i=1;  j=2;
    elseif pp==2
        i=1;  j=3;
    else
        i=2;  j=3;
    end
    %% first margin stuff
    [theta1m,~,~,resids1] = ARMAX_2(rets1(:,i),mean_order(i,1),mean_order(i,2));
    resids1 = [zeros(max(mean_order(i,1),mean_order(i,2)),1);resids1];
    scores1m = LLgrad_1('ARMA_LLa',theta1m,mean_order(i,1),mean_order(i,2),rets1(:,i));
    [theta1v, ~,~,hhat1,~,~,~,~,hess,scores1v]= RealGARCHestimate([data(:,i) datarv(:,i)],'SKEWT');
    %[parameters, ~, hessinv1, robustSE1, hhat1, scores1v]
    hess1v =hess;
    stdresids1 = resids1./sqrt(hhat1);
    theta1s = outSKEWT(i,:)';
    theta1 = [theta1m;theta1v;theta1s];
    scores1s = LLgrad_1('skewtdis_LLa',theta1s,stdresids1);
    scores1 = [scores1m, scores1v ,scores1s];
    B1 = newey_west(scores1,floor(T^(1/3)));
    H1 = zeros(size(scores1,2),size(scores1,2));
    H1m = hessian('ARMA_LL',theta1m,mean_order(i,1),mean_order(i,2),rets1(:,i))/T;
    H1v = hess1v;
    H1s = hessian_2stage('skewtdis_ARMA_RealGARCH_LL',theta1,length(theta1s),[],[data(:,i) datarv(:,i)],mean_order(i,1),mean_order(i,2),1,1)/T;
    H1(1:length(theta1m),1:length(theta1m)) = H1m;
    H1(length(theta1m)+1:length(theta1m)+length(theta1v)  ,length(theta1m)+1:length(theta1m)+length(theta1v)) = H1v;
    H1(end-1:end,:) = H1s;
    V1 = inv(H1)*B1*(inv(H1)')/T;  % avar[thetahat] = Ainv*B*Ainv, so V[thetahat] ~~ Ainv*B*Ainv/T
    [theta1,sqrt(diag(V1)),theta1./sqrt(diag(V1))]
    
    %% second margin stuff
    [theta2m,~,~,resids2] = ARMAX_2(rets1(:,j),mean_order(j,1),mean_order(j,2));
    resids2 = [zeros(max(mean_order(j,1),mean_order(j,2)),1);resids2];
    scores2m = LLgrad_1('ARMA_LLa',theta2m,mean_order(j,1),mean_order(j,2),rets1(:,j));
    [theta2v, ~,~,hhat2,~,~,~,~,hess,scores2v]= RealGARCHestimate([data(:,j) datarv(:,j)],'SKEWT');
    hess2v = hess;  % Kevin's code returns the inverse hessian - I convert it back to the hessian here, then divide by T
    stdresids2 = resids2./sqrt(hhat2);
    theta2s = outSKEWT(j,:)';
    theta2 = [theta2m;theta2v;theta2s];
    scores2s = LLgrad_1('skewtdis_LLa',theta2s,stdresids2);
    scores2 = [scores2m,scores2v,scores2s];
    B2 = newey_west(scores2,floor(T^(1/3)));
    H2 = zeros(size(scores2,2),size(scores2,2));
    H2m = hessian('ARMA_LL',theta2m,mean_order(j,1),mean_order(j,2),rets1(:,j))/T;
    H2v = hess2v;
    H2s = hessian_2stage('skewtdis_ARMA_RealGARCH_LL',theta2,length(theta2s),[],[data(:,j) datarv(:,j)],mean_order(j,1),mean_order(j,2),1,1)/T;
    H2(1:length(theta2m),1:length(theta2m)) = H2m;
    H2(length(theta2m)+1:length(theta2m)+length(theta2v)  ,length(theta2m)+1:length(theta2m)+length(theta2v)) = H2v;
    H2(end-1:end,:) = H2s;
    V2 = inv(H2)*B2*(inv(H2)')/T;  % avar[thetahat] = Ainv*B*Ainv, so V[thetahat] ~~ Ainv*B*Ainv/T
    [theta2,sqrt(diag(V2)),theta2./sqrt(diag(V2))]
    
    
    %% copula stuff: TV
    uu=2;  % parametric margins
    % Rot Gumbel copula
    scoresc = LLgrad_1('Rotgumbel_GAS_CLa',kappa7b3(:,pp),Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
    scoresALL = [scores1,scores2,scoresc];
    BB = newey_west(scoresALL,floor(T^(1/3)));
    thetac = kappa7b3(:,pp);
    kappa7b3(:,pp)'
    tic;
    Hc = hessian_2stage('my_margin_margin_copula_CL1',...
        [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
        'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','Rotgumbel_GAS_CL',...
        size(theta1,1),size(theta2,1),4,4,...
        mean_order(i,1),mean_order(i,2),1,1,...
        mean_order(j,1),mean_order(j,2),1,1,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)])/T;
    toc  % 45 seconds
    thetaALLmle = [theta1;theta2;thetac];
    HH = zeros(length(thetaALLmle),length(thetaALLmle));
    HH(1:length(theta1),1:length(theta1)) = H1;
    HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
    HH(end-length(thetac)+1:end,:) = Hc;
    VALL = inv(HH)*BB*(inv(HH)')/T;
    eig(VALL)
    [theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
    [theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
    [thetaALLmle,sqrt(diag(VALL))]
    table8a([2;4;6],1,pp) = sqrt(diag(VALL(end-2:end,end-2:end)));
    fprintf('Rotated Gumbel standard errors pair %s: %10.4f, %10.4f,%10.4f \n',pairs{pp},sqrt(diag(VALL(end-2:end,end-2:end)))')
    
    % Normal GAS copula
    scoresc = LLgrad_1('bivnorm_tv_GAS_CLa',theta1tv1(:,pp),Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));
    scoresALL = [scores1,scores2,scoresc];
    BB = newey_west(scoresALL,floor(T^(1/3)));
    thetac = theta1tv1(:,pp);
    theta1tv1(:,pp)'
    tic;
    hstep0 = -eps.^(1/3)*max(abs([theta1;theta2;thetac]),1e-2);
    hstep5 = hstep0;
    hstep5(end-length(thetac)+1:end) = -ones(length(thetac),1)*1e-3;  %
    Hc = hessian_2stage('my_margin_margin_copula_CL1',...
        [theta1;theta2;thetac],size(thetac,1),[],[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
        'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','bivnorm_tv_GAS_CL',...
        size(theta1,1),size(theta2,1),4,4,...
        mean_order(i,1),mean_order(i,2),1,1,...
        mean_order(j,1),mean_order(j,2),1,1,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1))/T;
    toc  % 65 seconds
    thetaALLmle = [theta1;theta2;thetac];
    HH = zeros(length(thetaALLmle),length(thetaALLmle));
    HH(1:length(theta1),1:length(theta1)) = H1;
    HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
    HH(end-length(thetac)+1:end,:) = Hc;
    VALL = inv(HH)*BB*(inv(HH)')/T;
    eig(VALL)
    [theta1,sqrt(diag(V1)),sqrt(diag(VALL(1:length(theta1),1:length(theta1))))]
    [theta2,sqrt(diag(V2)),sqrt(diag(VALL(1+length(theta1):length(theta1)+length(theta2),1+length(theta1):length(theta1)+length(theta2))))]
    [thetaALLmle,sqrt(diag(VALL))]
    table8a([9;11;13],1,pp) = sqrt(diag(VALL(end-2:end,end-2:end)));
    fprintf('Normal GAS standard errors pair %s: %10.4f, %10.4f,%10.4f \n',pairs{pp},sqrt(diag(VALL(end-2:end,end-2:end)))')
    
    % Student's t copula
    % WARNING: THIS PART IS PRETTY SLOW
    tic;scoresc = LLgrad_1('tcopula_GAS_CLa',theta8tv2(:,pp),Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);toc  % takes 35 seconds
    scoresALL = [scores1,scores2,scoresc];
    BB = newey_west(scoresALL,floor(T^(1/3)));
    thetac = theta8tv2(:,pp);  %  0.019872     0.065285      0.99121     0.088728
    tic;
    hstep0 = -eps.^(1/3)*max(abs([theta1;theta2;thetac]),1e-2);
    hstep5 = hstep0;
    hstep5(end-length(thetac)+1:end) = -ones(length(thetac),1)*1e-3;  % it turned out to require some tinkering with the step size to get a reasonable-looking VCV matrix. This step size for the bottom rows works OK
    Hc = hessian_2stage('my_margin_margin_copula_CL1',...
        [theta1;theta2;thetac],size(thetac,1),hstep5,[data(:,pair(pp,:)) datarv(:,pair(pp,:))],...
        'skewtdis_ARMA_RealGARCH_LL','skewtdis_ARMA_RealGARCH_LL','tcopula_GAS_CL',...
        size(theta1,1),size(theta2,1),4,4,...
        mean_order(i,1),mean_order(i,2),1,1,...
        mean_order(j,1),mean_order(j,2),1,1,thetaALL(8,1,uu,pp),RR,NN,HESSstudt)/T;toc  % takes 13 minutes
    
    thetaALLmle = [theta1;theta2;thetac];
    HH = zeros(length(thetaALLmle),length(thetaALLmle));
    HH(1:length(theta1),1:length(theta1)) = H1;
    HH(length(theta1) + (1:length(theta2)),length(theta1) + (1:length(theta2))) = H2;
    HH(end-length(thetac)+1:end,:) = Hc;
    VALL = inv(HH)*BB*(inv(HH)')/T;
    eig(VALL)
    table8a([16;18;20;22],1,pp) = sqrt(diag(Hc(end-3:end,end-3:end)));
end
table8c=table8(:,[1 3],:);

for pp=1:size(pair,1)
    % save path+file name
    tabName=[save_path,save_name,'table8c',pairs{pp},'.tex'];
    caption = ['Time-varying copula model parameter estimates for RealGARCH model. Pair ',pairs{pp},', number of simulations ',...
        num2str(bootreps),'. Stdandard errors are estimated based on stationary bootstraping.'];
    label = ['UnivRGTv',pairs{pp}];
    table8Latex(table8c(:,:,pp),tabName,caption,label,pairs{pp})  
end

% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_8.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_8.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GOODNESS OF FIT TESTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

table9 = nan(8+8,4,size(pair,1));  % first 8 rows are parametric, last 8 are semipara ; cols are KSc, CVMc, KSr, CVMr
% Note that I'm not replicating the "naive" test results reported in the chapter here, as those also require a simulation but are not correct 
% (so they're a pain AND they're wrong!)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parametric margins, constant copula
% KS and CVM on the copula directly

uu=2;  % skew t margins

for pp=1:size(pair,1)
[KSstat1, CVMstat1] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'NormalCopula_cdf',thetaALL(1,1,uu,pp));
[KSstat2, CVMstat2] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'clayton_cdf',thetaALL(2,1,uu,pp));
[KSstat3, CVMstat3] = copula_GOF_stats(1-Uall(:,pair(pp,:),uu),'gumbel_cdf',thetaALL(7,1,uu,pp));
[KSstat4, CVMstat4] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'tCopula_cdf_new',thetaALL(8,1:2,uu,pp)');
[KSstat5, CVMstat5] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'sym_jc_cdf_new',thetaALL(9,2,uu,pp),thetaALL(9,1,uu,pp));
                                                                                % tauU then tauL
GOFstats111(:,:,pp) = [[KSstat1;KSstat2;KSstat3;KSstat4;KSstat5],[CVMstat1;CVMstat2;CVMstat3;CVMstat4;CVMstat5]];
    for cc=1:5;
        for tt=1:2; % structure of GOFsim1(boot,[KS CV],cc,pp)
            table9(cc,tt,pp) = mean(GOFsim1(:,tt,cc,pp)>GOFstats111(cc,tt,pp));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nonparametric margins, constant copula
% KS and CVM on the copula directly

uu=1; % EDF margins

for pp=1:size(pair,1)
[KSstat1, CVMstat1] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'NormalCopula_cdf',thetaALL(1,1,uu,pp));
[KSstat2, CVMstat2] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'clayton_cdf',thetaALL(2,1,uu,pp));
[KSstat3, CVMstat3] = copula_GOF_stats(1-Uall(:,pair(pp,:),uu),'gumbel_cdf',thetaALL(7,1,uu,pp));
[KSstat4, CVMstat4] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'tCopula_cdf_new',thetaALL(8,1:2,uu,pp)');
[KSstat5, CVMstat5] = copula_GOF_stats(Uall(:,pair(pp,:),uu),'sym_jc_cdf_new',thetaALL(9,2,uu,pp),thetaALL(9,1,uu,pp));
   
GOFstats111(:,:,pp) = [[KSstat1;KSstat2;KSstat3;KSstat4;KSstat5],[CVMstat1;CVMstat2;CVMstat3;CVMstat4;CVMstat5]];
    for cc=1:5;
        for tt=1:2;
            table9(8+cc,tt,pp) = mean(GOFsim3(:,tt,cc,pp)>GOFstats111(cc,tt,pp));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parametric margins, constant copula
% KS and CVM on the Rosenblatt transforms

uu=2; % skew t margins

for pp=1:size(pair,1)
    Vhat1 = Uall(:,pair(pp,1),uu);
    Vhat2all = nan(T,5,size(pair,1));
    for cc=1:5;
        if cc==1;
            Vhat2all(:,cc) = normcdf(norminv(Uall(:,pair(pp,2),uu)),thetaALL(1,1,uu,pp)*norminv(Vhat1),sqrt(1-thetaALL(1,1,uu,pp)^2));  % conditional copula of V2 | V1
        elseif cc==2
            Vhat2all(:,cc) = ClaytonUgivenV_t(Uall(:,pair(pp,2),uu),Vhat1,0,thetaALL(2,1,uu,pp));  % conditional distribution of U2 | U1
        elseif cc==3
            Vhat2all(:,cc) = GumbelUgivenV_t(1-Uall(:,pair(pp,2),uu),1-Vhat1,0,thetaALL(7,1,uu,pp));  % conditional distribution of U2 | U1
        elseif cc==4;
            Vhat2all(:,cc) = mvt_cond_cdf(tinv(Uall(:,pair(pp,2),uu),1/thetaALL(8,2,uu,pp)),tinv(Vhat1,1/thetaALL(8,2,uu,pp)),zeros(1,2),[[1,thetaALL(8,1,uu,pp)];[thetaALL(8,1,uu,pp),1]],1/thetaALL(8,2,uu,pp));
        elseif cc==5
            Vhat2all(:,cc)=sjcUgivenV_t(Uall(:,pair(pp,2),uu),Vhat1,0,thetaALL(9,2,uu,pp),thetaALL(9,1,uu,pp)); % 
        end
    end

    [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2all(:,1)],'IndepCop_cdf');
    [KSstat2, CVMstat2] = copula_GOF_stats([Vhat1,Vhat2all(:,2)],'IndepCop_cdf');
    [KSstat3, CVMstat3] = copula_GOF_stats([Vhat1,Vhat2all(:,3)],'IndepCop_cdf');
    [KSstat4, CVMstat4] = copula_GOF_stats([Vhat1,Vhat2all(:,4)],'IndepCop_cdf');
    [KSstat5, CVMstat5] = copula_GOF_stats([Vhat1,Vhat2all(:,5)],'IndepCop_cdf');

    GOFstats111(:,:,pp) = [[KSstat1;KSstat2;KSstat3;KSstat4;KSstat5],[CVMstat1;CVMstat2;CVMstat3;CVMstat4;CVMstat5]];
    for mm=1:5;
        for tt=1:2;
            table9(mm,2+tt,pp) = mean(GOFsim10(:,tt,mm,pp)>GOFstats111(mm,tt,pp));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nonparametric margins, constant copula
% KS and CVM on the Rosenblatt transforms

uu=1; % EDF margins
for pp=1:size(pair,1)
    Vhat1 = Uall(:,pair(pp,1),uu);
    Vhat2all = nan(T,5,size(pair,1));
    for cc=1:5;
        if cc==1;
            Vhat2all(:,cc) = normcdf(norminv(Uall(:,pair(pp,2),uu)),thetaALL(1,1,uu,pp)*norminv(Vhat1),sqrt(1-thetaALL(1,1,uu,pp)^2));  % conditional copula of V2 | V1
        elseif cc==2
            Vhat2all(:,cc) = ClaytonUgivenV_t(Uall(:,pair(pp,2),uu),Vhat1,0,thetaALL(2,1,uu,pp));  % conditional distribution of U2 | U1
        elseif cc==3
            Vhat2all(:,cc) = GumbelUgivenV_t(1-Uall(:,pair(pp,2),uu),1-Vhat1,0,thetaALL(7,1,uu,pp));  % conditional distribution of U2 | U1
        elseif cc==4;
            Vhat2all(:,cc) = mvt_cond_cdf(tinv(Uall(:,pair(pp,2),uu),1/thetaALL(8,2,uu,pp)),tinv(Vhat1,1/thetaALL(8,2,uu,pp)),zeros(1,2),[[1,thetaALL(8,1,uu,pp)];[thetaALL(8,1,uu,pp),1]],1/thetaALL(8,2,uu,pp));
        elseif cc==5
            Vhat2all(:,cc)=sjcUgivenV_t(Uall(:,pair(pp,2),uu),Vhat1,0,thetaALL(9,2,uu,pp),thetaALL(9,1,uu,pp)); % 
        end
    end

    [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2all(:,1)],'IndepCop_cdf');
    [KSstat2, CVMstat2] = copula_GOF_stats([Vhat1,Vhat2all(:,2)],'IndepCop_cdf');
    [KSstat3, CVMstat3] = copula_GOF_stats([Vhat1,Vhat2all(:,3)],'IndepCop_cdf');
    [KSstat4, CVMstat4] = copula_GOF_stats([Vhat1,Vhat2all(:,4)],'IndepCop_cdf');
    [KSstat5, CVMstat5] = copula_GOF_stats([Vhat1,Vhat2all(:,5)],'IndepCop_cdf');

    GOFstats111(:,:,pp) = [[KSstat1;KSstat2;KSstat3;KSstat4;KSstat5],[CVMstat1;CVMstat2;CVMstat3;CVMstat4;CVMstat5]];
    for mm=1:5;
        for tt=1:2;
            table9(8+mm,2+tt,pp) = mean(GOFsim30(:,tt,mm,pp)>GOFstats111(mm,tt,pp));
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parametric margins, time varying copula
% KS and CVM on the Rosenblatt transforms

uu=2;  % skew t margins

for pp=1:size(pair,1)

    Vhat1 = Uall(:,pair(pp,1),uu);
    Vhat2all = nan(T,6,size(pair,1));
    for cc=1:3; 
        if cc==1
            [CL,kappat,ft] = Rotgumbel_GAS_CL(table8([1;3;5],1,pp),Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % getting the time path of the copula parameter
            Vhat2all(:,cc) = GumbelUgivenV_t(1-Uall(:,pair(pp,2),uu),1-Vhat1,0,kappat);  % conditional distribution of U2 | U1
        elseif cc==2
            % getting the Rosenblatt transformations to use in GOF tests
            [CL,rho1t,ft] = bivnorm_tv_GAS_CL(table8([8;10;12],1,pp),Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));
            for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
            Vhat2all(tt,cc) = normcdf(norminv(Uall(tt,pair(pp,2),uu)),rho1t(tt)*norminv(Vhat1(tt)),sqrt(1-rho1t(tt)^2));  % conditional copula of V2 | V1
            end

        elseif cc==3;
            [CL,rhot,ft] = tcopula_GAS_CL(table8([15;17;19;21],1,pp),Uall(:,pair(pp,:),uu),thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
            for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                Vhat2all(tt,cc) = mvt_cond_cdf(tinv(Uall(tt,pair(pp,2),uu),1/table8(21,1,pp)),tinv(Vhat1(tt),1/table8(21,1,pp)),zeros(1,2),[[1,rhot(tt)];[rhot(tt),1]],1/table8(21,1,pp));
            end
        end
    end

    [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2all(:,1)],'IndepCop_cdf');
    [KSstat2, CVMstat2] = copula_GOF_stats([Vhat1,Vhat2all(:,2)],'IndepCop_cdf');
    [KSstat3, CVMstat3] = copula_GOF_stats([Vhat1,Vhat2all(:,3)],'IndepCop_cdf');

    GOFstats112(:,:,pp) = [[KSstat1;KSstat2;KSstat3],[CVMstat1;CVMstat2;CVMstat2]];
    for mm=1:3;
        for tt=1:2;
            table9(5+mm,2+tt,pp) = mean(GOFsim100(:,tt,mm,pp)>GOFstats112(mm,tt,pp));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nonparametric margins, time varying copula
% KS and CVM on the Rosenblatt transforms

% Note that the method below does not (yet) have theoretical foundation. I am treating the EDF below in the same way as the parametric margin case,
% but this approach still needs a formal result showing that it is appropriate.

uu=1; % EDF margins

% WARNING: THIS PART IS VERY SLOW!

bootreps = 4; % make it 100
GOFsim120 = nan(bootreps,2,3,size(pair,1));
tic;
for pp=1:size(pair,1)
    for bb=1:bootreps
        % First simulate from the copula
        U1 = Rotgumbel_GAS_rnd(table8([1;3;5],1,pp),T,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);
        U2 = bivnorm_tv_GAS_rnd(table8([8;10;12],1,pp),T,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1)); 
        U3 = tcopula_GAS_rnd(table8([15;17;19;21],1,pp),T,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
        UUU(:,:,1,pp) = U1;
        UUU(:,:,2,pp) = U2;
        UUU(:,:,3,pp) = U3;
        % then obtain the std resids
        EEE = nan(size(UUU));  
        if pp==1
        for cc=1:3;
            for mm=1:2;
                EEE(:,mm,cc,pp) = quantile(stdresids(:,mm),UUU(:,mm,cc,pp),1);  % using empirical dist fn to get std resids (and using linear interpolation to smooth it out a bit). This is where the nonparam bit is
            end
        end
        elseif pp==2
            for cc=1:3;
                EEE(:,1,cc,pp) = quantile(stdresids(:,1),UUU(:,1,cc,pp),1);  % using empirical dist fn to get std resids (and using linear interpolation to smooth it out a bit). This is where the nonparam bit is
                EEE(:,2,cc,pp) = quantile(stdresids(:,3),UUU(:,2,cc,pp),1);  % using empirical dist fn to get std resids (and using linear interpolation to smooth it out a bit). This is where the nonparam bit is
            end
        elseif pp==3
            for cc=1:3;
                EEE(:,1,cc,pp) = quantile(stdresids(:,2),UUU(:,1,cc,pp),1);  % using empirical dist fn to get std resids (and using linear interpolation to smooth it out a bit). This is where the nonparam bit is
                EEE(:,2,cc,pp) = quantile(stdresids(:,3),UUU(:,2,cc,pp),1);  % using empirical dist fn to get std resids (and using linear interpolation to smooth it out a bit). This is where the nonparam bit is
            end
        end
        % next obtain the marginal dynamics
        HHH = nan(size(UUU));  % vol
        YYY = nan(size(UUU));  % simulated raw data
        for cc=1:3
            for mm=1:2;
                if pp==1 
                            if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                            else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                            end
                elseif pp==2       
                     if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams1,GARCHparams(:,1),sigmau1(1),varResids(1),EEE(:,mm,cc,pp));
                     else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                     end
                 else
                    if mm==1
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams2,GARCHparams(:,2),sigmau1(2),varResids(2),EEE(:,mm,cc,pp));
                    else
                                 [ YYY(:,mm,cc,pp),  HHH(:,mm,cc,pp)] =simRealGARCH(T,ARparams3,GARCHparams(:,3),sigmau1(3),varResids(3),EEE(:,mm,cc,pp));
                    end          
                end
            end
        end

        for cc=1:3;
            if pp==1
            % now estimate the models on the simulated data
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),0,0);
           
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            elseif pp==2
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            else
            [~,~,~,resids_1boot] = ARMAX_2(YYY(:,1,cc,pp),0,0);
            [~,~,~,resids_2boot] = ARMAX_2(YYY(:,2,cc,pp),2,0);
            resids_2boot=[zeros(2,1);resids_2boot];
            [~, ~,~,hhat1boot,~,~,~,~] = RealGARCHestimate([resids_1boot HHH(:,1,cc,pp)],'SKEWT');
            [~, ~,~,hhat2boot,~,~,~,~] = RealGARCHestimate([resids_2boot HHH(:,2,cc,pp)],'SKEWT');
            end
            stdresids1 = resids_1boot./sqrt(hhat1boot);
            stdresids2 = resids_2boot./sqrt(hhat2boot);
            Uhat = empiricalCDF([stdresids1,stdresids2]);  % using EDF to get unif variables
%             end
            
            if cc==1
                % 7. Rotated Gumbel GAS copula
                lower = [-3 ; -3 ; 0 ];
                upper = [ 3 ; 3 ; 0.999 ];
                kappa8b3b = fmincon('Rotgumbel_GAS_CL',kappa7tvs,[],[],[],[],lower,upper,[],options,Uhat,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);

                % getting the Rosenblatt transformations to use in GOF tests
                [CL,kappat,ft] = Rotgumbel_GAS_CL(kappa8b3b,Uhat,thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % getting the time path of the copula parameter
                Vhat1 = 1-Uhat(:,1);
                Vhat2 = GumbelUgivenV_t(1-Uhat(:,2),1-Uhat(:,1),0,kappat);  % conditional distribution of U2 | U1
            elseif cc==2
                % Normal copula
                lower = [-3 ; -3 ; 0     ];
                upper = [ 3 ;  3 ; 0.999 ];
                theta1tv1b = fmincon('bivnorm_tv_GAS_CL',theta1tv1,[],[],[],[],lower,upper,[],options,Uhat,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));  % about 30 minuts
                
                % getting the Rosenblatt transformations to use in GOF tests
                [CL,rho1t,ft] = bivnorm_tv_GAS_CL(theta1tv1b,Uhat,thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));
                Vhat1 = Uhat(:,1);
                Vhat2 = nan(T,1);
                for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                Vhat2(tt) = normcdf(norminv(Uhat(tt,2)),rho1t(tt)*norminv(Uhat(tt,1)),sqrt(1-rho1t(tt)^2));  % conditional copula of V2 | V1
                end
            elseif cc==3
                % 8. Student's t copula
                lower = [-3 ; -3 ; 0     ; 0.01];
                upper = [ 3 ;  3 ; 0.999 ; 0.45];
                theta8tv2b = fmincon('tcopula_GAS_CL',theta8tvs,[],[],[],[],lower,upper,[],options,Uhat,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
                [CL,rhot,ft] = tcopula_GAS_CL(theta8tv2b,Uhat,thetaALL(8,1,uu,pp),RR,NN,HESSstudt);
                
                % getting the Rosenblatt transformations
                Vhat1 = Uhat(:,1);
                Vhat2 = nan(T,1);
                for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                    Vhat2(tt) = mvt_cond_cdf(tinv(Uhat(tt,2),1/theta8tv2b(end)),tinv(Uhat(tt,1),1/theta8tv2b(end)),zeros(1,2),[[1,rhot(tt)];[rhot(tt),1]],1/theta8tv2b(end));
                end
            end
            [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2],'IndepCop_cdf');
            GOFsim120(bb,:,cc,pp) = [KSstat1 CVMstat1];
            fmtspec='KS and CVM for non-parametric TV copulas: Loop %10.0f of %-10.0f, pair %s \n';
            fprintf(fmtspec,bb,bootreps,pairs{pp})  % takes about 34 sec per loop
        end
    end
end
    toc  % took 27.2 hours
    
uu=1;
for pp=1:size(pair,1)
    Vhat1 = Uall(:,pair(pp,1),uu);
    Vhat2all = nan(T,3,size(pair,1));
    for cc=1:3;
        if cc==1
            [CL,kappat,ft] = Rotgumbel_GAS_CL(kappa7tvs,Uall(:,pair(pp,:),uu),thetaALL(7,1,uu,pp),[KK,HESSgumbel(:,1)]);  % getting the time path of the copula parameter
            Vhat2all(:,cc,pp) = GumbelUgivenV_t(1-Uall(:,pair(pp,2),uu),1-Uall(:,pair(pp,1),uu),0,kappat);  % conditional distribution of U2 | U1
        elseif cc==2;
            [CL,rho1t,ft] = bivnorm_tv_GAS_CL(theta1tv1b,Uall(:,pair(pp,:),uu),thetaALL(1,1,uu,pp),RR,HESSnorm(:,1));
            for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                Vhat2all(tt,cc,pp) = normcdf(norminv(Uall(tt,2,uu)),rho1t(tt)*norminv(Uall(tt,1,uu)),sqrt(1-rho1t(tt)^2));  % conditional copula of V2 | V1
            end           
        elseif cc==3;
            [CL,rhot,ft] = tcopula_GAS_CL(theta8tvs,Uall(:,pair(pp,:),uu),thetaALL(8,1,uu),RR,NN,HESSstudt);
            for tt=1:T;  % need to loop over t as my "mvt_cond_cdf" functino does not accept time-varying inputs (it assumes that the correlatino and DoF are constant)s
                Vhat2all(tt,cc,pp) = mvt_cond_cdf(tinv(Uall(tt,2,uu),1/theta8tv2(end,pp)),tinv(Uall(tt,1,uu),1/theta8tv2(end,pp)),zeros(1,2),[[1,rhot(tt)];[rhot(tt),1]],1/theta8tv2(end,pp));
            end
        end
    end
    [KSstat1, CVMstat1] = copula_GOF_stats([Vhat1,Vhat2all(:,1,pp)],'IndepCop_cdf');
    [KSstat2, CVMstat2] = copula_GOF_stats([Vhat1,Vhat2all(:,2,pp)],'IndepCop_cdf');
    [KSstat3, CVMstat3] = copula_GOF_stats([Vhat1,Vhat2all(:,3,pp)],'IndepCop_cdf');    
    GOFstats113(:,:,pp) = [[KSstat1;KSstat2;KSstat3],[CVMstat1;CVMstat2;CVMstat3]];
end

for pp=1:size(pair,1)
    for mm=1:3;
        for tt=1:2;
            table9(8+5+mm,2+tt,pp) = mean(GOFsim120(:,tt,mm,pp)>GOFstats113(mm,tt,pp));
        end
    end
end


for pp=1:size(pair,1)
    % save path+file name
    tabName=[save_path,save_name,'table9',pairs{pp},'.tex'];
    info.fid=fopen(tabName,'w');
    
    % LaTEX table header
    h1 = '\begin{table}';
    h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrr}\toprule';
    h3 = ['& \multicolumn{4}{c}{',pairs{pp},'} \\ '];
    h4 = '& \multicolumn{4}{c}{Parametric}\\';
    h5 = '\cmidrule{2-5}';
    fprintf(info.fid,'%s \n',h1,h2,h3,h4,h5);
    
    % Body of the table
    info.fmt = strvcat('%10.2f');
    info.cnames = strvcat('$KS_C$','$CvM_C$','$KS_R$','$CvM_R$');
    info.rnames = strvcat(' ','Normal','Clayton','Rot Gumbel','Student''s \emph{t}','SJC','Rot $Gumbel_{GAS}$','$Normal_{GAS}$','Student''s $t_{GAS}$');
    lprint_KA(table9(1:8,:,pp),info)
    
    h6 = '& \multicolumn{4}{c}{Semiparametric}\\';
    h7 = '\cmidrule{2-5}';
    fprintf(info.fid,'%s \n',h6,h7);
    info.fmt = strvcat('%10.2f');
    info.cnames = strvcat('$KS_C$','$CvM_C$','$KS_R$','$CvM_R$');
    info.rnames = strvcat(' ','Normal','Clayton','Rot Gumbel','Student''s \emph{t}','SJC','Rot $Gumbel_{GAS}$','$Normal_{GAS}$','Student''s $t_{GAS}$');
       
    lprint_KA(table9(9:16,:,pp),info)
    
    % LaTEX table footer
    t1 = '  \bottomrule ';
    t2 = '\end{tabular*}  ';
    t3 = ['\caption{Goodness of fit tests for copula models, pair ',pairs{pp},'. KS and CvM refer to the Kolmogorov-Smirnov and Cramer-von Mises tests respectively.']; 
    t4 = 'The subscripts C and R refer to whether the test was applied to the empirical copula of the standardized residuals, or to the empirical copula of the Rosenblatt transform of these residuals. }';
    t5 = ['\label{tab:UnivGof',pairs{pp},'}'];
    t6 = '\end{table}';
    fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5,t6);
end

% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_9.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_9.mat'';'];
evalin('base',temp_str);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUT OF SAMPLE MODEL COMPARISONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options = optimset('Algorithm','interior-point','Display','off','TolCon',10^-12,'TolFun',10^-4,'TolX',10^-6,'MaxIter',100,'DiffMaxChange',Inf,'DiffMinChange',0 );  % 24apr12: decreasing MaxIter here - it only goes above about 20 when there is a problem, so no need to keep it at default of 400.

table10 = nan(8+2+8+2+1,8,nIndices);

R = floor(0.75*T);  % in sample size. Arbitrary choosing 60% length of the series.
P = T-R;  % out of sample size

% Conditional mean models for the in-sample.
residsR = nan(R,nIndices);
mean_order = nan(2,nIndices);
tic;
for ii=1:nIndices
    [theta1,sig21,vcv1,order1,resids1] = ARMAX_opt(rets1(1:R,ii),5,5,'BIC');  % takes about 6 seconds per variable
    mean_order(ii,1:2) = order1';
    mean_order(ii,3) = 1-sig21/cov(rets1(1:R,ii));
    residsR(:,ii) = [zeros(max(order1),1);resids1];
    [ii,toc]
end
toc  % takes 15 seconds for each series
mean_order % the same as full sample i.e. constant mean. For SP500 AR(2)

MEANparams1 =mean(rets1(1:R,1));
MEANparams2 =mean(rets1(1:R,2));
temp1 = ols(rets1(3:R,3),[ones(R-2,1),rets1(2:R-1,3),rets1(1:R-2,3)]);
MEANparams3 = temp1.beta;
%MEANparams3 =mean(rets1(1:R,3));


for ii=1:2
residsIS(:,ii)= rets1(1:R,ii)- mean(rets1(1:R,ii));
end
residsIS(:,3)=[0;0;temp1.resid];
%volatility models
hhatIS = nan(R,nIndices);
tic;
for ii=1:nIndices
    dataIS(:,ii)=residsIS(:,ii)/std(residsIS(:,ii));
    datarvIS(:,ii)=rvdata(:,ii)/std(rvdata(:,ii));
    [GARCHparamsIS(:,ii), ~,~,hhatIS(:,ii),~,~,~] = RealGARCHestimate([dataIS(:,ii) datarvIS(1:R,ii)],'SKEWT');
end
stdresidsIS = dataIS./sqrt(hhatIS);
% GARCHparamsIS = [GARCHparams1IS,GARCHparams2IS(1:3),GARCHparams2IS(1:3)];

% margins. For Gold in-sample skew-t fits better
lower = [2.1, -0.99];
upper = [Inf, 0.99 ];
theta0 = [6;0];
tic;
for ii=1:nIndices;
    
        theta1 = fmincon('skewtdis_LL',theta0,[],[],[],[],lower,upper,[],options,stdresidsIS(:,ii));
        outSKEWTIS(ii,:) = theta1';
    
end
toc 
outSKEWTIS

% Plot of histogram of stdresIS against fitted density, and QQ plot
fig=figure(801);
set (fig,'PaperUnits','points','Position',[100 100 1150 650],'Color',[1 1 1]) %  
set (gca,'FontSize',14) %
bins=50;
ee = (-5:0.01:5)';
ii=1;[temp1,temp2] = hist(stdresidsIS(:,ii),bins);
subplot(2,3,1),bar(temp2,temp1/(R*(max(stdresidsIS(:,ii))-min(stdresidsIS(:,ii)))/bins),'c');hold on;plot(ee,skewtdis_pdf(ee,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),'r','LineWidth',2),title('Gold'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skwed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;
ii=2;[temp1,temp2] = hist(stdresidsIS(:,ii),bins);
subplot(2,3,2),bar(temp2,temp1/(R*(max(stdresidsIS(:,ii))-min(stdresidsIS(:,ii)))/bins),'c');hold on;plot(ee,skewtdis_pdf(ee,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),'r-','LineWidth',2),title('Crude Oil'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skwed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;
ii=3;[temp1,temp2] = hist(stdresidsIS(:,ii),bins);
subplot(2,3,3),bar(temp2,temp1/(R*(max(stdresidsIS(:,ii))-min(stdresidsIS(:,ii)))/bins),'c');hold on;plot(ee,skewtdis_pdf(ee,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),'r-','LineWidth',2),title('SP500'),xlabel('x'),ylabel('f(x)'),legend('Data','Fitted skewed t',2),axis([min(ee),max(ee),0,0.55]); grid on; hold off;

ii=1;qq = sort(empiricalCDF(stdresidsIS(:,ii)));
subplot(2,3,4),plot(skewtdis_inv(qq,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),sort(stdresidsIS(:,ii)),'bo');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;
ii=2;qq = sort(empiricalCDF(stdresidsIS(:,ii)));
subplot(2,3,5),plot(skewtdis_inv(qq,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),sort(stdresidsIS(:,ii)),'bo');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;
ii=3;qq = sort(empiricalCDF(stdresidsIS(:,ii)));
subplot(2,3,6),plot(skewtdis_inv(qq,outSKEWTIS(ii,1),outSKEWTIS(ii,2)),sort(stdresidsIS(:,ii)),'bo');hold on;plot([-10,10],[-10,10],'r--','LineWidth',2),axis([-4.5,4.5,-4.5,4.5]),xlabel('Model quantile'),ylabel('Empirical quantile');grid on;

% PIT variables
UhatIS = nan(T,nIndices,2);  % day ; [margin1, margin2, margin3] ; [nonparam , skewt]
for mm=1:3;
    UhatIS(1:R,mm,1) = empiricalCDF(stdresidsIS(:,mm));
    
    UhatIS(1:R,mm,2) = skewtdis_cdf(stdresidsIS(:,mm),outSKEWTIS(mm,1),outSKEWTIS(mm,2));
     
end

% copula models
KAPPAhatIS = nan(4,8,2,nIndices);  % parameter (nan if num params<4) ; [Normal, Clayton, RGum, Studt] ; [nonparam, skewt]
tic;
for pp=1:nIndices
    for uu=1:2
        % 1. Normal Copula
        KAPPAhatIS(1,1,uu,pp) = corrcoef12(norminv(UhatIS(1:R,pair(pp,:),uu)));
        % 2. Clayton's copula
        lower = 0.0001;    warning off;
        KAPPAhatIS(1,2,uu,pp) = fmincon('claytonCL',thetaALL(2,1,2,pp),[],[],[],[],lower,[],[],options,UhatIS(1:R,pair(pp,:),uu));
        % 7. Rotated Gumbel copula
        lower = 1.1;
        upper = 5;
        KAPPAhatIS(1,3,uu,pp) = fmincon('gumbelCL',thetaALL(7,1,2,pp),[],[],[],[],lower,upper,[],options,1-UhatIS(1:R,pair(pp,:),uu));
        % 8. Student's t copula
        lower = [-0.9 , 0.01 ];
        upper = [ 0.9 , 0.45 ];
        KAPPAhatIS(1:2,4,uu,pp) = fmincon('tcopulaCL2',thetaALL(8,:,2,pp)',[],[],[],[],lower,upper,[],options,UhatIS(1:R,pair(pp,:),uu));
        % 9. SJC copulas
        lower = [0 , 0 ];
        upper = [ 1 , 1 ];
        KAPPAhatIS(1:2,5,uu,pp) = fmincon('sym_jc_CL',thetaALL(9,[2,1],2,pp)',[],[],[],[],lower,upper,[],options,UhatIS(1:R,pair(pp,:),uu));
        KAPPAhatIS(1:2,5,uu,pp)=KAPPAhatIS([2,1],5,uu,pp); % putting tauL before tauU
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARALLELIZE FOR TV COPULAS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
parfor pp=1:nIndices
        for uu=1:2    
        % 7. Rotated Gumbel GAS copula
        lower = [-3 ; -3 ; 0 ];
        upper = [ 3 ; 3 ; 0.999 ];
        tempGmb(:,uu,pp) = fmincon('Rotgumbel_GAS_CL',kappa7b3(:,pp),[],[],[],[],lower,upper,[],options,UhatIS(1:R,pair(pp,:),uu),1.2,[KK,HESSgumbel(:,1)]);
        end
end
toc  % takes 33 mins for all 6 models and both types of margins (param, nonparm)
fmtspec='OOS comparison. Rotated Gumbel copula took %10.0f seconds.  \n';
fprintf(fmtspec,toc)

tic;
parfor pp=1:nIndices
        for uu=1:2    
        % 7. Normal copula
        lower = [-3 ; -3 ; 0     ];
        upper = [ 3 ;  3 ; 0.999 ];
        tempNorm(:,uu,pp)=fmincon('bivnorm_tv_GAS_CL',theta1tv1(:,pp),[],[],[],[],lower,upper,[],options,UhatIS(1:R,pair(pp,:),uu),KAPPAhatIS(1,1,uu,pp),RR,HESSnorm(:,1)); 
        end
end
toc  % takes 33 mins for all 6 models and both types of margins (param, nonparm)
fmtspec='OOS comparison. Normal copula took %10.0f seconds.  \n';
fprintf(fmtspec,toc)

tic;
parfor pp=1:nIndices
        for uu=1:2    
        % 8. Student's t copula
        lower = [-3 ; -3 ; 0     ; 0.01];
        upper = [ 3 ;  3 ; 0.999 ; 0.45];
        tempT(:,uu,pp)= fmincon('tcopula_GAS_CL',theta8tv2(:,pp),[],[],[],[],lower,upper,[],options,UhatIS(1:R,pair(pp,:),uu),KAPPAhatIS(1,4,uu,pp),RR,NN,HESSstudt);
        end
end
  % takes 33 mins for all 6 models and both types of margins (param, nonparm)
fmtspec='OOS comparison. T-copula took %10.0f seconds.  \n';
fprintf(fmtspec,toc)
% transfer estimated copula params
for pp=1:nIndices
    for uu=1:2
        KAPPAhatIS(1:3,6,uu,pp)=tempGmb(:,uu,pp);
        KAPPAhatIS(1:4,8,uu,pp)=tempT(:,uu,pp);
        KAPPAhatIS(1:3,7,uu,pp)=tempNorm(:,uu,pp);
    end
end

KAPPAhatIS

% OK, now we use these estimated parameters to obtain estimated mean, variance, and copula parameters through the OOS period
MUhatOOS = nan(T,nIndices);
VOL2hatOOS = nan(T,nIndices);
RVhatOOS= nan(T,nIndices); % Realized Volatility
KAPPAhatOOS = nan(T,2,8,2,nIndices);  % day ; [param1 (eg, kappa or rho), param2 (nu, for Stud t)] ; [Normal, Clayton, RGum, Studt, sjc, RGum-GAS, Normal-GAS Studt-GAS] ;  [nonparam, skewt];[pairs]

MUhatOOS(:,1) = MEANparams1;  % first margin had constant conditional mean
MUhatOOS(:,2) = MEANparams2;  % second margin had constant conditional mean
% MUhatOOS(:,3) = MEANparams3;  % second margin had constant conditional mean

MUhatOOS(:,3) = [rets1(1:2,3); [ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3)]*MEANparams3 ];  % cond mean for third margin
residsOOS = rets1 - MUhatOOS;

for ii=1:nIndices
residsOOS(:,ii)=residsOOS(:,ii)/std(residsOOS(:,ii));
end

VOL2hatOOS(1:R,:) = log(hhatIS(1:R,:));  
for ii=1:nIndices;
RVhatOOS(:,ii)=log(rvdata(:,ii)/std(rvdata(:,ii)));
end
for mm=1:nIndices;
    for tt=R+1:T;
            VOL2hatOOS(tt,mm) = GARCHparamsIS(1,mm) + GARCHparamsIS(2,mm)*VOL2hatOOS(tt-1,mm) ...
            + GARCHparamsIS(3,mm)*RVhatOOS(tt-1,mm); % predicted cond Vol.
            %RVhatOOS(tt,mm)=GARCHparamsIS(4,mm) + GARCHparamsIS(5,mm)*VOL2hatOOS(tt,mm); % predicted RV          
    end
end
VOL2hatOOS=exp(VOL2hatOOS);
RVhatOOS=exp(RVhatOOS);

stdresidsOOS = residsOOS./sqrt(VOL2hatOOS);

UhatOOS = nan(T,nIndices,2);
for mm=1:nIndices;
    UhatOOS(1:R,mm,:) = UhatIS(1:R,mm,:);
    
    UhatOOS(R+1:end,mm,1) = empiricalCDF(stdresidsOOS(1:R,mm),stdresidsOOS(R+1:end,mm));  % EDF from in-sample data evaluated at OOS std resids
    UhatOOS(R+1:end,mm,2) = skewtdis_cdf(stdresidsOOS(R+1:end,mm),outSKEWTIS(mm,1),outSKEWTIS(mm,2));  % skew t dis with IS params evaluated at OOS std resids
end

% when using in-sample EDF, there is a chance that an OOS PIT observation gets a value of 0, which causes problems below. so check for this:
min(UhatOOS)  % so there may be such a problem with the EDF margins, but OK for param margins

uu=1;
for mm=1:nIndices;    
temp124 = find(UhatOOS(R+1:end,mm,uu)<=0.0001);
    if ~isempty(temp124)  % if there are OOS PIT observations with value 0 make the replacement below.
    UhatOOS(R+temp124,mm,uu)
    UhatOOS(R+temp124,mm,uu) = 1/(2*R);  % pushing this below 1/R, but above 0. This maintains its rank
    end
end

uu=1;
for mm=1:nIndices;    
temp124 = find(UhatOOS(R+1:end,mm,uu)>=0.9999);
    if ~isempty(temp124)  % if there are OOS PIT observations with value 1 make the replacement below.
    UhatOOS(R+temp124,mm,uu)
    UhatOOS(R+temp124,mm,uu) = (R-1)/R;  % pushing this close to1 , but below 1. This maintains its rank
    end
end
% now getting parameters of the conditional copula
tic;
for pp=1:nIndices
    for uu=1:2;
        KAPPAhatOOS(:,1,1:5,uu,pp) = ones(T,1)*KAPPAhatIS(1,1:5,uu,pp);  % first four copulas all have constant parameters
        KAPPAhatOOS(:,2,4,uu,pp)   = ones(T,1)*KAPPAhatIS(2,  4,uu,pp);  % fourth copula (stud t) has constant DoF parameter
        KAPPAhatOOS(:,2,5,uu,pp)   = ones(T,1)*KAPPAhatIS(2,  5,uu,pp);  % 5th copula sjc tauU parameter        
        KAPPAhatOOS(:,2,8,uu,pp)   = ones(T,1)*KAPPAhatIS(4,  8,uu,pp);  % 8th copula (stud t-GAS) has constant DoF parameter

        % now need to get the time-varying copula parameters for the RGum and Studt GAS models
        [~,kappatIS] = Rotgumbel_GAS_CL(KAPPAhatIS(1:3,6,uu,pp),UhatOOS(1:R,pair(pp,:),uu),KAPPAhatIS(1,3,uu,pp),[KK,HESSgumbel(:,1)]);
        KAPPAhatOOS(1:R,1,6,uu,pp) = kappatIS;
        [~,rhotISn] = bivnorm_tv_GAS_CL(KAPPAhatIS(1:3,7,uu,pp),UhatOOS(1:R,pair(pp,:),uu),KAPPAhatIS(1,1,uu,pp),RR,HESSnorm(:,1));
        KAPPAhatOOS(1:R,1,7,uu,pp) = rhotISn;
        [~,rhotIS] = tcopula_GAS_CL( KAPPAhatIS(1:4,8,uu,pp),UhatOOS(1:R,pair(pp,:),uu),KAPPAhatIS(1,4,uu,pp),RR,NN,HESSstudt);
        KAPPAhatOOS(1:R,1,8,uu,pp) = rhotIS;
        for tt=R+1:T;
            kappatOOS = Rotgumbel_GAS_one_step(KAPPAhatIS(1:3,6,uu,pp),KAPPAhatOOS(tt-1,1,6,uu,pp),UhatOOS(tt-1,pair(pp,:),uu),KAPPAhatIS(1,3,uu,pp),[KK,HESSgumbel(:,1)]);
            KAPPAhatOOS(tt,1,6,uu,pp) = kappatOOS;
            rhotOOSn=bivnorm_tv_GAS_CL_one_step(KAPPAhatIS(1:3,7,uu,pp),KAPPAhatOOS(tt-1,1,7,uu,pp),UhatOOS(tt-1,pair(pp,:),uu),RR,HESSnorm(:,1));
            KAPPAhatOOS(tt,1,7,uu,pp) = rhotOOSn;
            rhotOOS = tcopula_GAS_one_step( KAPPAhatIS(1:4,8,uu,pp),KAPPAhatOOS(tt-1,1,8,uu,pp),UhatOOS(tt-1,pair(pp,:),uu),KAPPAhatIS(1,4,uu,pp),RR,NN,HESSstudt);
            KAPPAhatOOS(tt,1,8,uu,pp) = rhotOOS;
        end
    end
end
toc  % takes 65 seconds 

for pp=1:nIndices
fig=figure(20200+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,[kappatRotp(:,pp),squeeze(KAPPAhatOOS(:,1,[3,6],1,pp))]),hold on
line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','Color',[0 0 0])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2),'R','HorizontalAlignment','left','VerticalAlignment','top')
legend('In sample GAS','OOS const','OOS GAS',2),title(['Rot Gum pair ',pairs{pp}])
datetick('x')
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'InOOScompGum',pairs{pp},'.eps'],'psc2') %

fig=figure(20210+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,[rhotNormp(:,pp),squeeze(KAPPAhatOOS(:,1,[1,7],1,pp))]), hold on
line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','Color',[0 0 0])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2),'R','HorizontalAlignment','left','VerticalAlignment','top')
legend('In sample GAS','OOS const','OOS GAS',2),title(['Normal pair ',pairs{pp}])
datetick('x')
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'InOOScompN',pairs{pp},'.eps'],'psc2') 

fig=figure(20220+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,[rhotTp(:,pp),squeeze(KAPPAhatOOS(:,1,[4,8],1,pp))]),hold on
line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','Color',[0 0 0]),
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2),'R','HorizontalAlignment','left','VerticalAlignment','top')
legend('In sample GAS','OOS const','OOS GAS',2),title(['Student''s t pair ',pairs{pp}])
datetick('x')
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'InOOScompT',pairs{pp},'.eps'],'psc2') 
end
% very close. this is good - suggests that GAS parameters did not change much over the full sample relative to the IS

% now get the OOS copula log-likelihoods
outLLOOS = nan(P,8,2,nIndices);
for pp=1:nIndices
    for uu=1:2;
        outLLOOS(:,1,uu,pp) = NormalCopula_CLa(KAPPAhatIS(1,1,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLOOS(:,2,uu,pp) = claytonCLa(KAPPAhatIS(1,2,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLOOS(:,3,uu,pp) = gumbelCLa(KAPPAhatIS(1,3,uu,pp),1-UhatOOS(R+1:end,pair(pp,:),uu));
        outLLOOS(:,4,uu,pp) = tcopulaCL2a(KAPPAhatIS(1:2,4,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLOOS(:,5,uu,pp) = sym_jc_CLa(KAPPAhatIS([2,1],5,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLOOS(:,6,uu,pp) = Rotgumbel_GAS_CLa(KAPPAhatIS(1:3,6,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,3,uu,pp),[KK,HESSgumbel(:,1)]);
        outLLOOS(:,7,uu,pp) = bivnorm_tv_GAS_CLa(KAPPAhatIS(1:3,7,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,1,uu,pp),RR,HESSnorm(:,1));
        outLLOOS(:,8,uu,pp) = tcopula_GAS_CLa(KAPPAhatIS(1:4,8,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,4,uu,pp),RR,NN,HESSstudt);
    end
end 
outLLOOS = -outLLOOS;  % converting from neg log-like to regular log-like
sum(outLLOOS)

for pp=1:nIndices
 table10(9,:,pp) = sum(outLLOOS(:,:,2,pp));
 table10(10,:,pp) = ranks(-sum(outLLOOS(:,:,2,pp))');
 table10(10+9,:,pp) = sum(outLLOOS(:,:,1,pp));
 table10(10+10,:,pp) = ranks(-sum(outLLOOS(:,:,1,pp))');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GW pair-wise tests for parametric and nonparametric margins

outLLGWtest = nan(8,8,2,nIndices);
for pp=1:nIndices
    for uu=1:2
        for jj=1:7
            for ii=jj+1:8;
                temp = nwest(outLLOOS(:,ii,uu,pp)-outLLOOS(:,jj,uu,pp),ones(P,1)); % removed 10 lags
                outLLGWtest(ii,jj,uu,pp) = temp.tstat;
            end
        end
    end
end
outLLGWtest

for pp=1:nIndices
table10(1:8,1:8,pp)  = outLLGWtest(:,:,2,pp);
table10(11:18,1:8,pp) = outLLGWtest(:,:,1,pp);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GW pair-wise test for mdoels with same copula but different margins (param vs nonparam)

% for EDF marginals I do not have a marginal density. For the density i need some sort of kernel (I guess). let's try using the built in one in
% Matlab for this 

mm=1;
[h1, f1, y1] = pltdens(stdresidsOOS(1:R,mm));
sum(f1<=0)  % 21
figure(10),plot(y1,f1,'b.-')

mm=2;
[h2, f2, y2] = pltdens(stdresidsOOS(1:R,mm));
sum(f2<=0)  % 29
figure(12),plot(y2,f2,'r.-')

mm=3;
[h3, f3, y3] = pltdens(stdresidsOOS(1:R,mm));
sum(f3<=0)  % 29
figure(14),plot(y3,f3,'g.-')

edfpdf1 = interp1(y1,f1,stdresidsOOS(R+1:end,1));
min(edfpdf1)  %   0.012    so the neg value of the pdf turns out not to matter, so no problem
edfpdf2 = interp1(y2,f2,stdresidsOOS(R+1:end,2));
min(edfpdf2)  %   0.0061    so the neg value of the pdf turns out not to matter, so no problem
edfpdf3 = interp1(y3,f3,stdresidsOOS(R+1:end,3));
min(edfpdf3) 
for ii=1:P
    if edfpdf1(ii)<0
        edfpdf1(ii)=-edfpdf1(ii); % replace the very small negative with very small positive.
    end
    if edfpdf2(ii)<0
        edfpdf2(ii)=-edfpdf2(ii); % replace the very small negative with very small positive.
    end
    if edfpdf3(ii)<0
        edfpdf3(ii)=-edfpdf3(ii); % replace the very small negative with very small positive.
    end
end
edfpdf=[edfpdf1, edfpdf2, edfpdf3];
% OK, so no problem with neg density. Go with this. The fact that the kernel density is negative (slightly) in some regions may cause problems in
% other applications so this needs to be monitored.

outLLcomp = nan(P,8+1,2,nIndices);  % log-likelihood of joint models with nonparam margins vs param maregs (same copual)
for pp=1:nIndices
outLLcomp(:,9,1,pp) = log(edfpdf(:,pair(pp,1)))+log(edfpdf(:,pair(pp,2)));  % log like of the marginals
    if pp==1
    outLLcomp(:,9,2,pp) = log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,1)),outSKEWTIS(pair(pp,1),1),outSKEWTIS(pair(pp,1),2))) + log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,2)),outSKEWTIS(pair(pp,2),1),outSKEWTIS(pair(pp,2),2)));        
    elseif pp==2
    outLLcomp(:,9,2,pp) = log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,1)),outSKEWTIS(pair(pp,1),1),outSKEWTIS(pair(pp,1),2))) + log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,2)),outSKEWTIS(pair(pp,2),1),outSKEWTIS(pair(pp,2),2)));
    else
    outLLcomp(:,9,2,pp) = log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,1)),outSKEWTIS(pair(pp,1),1),outSKEWTIS(pair(pp,1),2))) + log(skewtdis_pdf(stdresidsOOS(R+1:end,pair(pp,2)),outSKEWTIS(pair(pp,2),1),outSKEWTIS(pair(pp,2),2)));
    end
end

for pp=1:nIndices
    for uu=1:2;
        outLLcomp(:,1,uu,pp) = -NormalCopula_CLa(KAPPAhatIS(1,1,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLcomp(:,2,uu,pp) = -claytonCLa(KAPPAhatIS(1,2,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLcomp(:,3,uu,pp) = -gumbelCLa(KAPPAhatIS(1,3,uu,pp),1-UhatOOS(R+1:end,pair(pp,:),uu));
        outLLcomp(:,4,uu,pp) = -tcopulaCL2a(KAPPAhatIS(1:2,4,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLcomp(:,5,uu,pp) = -sym_jc_CLa(KAPPAhatIS([2,1],5,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu));
        outLLcomp(:,6,uu,pp) = -Rotgumbel_GAS_CLa(KAPPAhatIS(1:3,6,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,3,uu),[KK,HESSgumbel(:,1)]);
        outLLcomp(:,7,uu,pp) = -bivnorm_tv_GAS_CLa(KAPPAhatIS(1:3,7,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,1,uu,pp),RR,HESSnorm(:,1));
        outLLcomp(:,8,uu,pp) = -tcopula_GAS_CLa(KAPPAhatIS(1:4,8,uu,pp),UhatOOS(R+1:end,pair(pp,:),uu),KAPPAhatIS(1,4,uu,pp),RR,NN,HESSstudt);
    end
end


outLLcompT = nan(1,8,nIndices);
for pp=1:nIndices
    for cc=1:8;
        temp = nwest( outLLcomp(:,9,1,pp)-outLLcomp(:,9,2,pp)+outLLcomp(:,cc,1,pp)-outLLcomp(:,cc,2,pp),ones(P,1));
        outLLcompT(cc,pp) = -temp.tstat;
    end
table10(end,:,pp) = outLLcompT(:,pp);
end

for pp=1:size(pair,1)
    % save path+file name
    tabName=[save_path,save_name,'table10',pairs{pp},'.tex'];
    info.fid=fopen(tabName,'w');
    
    % LaTEX table header
    h1 = '\begin{table}';
    h2 = '\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrrrr}\toprule';
    h3 = ['& \multicolumn{8}{c}{',pairs{pp},'} \\ '];
    h4 = '& \multicolumn{8}{c}{Parametric margins}\\';
    h5 = '\cmidrule{2-9}';
    fprintf(info.fid,'%s \n',h1,h2,h3,h4,h5);
    
    % Body of the table
    info.fmt = strvcat('%10.2f');
    info.cnames = strvcat('Normal','Clayton','R. Gum.','Stud t','SJC','$RGum_{GAS}$','$N_{GAS}$','$t_{GAS}$');
    info.rnames = strvcat(' ','Normal','Clayton','R. Gum.','Stud t','SJC','$RGum_{GAS}$','$N_{GAS}$','$t_{GAS}$','$\mathcal{LL}^{OOS}$','Rank');
    lprint_KA(table10(1:10,:,pp),info)
    
    h6 = '& \multicolumn{8}{c}{Nonparametric margins}\\';
    h7 = '\cmidrule{2-9}';
    fprintf(info.fid,'%s \n',h6,h7);
    info.fmt = strvcat('%10.2f');
    %info.cnames = strvcat('Normal','Clayton','Rot Gumbel','Stud t','SJC','RGum-GAS','Normal GAS','Stud t-GAS');
    info.rnames = strvcat(' ','Normal','Clayton','R. Gum.','Stud t','SJC','$RGum_{GAS}$','$N_{GAS}$','$t_{GAS}$','$\mathcal{LL}^{OOS}$','Rank');
    lprint_KA(table10(11:20,:,pp),info)

    h8 = '& \multicolumn{8}{c}{Parametric vs nonparametric margins}\\';
    h9 = '\cmidrule{2-9}';
    fprintf(info.fid,'%s \n',h8,h9);
    info.rnames = strvcat(' ','\emph{t-stat}');
    lprint_KA(table10(end,:,pp),info)

    % LaTEX table footer
    t1 = '  \bottomrule ';
    t2 = '\end{tabular*}  ';
    t3 = ['\caption{The t-statistics from out-of-sample pair-wise comparisons of log-likelihood values for five constant copula ',...
        'models and three time-varying copula models, with fully parametric or semiparametric marginal distribution models.',...
        ' Positive (negative) values indicate better performance of copula to the left (above).'...
        ' Out-of-sample period is from ',datestr(dates(R)),' to ',datestr(dates(T)),' and includes ',num2str(P),' observations.}'];
    t4 = ['\label{tab:UnivRGOosComp',pairs{pp},'}'];
    t5 = '\end{table}';
    fprintf(info.fid,'%s \n',t1,t2,t3,t4,t5);
end

% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_10.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_10.mat'';'];
evalin('base',temp_str);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LINEAR CORRELATION FROM COPULA-BASED MODELS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% let's first plot conditional tail depednence 
uu=2;
for pp=1:nIndices
    %gumbel copula tails
tauUg = zeros(T,1);
tauLg = 2-2.^(1./KAPPAhatOOS(:,1,6,uu,pp));
    % t copula tail/s
tauUt = 2*tdis_cdf(-sqrt(1+1/table8(21,1,pp))*sqrt((1-KAPPAhatOOS(:,1,8,uu,pp))./(1+KAPPAhatOOS(:,1,8,uu,pp))),1+1/table8(21,1,pp));
tauLt = tauUt;
fig=figure(1900+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,tauLg,'k--');hold on;
plot(dates,tauLt,'r-');
line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','LineWidth',2,'Color',[0.4 0.1 1])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2)-0.08,'Forecasted tail dependence','HorizontalAlignment','left','VerticalAlignment','middle')

datetick('x')
title(['Tail dependence from time-varying copula models ',pairs{pp}]);
legend('RotGumbel lower tail','Stud t upper and lower tail',2);hold off;
legend('Stud t upper and lower tail',2);hold off;


set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'tailDep',pairs{pp},'.eps'],'psc2') % for loops: saveas (gcf, ['My Figure' ,num2str (i), '.figuretype']);                                                    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simulation approximation to linear correlation from a coupla-based models

% key here is for the estimate at each node to be VERY accurate. For a fixed computation time there is a trade off between the number of nodes and the
% number of simulations at each node. I suggest that 10-20 nodes with 100,000 simulations each works well (and better than 100 nodes with 10,000 simualtions each)

%gridG2 = linspace(min(kappat), max(kappat), 20);

% WARNING: THIS PART IS PRETTY SLOW

sims = 1000;
sims2 = 100;  % doing many replications of length 1000 (could consider doing sims = 100,000 but may start to have memory problems)
outG1 = nan(10,2,sims2,nIndices);
tic;
for pp=1:nIndices;
    gridG1(pp,:) = linspace(min(kappatRotp(:,pp)), max(kappatRotp(:,pp)), 10);
    for ss=1:sims2;
        for gg=1:length(gridG1)
            U3 = 1-Gumbel_rnd(gridG1(gg),sims);
            outG1(gg,1,ss,pp) = corrcoef12(U3);  % rank correlation
            outG1(gg,2,ss,pp) = corrcoef12([quantile(stdresids(:,pair(pp,1)),U3(:,1),1),quantile(stdresids(:,pair(pp,2)),U3(:,2),1)]);
        end
    end
        fmtspec='Loop %10.0f of %-10.0f \n';
        fprintf(fmtspec,pp,nIndices)  % takes about 34 sec per loop
end
toc  % takes 17 mins for sims=1000 and sims2=100, length(gridG1)=10
outG1a = mean(outG1,3);

% % WARNING: THIS PART IS PRETTY SLOW
% 
% outG2 = nan(10,2,sims2,nIndices);
% tic;
% for pp=1:nIndices;
%     gridG2(pp,:) = linspace(min(kappatRotp(:,pp)), max(kappatRotp(:,pp)), 20);
%     for ss=1:sims2;
%         for gg=1:length(gridG2)
%             U3 = 1-Gumbel_rnd(gridG2(gg),sims);
%             outG2(gg,1,ss,pp) = corrcoef12(U3);  % rank correlation
%             outG2(gg,2,ss,pp) = corrcoef12([quantile(stdresids(:,pair(pp,1)),U3(:,1),1),quantile(stdresids(:,pair(pp,2)),U3(:,2),1)]);
%         end
%     end
%     fmtspec='Loop %10.0f of %-10.0f \n';
%     fprintf(fmtspec,pp,nIndices)  % takes about 34 sec per loop
% end
% toc  % takes 35 mins for sims=1000 and sims2=100, length(gridG1)=20
% outG2a = mean(outG2,3);
% 
% for pp=1:nIndices
% figure(1930+pp),plot(gridG2(pp,:),interp1(gridG1(pp,:),outG1a(:,2,pp),gridG2(pp,:),'spline'),'-',gridG2(pp,:),outG2a(:,2,pp),'rp'),legend('Interpolated using 10 nodes','Values from 20 nodes',2),title(['Linear correlation ',pairs{pp}]);
% figure(1940+pp),plot(gridG2(pp,:),interp1(gridG1(pp,:),outG1a(:,1,pp),gridG2(pp,:),'spline'),'-',gridG2(pp,:),outG2a(:,1,pp),'rp'),legend('Interpolated using 10 nodes','Values from 20 nodes',2),title(['Rank correlation ',pairs{pp}]);
% end


sims=1000;
sim2=100;
outN1 = nan(10,2,sims2,nIndices);
outN2 = nan(20,2,sims2,nIndices);
tic;
for pp=1:nIndices
gridN1(pp,:) = linspace(min(rhotNormp(:,pp)), max(rhotNormp(:,pp)), 10);
    for ss=1:sims2;
        for gg=1:length(gridN1)
            U4 = normcdf(mvnrnd([0 0],[[1,gridN1(pp,gg)];[gridN1(pp,gg),1]],T));
            outN1(gg,1,ss,pp) = corrcoef12(U4);  % rank correlation
            outN1(gg,2,ss,pp) = corrcoef12([quantile(stdresids(:,pair(pp,1)),U4(:,1),1),quantile(stdresids(:,pair(pp,2)),U4(:,2),1)]);
        end
    end
    fmtspec='Loop %10.0f of %-10.0f \n';
    fprintf(fmtspec,pp,nIndices) 
end
toc  % takes 21 seconds for sims=100, sims2 = 100 and length(gridG1)=10
outN1a = mean(outN1,3);

% get OOS correlations
uu=2;
outN12 = nan(10,2,sims2,nIndices);
outN22 = nan(20,2,sims2,nIndices);
tic;
for pp=1:nIndices
gridN12(pp,:) = linspace(min(KAPPAhatOOS(:,1,7,uu,pp)), max(KAPPAhatOOS(:,1,7,uu,pp)), 10);
    for ss=1:sims2;
        for gg=1:length(gridN12)
            U4 = normcdf(mvnrnd([0 0],[[1,gridN12(pp,gg)];[gridN12(pp,gg),1]],T));
            outN12(gg,1,ss,pp) = corrcoef12(U4);  % rank correlation
            outN12(gg,2,ss,pp) = corrcoef12([quantile(stdresidsOOS(:,pair(pp,1)),U4(:,1),1),quantile(stdresidsOOS(:,pair(pp,2)),U4(:,2),1)]);
        end
    end
    fmtspec='Loop %10.0f of %-10.0f \n';
    fprintf(fmtspec,pp,nIndices) 
end
toc  % takes 21 seconds for sims=100, sims2 = 100 and length(gridG1)=10
outN12a = mean(outN12,3);

% now do same for Student's t

sims=1000;
sim2=100;
outT1 = nan(10,2,sims2,nIndices);
outT2 = nan(20,2,sims2,nIndices);
tic;
for pp=1:nIndices
gridT1(pp,:) = linspace(min(rhotTp(:,pp)), max(rhotTp(:,pp)), 10);
    for ss=1:sims2;
        for gg=1:length(gridT1)
            U4 = tdis_cdf(mvtrnd([[1,gridT1(pp,gg)];[gridT1(pp,gg),1]],1/table8(21,1,pp),T),1/table8(21,1,pp));
            outT1(gg,1,ss,pp) = corrcoef12(U4);  % rank correlation
            outT1(gg,2,ss,pp) = corrcoef12([quantile(stdresids(:,pair(pp,1)),U4(:,1),1),quantile(stdresids(:,pair(pp,2)),U4(:,2),1)]);
        end
    end
    fmtspec='Loop %10.0f of %-10.0f \n';
    fprintf(fmtspec,pp,nIndices) 
end
toc  % takes 21 seconds for sims=100, sims2 = 100 and length(gridG1)=10
outT1a = mean(outT1,3);

% get OOS correlations
outT12 = nan(10,2,sims2,nIndices);
outT22 = nan(20,2,sims2,nIndices);
tic;
for pp=1:nIndices
gridT12(pp,:) = linspace(min(KAPPAhatOOS(:,1,8,uu,pp)), max(KAPPAhatOOS(:,1,8,uu,pp)), 10);
    for ss=1:sims2;
        for gg=1:length(gridT12)
            U4 = tdis_cdf(mvtrnd([[1,gridT12(pp,gg)];[gridT12(pp,gg),1]],1/table8(21,1,pp),T),1/table8(21,1,pp));
            outT12(gg,1,ss,pp) = corrcoef12(U4);  % rank correlation
            outT12(gg,2,ss,pp) = corrcoef12([quantile(stdresidsOOS(:,pair(pp,1)),U4(:,1),1),quantile(stdresidsOOS(:,pair(pp,2)),U4(:,2),1)]);
        end
    end
    fmtspec='Loop %10.0f of %-10.0f \n';
    fprintf(fmtspec,pp,nIndices) 
end
toc  % takes 21 seconds for sims=100, sims2 = 100 and length(gridG1)=10
outT12a = mean(outT12,3);
% tic;
% for pp=1:nIndices
%     gridT2(pp,:) = linspace(min(rhotTp(:,pp)), max(rhotTp(:,pp)), 20);
%     for ss=1:sims2;
%         for gg=1:length(gridT2)
%             U4 = tdis_cdf(mvtrnd([[1,gridT2(pp,gg)];[gridT2(pp,gg),1]],1/table8(21,1,pp),T),1/table8(21,1,pp));
%             outT2(gg,1,ss,pp) = corrcoef12(U4);  % rank correlation
%             outT2(gg,2,ss,pp) = corrcoef12([quantile(stdresids(:,pair(pp,1)),U4(:,1),1),quantile(stdresids(:,pair(pp,2)),U4(:,2),1)]);
%         end
%     end
%     fmtspec='Loop %10.0f of %-10.0f \n';
%     fprintf(fmtspec,pp,nIndices) 
% end
% toc  % takes 21 seconds for sims=100, sims2 = 100 and length(gridG1)=20
% outT2a = mean(outT2,3);
%   
% for pp=1:nIndices
% figure(1950+pp),plot(gridT2(pp,:),interp1(gridT1(pp,:),outT1a(:,2,pp),gridT2(pp,:),'spline'),'-',gridT2(pp,:),outT2a(:,2,pp),'rp'),legend('Interpolated using 10 nodes','Values from 20 nodes',2),title(['Linear correlation ',pairs{pp}]);
% figure(1960+pp),plot(gridT2(pp,:),interp1(gridT1(pp,:),outT1a(:,1,pp),gridT2(pp,:),'spline'),'-',gridT2(pp,:),outT2a(:,1,pp),'rp'),legend('Interpolated using 10 nodes','Values from 20 nodes',2),title(['Rank correlation ',pairs{pp}]);
% 
% figure(1970+pp),subplot(2,1,1),plot(gridG2(pp,:),interp1(gridG1(pp,:),outG1a(:,2,pp),gridG2(pp,:),'spline'),'b-','LineWidth',2);hold on;
% plot(gridG2(pp,:),outG2a(:,2,pp),'rp'),...
%     title(['Linear correlation from Gumbel copula model ',pairs{pp}]),xlabel('Gumbel copula parameter'),ylabel('Linear correlation');grid on;hold off;
% subplot(2,1,2),plot(gridT2(pp,:),interp1(gridT1(pp,:),outT1a(:,1,pp),gridT2(pp,:),'spline'),'b-','LineWidth',2);hold on;
% plot(gridT2(pp,:),outT2a(:,1,pp),'rp'),legend('Interpolated using 10 nodes','Values from 20 nodes',2),...
%     title(['Linear correlation from Student''s t copula model ',pairs{pp}]),xlabel('t copula correlation parameter'),ylabel('Linear correlation');grid on;hold off;
% end


for pp=1:nIndices
    fig=figure(1980+pp);
    set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
    set (gca,'FontSize',16)
    plot(dates,interp1(gridG1(pp,:),outG1a(:,2,pp),kappatRotp(:,pp),'spline'),'b-');hold on;
    plot(dates,interp1(gridN1(pp,:),outN1a(:,2,pp),rhotNormp(:,pp),'spline'),'k-');
    plot(dates,interp1(gridT1(pp,:),outT1a(:,2,pp),rhotTp(:,pp),'spline'),'r-');
    datetick('x')
    title(['Linear correlation from time-varying copula models ',pairs{pp}]);
    legend('RotGumbel','Normal','Stud t',2);hold off;
    axis tight
    set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
    saveas (gcf,[save_path,save_name,'linCorr',pairs{pp},'.eps'],'psc2') %
end
% looks good
% Plot the correlations with OOS forecast 
for pp=1:nIndices
    fig=figure(1990+pp);
    set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
    set (gca,'FontSize',14)
    
    load('realizedCorrelations.mat'); 
    hh5=plot(dates,rcdata(:,pp),'-.','Color',[0.83 0.82 .78]);hold on;
    hh1=plot(dates(1:R),interp1(gridN12(pp,:),outN12a(:,2,pp),KAPPAhatOOS(1:R,1,7,uu,pp),'spline'),'k-.');
    hh2=plot(dates(1+R:end),interp1(gridN12(pp,:),outN12a(:,2,pp),KAPPAhatOOS(R+1:end,1,7,uu,pp),'spline'),'k--');
    hh3=plot(dates(1:R),interp1(gridT12(pp,:),outT12a(:,2,pp),KAPPAhatOOS(1:R,1,8,uu,pp),'spline'),'Linestyle','-','Color',[.4 .4 .4]);
    hh4=plot(dates(R+1:end),interp1(gridT12(pp,:),outT12a(:,2,pp),KAPPAhatOOS(R+1:end,1,8,uu,pp),'spline'),'Linestyle','--','Color',[.4 .4 .4]);
    line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','LineWidth',2,'Color',[0.4 0.4 .4])
    yLimits=get(gca,'YLim');
    text(dates(R+30),yLimits(1)+0.1,'Forecasted correlation','HorizontalAlignment','left','VerticalAlignment','middle')

    datetick('x')
    title(['Linear correlation from time-varying copula models ',pairs{pp}],'FontSize',16);
    h_legend=legend([hh1 hh3 hh5],{'Normal','Stud t','Realized correlation'},'Location','NorthWest');
    set(h_legend,'FontSize',16);hold off;
    axis tight
    set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
    saveas (gcf,[save_path,save_name,'linCorrOOS',pairs{pp},'_bw.eps'],'psc2') %
end
% saving the output down to this part of the code.
temp_str = ['save ''',save_path,save_name,'_stage_11.mat'';'];
evalin('base',temp_str);
% to load the output matrix from this point run the following
temp_str = ['load ''',save_path,save_name,'_stage_11.mat'';'];
evalin('base',temp_str);
%% VaR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VALUE-AT-RISK AND EXPECTED SHORTFALL FROM COPULA-BASED MODELS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% getting VaR and ES for a portfolio of these variables

% WARNING: THIS PART IS VERY SLOW (takes around 12 hours for 3 pairs and
% sims=5000)

WW = [0;0.01;(0.05:0.05:0.95)';0.99;1];  % getting lots of weights, as this part is cheap once we have the simulations
QQ = [0.001;0.005;0.01;0.05;0.1;0.9;0.95;0.99];  % quantiles to look at

% Create equal weighted portfolio returns for each par (and standardize to
% compare with VaR and ES)

port(:,1)=0.5*(data(:,1)+data(:,2)+mean(rets1(:,1))+mean(rets1(:,2)));
port(:,2)=0.5*(data(:,1)+data(:,3)+mean(rets1(:,1))+[rets1(1:2,3); [ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3)]*ARparams3 ]);
port(:,3)=0.5*(data(:,2)+data(:,3)+mean(rets1(:,2))+[rets1(1:2,3); [ones(T-2,1),rets1(2:end-1,3),rets1(1:end-2,3)]*ARparams3 ]);

% I am obtaining resids again here because the resids from previous are in
% fact standardized.
for ii=1:nIndices
    [theta1,sig21,vcv1,order1,resids1] = ARMAX_opt(rets1(:,ii),5,5,'BIC');  % takes about 6 seconds per variable
    mean_order(ii,1:2) = order1';
    mean_order(ii,3) = 1-sig21/cov(rets1(:,ii));
    resids(:,ii) = [zeros(max(order1),1);resids1];
end

muhat = rets1 - resids;  % conditional mean

sims = 100; % make it 5000
outVARu2 = nan(T,4,length(WW),length(QQ),2,2,nIndices);
clear UUU
uu=2;
tic;
tStart=tic;
for pp=1:nIndices;
    for tt=1:T;
        U2 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,1,uu,pp)];[KAPPAhatOOS(tt,1,1,uu,pp),1]],sims));
        U3 = 1-Gumbel_rnd(KAPPAhatOOS(tt,1,6,uu,pp),sims);
        U4 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,7,uu,pp)];[KAPPAhatOOS(tt,1,7,uu,pp),1]],sims));
        U5 = tdis_cdf(mvtrnd([[1,KAPPAhatOOS(tt,1,8,uu,pp)];[KAPPAhatOOS(tt,1,8,uu,pp),1]],1/KAPPAhatIS(1,4,uu,pp),sims),1/KAPPAhatIS(1,4,uu,pp));
        UUU(:,:,1) = U2;
        UUU(:,:,2) = U3;
        UUU(:,:,3) = U4;
        UUU(:,:,4)=U5;
        EEE = nan(sims,2,4);
        YYY = nan(sims,2,4);
        for cc=1:4;
            for mm=1:2;
                EEE(:,mm,cc) = quantile(stdresidsOOS(:,pair(pp,mm)),UUU(:,mm,cc),1);
                YYY(:,mm,cc) = muhat(tt,pair(pp,mm)) + sqrt(VOL2hatOOS(tt,pair(pp,mm)))*EEE(:,mm,cc);  % simulated value for return
            end
            for ww=1:length(WW);
                w = WW(ww);
                pf = w*YYY(:,1,cc) + (1-w)*YYY(:,2,cc);
                pf2 = w*EEE(:,1,cc) + (1-w)*EEE(:,2,cc);
                outVARu2(tt,cc,ww,:,1,1,pp) = quantile(pf,QQ);                 % Value at Risk
                outVARu2(tt,cc,ww,:,1,2,pp) = quantile(pf2,QQ);                 % Value at Risk of the std resids (useful for seeing where the copula matters)

                for qq=1:length(QQ);
                    temp124 = (pf<=quantile(pf,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,1,pp) = mean(pf(temp124));   % Expected Shortfall for simulated returns
                    end
                    temp124 = (pf2<=quantile(pf2,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu2(tt,cc,ww,qq,2,2,pp) = mean(pf2(temp124));   % Expected Shortfall for stdresids
                    end
                end
            end
        end
        if mod(tt,100)==0
            [tt,toc]
        end
    end
tEnd=toc(tStart);
fprintf('Finished simulation of parametric VaR and ES for pair: %s . Number of simulations/day: %d \n',pairs{pp},sims)
fprintf('Cumulative time %d minutes and %f seconds \n', floor(tEnd/60),rem(tEnd,60))
end
%toc  % takes about 3.88 hours for sims=5000

% Retrieve and plot the estimated VaR and ES for desired weights and quantiles.
wstar = find(abs(WW-0.5)<eps); % doing WW==0.5 does not work ! ... because of floating point numbers
grey=[0.4 0.4 0.4]; % define grey color
for pp=1:nIndices
fig=figure(2200+pp);
set (fig,'Position',[100 100 900 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)

qq = find(abs(QQ-0.05)<eps);
plot(dates,squeeze(outVARu2(:,1,wstar,qq,1,1,pp)),'g');hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,1,1,pp)),'b');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,4,wstar,qq,1,1,pp)),'m');

plot(dates,port(:,pp),'Color',grey);

qq = find(abs(QQ-0.95)<eps);
plot(dates,squeeze(outVARu2(:,1,wstar,qq,1,1,pp)),'g');hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,1,1,pp)),'b');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'m');

line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','LineWidth',2,'Color',[0.4 0.1 1])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2)-2,'Out-of-sample','HorizontalAlignment','left','VerticalAlignment','middle')

title(['Parametric Value-at-Risk from time-varying copula models,',pairs{pp},' w=[',num2str(WW(wstar)),',',num2str(WW(wstar)),'], q=[',num2str(1-QQ(qq)),',',num2str(QQ(qq)),']']);
legend('Normal','RotGumbel','Tv-Normal','Stud t',3);hold off;
datetick('x')
axis([dates(1) dates(end) -7 6])
set (gcf, 'PaperUnits','inches','PaperPosition',[0.05 0.05 11.5 9],'PaperSize',[8.5 11],'PaperOrientation','landscape')   % Use screen size
%set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'VaR',pairs{pp},'_',num2str(QQ(qq)*100),'.eps'],'psc2') %

qq = find(abs(QQ-0.01)<eps);
fig=figure(2300+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,squeeze(outVARu2(:,1,wstar,qq,2,1,pp)),'g:','LineWidth',2);hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,2,1,pp)),'k');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,2,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,4,wstar,qq,2,1,pp)),'m');

line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','LineWidth',2,'Color',[0.4 0.1 1])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(1)+2,'Out-of-sample','HorizontalAlignment','left','VerticalAlignment','bottom')

title(['Parametric Expected Shortfall from time-varying copula models,',pairs{pp},' w=[',num2str(WW(wstar)),',',num2str(WW(wstar)),'], q=',num2str(QQ(qq))]);
legend('Normal','RotGumbel','Tv-Normal','Stud t',3);hold off;
datetick('x')
%axis tight
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'ES',pairs{pp},'_',num2str(QQ(qq)*100),'.eps'],'psc2') %
end

% VaR for semiparametric model
outVARu1 = nan(T,4,length(WW),length(QQ),2,2,nIndices);
clear UUU
uu=1;
tic;
tStart=tic;
for pp=1:nIndices;
    for tt=1:T;
        U2 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,1,uu,pp)];[KAPPAhatOOS(tt,1,1,uu,pp),1]],sims));
        U3 = 1-Gumbel_rnd(KAPPAhatOOS(tt,1,6,uu,pp),sims);
        U4 = normcdf(mvnrnd(zeros(1,2),[[1,KAPPAhatOOS(tt,1,7,uu,pp)];[KAPPAhatOOS(tt,1,7,uu,pp),1]],sims));
        U5 = tdis_cdf(mvtrnd([[1,KAPPAhatOOS(tt,1,8,uu,pp)];[KAPPAhatOOS(tt,1,8,uu,pp),1]],1/KAPPAhatIS(1,4,uu,pp),sims),1/KAPPAhatIS(1,4,uu,pp));
        UUU(:,:,1) = U2;
        UUU(:,:,2) = U3;
        UUU(:,:,3) = U4;
        UUU(:,:,4)=U5;
        EEE = nan(sims,2,4);
        YYY = nan(sims,2,4);
        for cc=1:4;
            for mm=1:2;
                EEE(:,mm,cc) = quantile(stdresidsOOS(:,pair(pp,mm)),UUU(:,mm,cc),1);
                YYY(:,mm,cc) = muhat(tt,pair(pp,mm)) + sqrt(VOL2hatOOS(tt,pair(pp,mm)))*EEE(:,mm,cc);  % simulated value for return
            end
            for ww=1:length(WW);
                w = WW(ww);
                pf = w*YYY(:,1,cc) + (1-w)*YYY(:,2,cc);
                pf2 = w*EEE(:,1,cc) + (1-w)*EEE(:,2,cc);
                outVARu1(tt,cc,ww,:,1,1,pp) = quantile(pf,QQ);                 % Value at Risk
                outVARu1(tt,cc,ww,:,1,2,pp) = quantile(pf2,QQ);                 % Value at Risk of the std resids (useful for seeing where the copula matters)

                for qq=1:length(QQ);
                    temp124 = (pf<=quantile(pf,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu1(tt,cc,ww,qq,2,1,pp) = mean(pf(temp124));   % Expected Shortfall for simulated returns
                    end
                    temp124 = (pf2<=quantile(pf2,QQ(qq)));  % observations below this quantile
                    if sum(temp124)>0
                        outVARu1(tt,cc,ww,qq,2,2,pp) = mean(pf2(temp124));   % Expected Shortfall for stdresids
                    end
                end
            end
        end
        if mod(tt,100)==0
            [tt,toc]
        end
    end
tEnd=toc(tStart);
fprintf('Finished simulation of semi-parametric VaR and ES for pair: %s . Number of simulations/day: %d \n',pairs{pp},sims)
fprintf('Cumulative time %d minutes and %f seconds \n', floor(tEnd/60),rem(tEnd,60))
end
%toc  % takes about 3.88 hours for sims=5000

% Retrieve and plot the estimated VaR and ES for desired weights and quantiles.
wstar = find(abs(WW-0.5)<eps); % doing WW==0.5 does not work ! ... because of floating point numbers
for pp=1:nIndices

fig=figure(20200+pp);
set (fig,'Position',[100 100 900 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
qq = find(abs(QQ-0.05)<eps);
plot(dates,squeeze(outVARu2(:,1,wstar,qq,1,1,pp)),'g','LineWidth',2);hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,1,1,pp)),'b');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,4,wstar,qq,1,1,pp)),'m');

plot(dates,port(:,pp),'Color',grey);

qq = find(abs(QQ-0.95)<eps);
plot(dates,squeeze(outVARu2(:,1,wstar,qq,1,1,pp)),'g','LineWidth',2);hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,1,1,pp)),'b');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,1,1,pp)),'m');

line([dates(R) dates(R)],get(gca,'YLim'),'Linestyle','-.','LineWidth',2,'Color',[0.4 0.1 1])
yLimits=get(gca,'YLim');
text(dates(R+30),yLimits(2)-2,'Out-of-sample','HorizontalAlignment','left','VerticalAlignment','middle')

title(['Semi-parametric Value-at-Risk from time-varying copula models,',pairs{pp},' w=[',num2str(WW(wstar)),',',num2str(WW(wstar)),'], q=[',num2str(1-QQ(qq)),',',num2str(QQ(qq)),']']);
legend('Normal','RotGumbel','Tv-Normal','Stud t','Portfolio returns',3);hold off;
datetick('x')
%axis tight
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'VaR',pairs{pp},'_',num2str(QQ(qq)*100),'SemiP.eps'],'psc2') %

fig=figure(20300+pp);
set (fig,'Position',[100 100 700 550],'Color',[1 1 1]) %  
set (gca,'FontSize',16)
plot(dates,squeeze(outVARu2(:,1,wstar,qq,2,1,pp)),'g:','LineWidth',2);hold on;
plot(dates,squeeze(outVARu2(:,2,wstar,qq,2,1,pp)),'k');
plot(dates,squeeze(outVARu2(:,3,wstar,qq,2,1,pp)),'c');
plot(dates,squeeze(outVARu2(:,4,wstar,qq,2,1,pp)),'m');

title(['Semi-parametric Expected Shortfall from time-varying copula models,',pairs{pp},' w=[',num2str(WW(wstar)),',',num2str(WW(wstar)),'], q=',num2str(QQ(qq))]);
legend('Normal','RotGumbel','Tv-Normal','Stud t',3);grid on;hold off;
datetick('x')
%axis tight
set (gcf, 'PaperPositionMode', 'auto')   % Use screen size
saveas (gcf,[save_path,save_name,'ES',pairs{pp},'_',num2str(QQ(qq)*100),'SemiP.eps'],'psc2') %
end

 
temp_str = ['save ''',save_path,save_name,'_stage_12a.mat'';'];
evalin('base',temp_str);
temp_str = ['load ''',save_path,save_name,'_stage_12a.mat'';'];
evalin('base',temp_str);
% 
% 
%  exit;
