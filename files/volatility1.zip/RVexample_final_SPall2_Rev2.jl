
# nohup julia RVexample_final_SPall2_Rev2.jl > out_nohup_v1"`date +%FT%H%M`".txt &

using Distributed
addprocs(4);   # number of cores available

@everywhere using CSV, DataFrames, GLM, Distributions, LinearAlgebra, Statistics
@everywhere using BSON, Dates
@everywhere using XLSX

@everywhere using RCall
@everywhere R"library(tvReg)"
@everywhere R"library(forecast)"

# load main functions
# @everywhere include("tvPersistence_functions_clean.jl");
@everywhere include("tvPersistence_functions_Restat_Rev5.jl");


@everywhere data = CSV.read("RV.csv", DataFrame)
@everywhere data = Matrix(data[:,2:end])
@everywhere data = 100.0*data;

#@everywhere data_read=CSV.File("RV_commodities_ballanced.csv",header=true) |> DataFrame
#@everywhere data=Matrix(data_read)

#@everywhere xf=XLSX.readxlsx("SPOT_IVOL_daily_2004_2022.xlsx");
#@everywhere data=Float64.(xf["Sheet1"]["B2:U4733"])
#@everywhere data = data .* 1.0

@everywhere crossection = size(data)[2]
#@everywhere crossection = 3


println("All things loaded. ", now())
flush(stdout)


########## HORIZON 1 ##########################

@everywhere horizon=1

### Chose parameters
@everywhere maxAR					= 2;   # original with AR=5
@everywhere kernel_width_for_const 	= 0.05; # deterministic (constant) forecast
@everywhere kernel_width_IRF		= 0.2;  # IRFs on errors
@everywhere kernel_width_forecast 	= 0.5;  # forecast of constant
@everywhere AR_lag_forecast 		= 1;	# AR lag choice for forecast of constant
@everywhere kernel_width_HAR		= 0.3; 	# kernel for TVP-AR3 TVP-HAR model 
@everywhere JMAX=5;  

@everywhere tt=1000;


forecasts=[]
for k=1:crossection

	println(now(),"     stock  ", k,"   h=",horizon,"   tt=",tt)
	flush(stdout)

	@everywhere rvfx = data[:,$k];

	@everywhere fcast_length = length(rvfx)-tt-21-horizon; #length of forecast sample

	# @everywhere (horizon_forecast_HAR,Error_HAR) = HAR(rvfx,tt,fcast_length,horizon);

	@everywhere (horizon_forecast_AR2,Error_AR2) = ARX(rvfx,tt,fcast_length,horizon,2);

	out=hcat(pmap(i -> ARX_tvLS_parallel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR,2), 0:(fcast_length-1))...);
	horizon_forecast_AR2tv=out[1,:];
	Error_AR2tv=out[2,:];

	# out0=hcat(pmap(i -> EWD_parallel(i,rvfx,tt,maxAR,JMAX,horizon), 0:(fcast_length-1))...);
	# horizon_forecast_EWD=out0[1,:];
	# RV_h=out0[2,:];
	# Error_EWD=out0[3,:];


	# out=hcat(pmap(i -> AR3_tvLS_parallel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR), 0:(fcast_length-1))...);
	# horizon_forecast_AR3tv=out[1,:];
	# Error_AR3tv=out[2,:];

	# out=hcat(pmap(i -> HAR_tvLS_parralel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR), 0:(fcast_length-1))...);
	# horizon_forecast_HARtv=out[1,:];
	# Error_HARtv=out[2,:];

	# out=hcat(pmap(i -> EWD_tvLS_parallel(i,rvfx,tt,maxAR,JMAX,horizon,kernel_width_for_const,kernel_width_IRF,kernel_width_forecast,AR_lag_forecast), 0:(fcast_length-1))...);
	# horizon_forecast_EWDtv=out[1,:];
	# Error_EWDtv=out[2,:];

	res=[horizon_forecast_AR2 horizon_forecast_AR2tv]

	push!(forecasts,res)

end
output_bson = Dict("forecasts" => forecasts, "tt" => tt,"horizon" => horizon)
BSON.bson("results_RV_SP500_AR2_ARtv2_final_predictions_$tt-$horizon.bson", output_bson)

println("Horizon 1 completed. ", now())
flush(stdout)




########## HORIZON 5 ##########################

@everywhere horizon=5

### Chose parameters
@everywhere maxAR					= 5;   # original with AR=5
@everywhere kernel_width_for_const 	= 0.05; # deterministic (constant) forecast
@everywhere kernel_width_IRF		= 0.2;  # IRFs on errors
@everywhere kernel_width_forecast 	= 0.4;  # forecast of constant
@everywhere AR_lag_forecast 		= 1;	# AR lag choice for forecast of constant
@everywhere kernel_width_HAR		= 0.3; 	# kernel for TVP-AR3 TVP-HAR model 
@everywhere JMAX=5;  

@everywhere tt=1000;



forecasts=[]
for k=1:crossection

	println(now(),"     stock  ", k,"   h=",horizon,"   tt=",tt)
	flush(stdout)

	@everywhere rvfx = data[:,$k];

	@everywhere fcast_length = length(rvfx)-tt-21-horizon; #length of forecast sample

	@everywhere (horizon_forecast_RW,Error_RW) = RW(rvfx,tt,fcast_length,horizon);

	# @everywhere (horizon_forecast_HAR,Error_HAR) = HAR(rvfx,tt,fcast_length,horizon);

	# out0=hcat(pmap(i -> EWD_parallel(i,rvfx,tt,maxAR,JMAX,horizon), 0:(fcast_length-1))...);
	# horizon_forecast_EWD=out0[1,:];
	# RV_h=out0[2,:];
	# Error_EWD=out0[3,:];


	# out=hcat(pmap(i -> AR3_tvLS_parallel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR), 0:(fcast_length-1))...);
	# horizon_forecast_AR3tv=out[1,:];
	# Error_AR3tv=out[2,:];

	# out=hcat(pmap(i -> HAR_tvLS_parralel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR), 0:(fcast_length-1))...);
	# horizon_forecast_HARtv=out[1,:];
	# Error_HARtv=out[2,:];

	# out=hcat(pmap(i -> EWD_tvLS_parallel(i,rvfx,tt,maxAR,JMAX,horizon,kernel_width_for_const,kernel_width_IRF,kernel_width_forecast,AR_lag_forecast), 0:(fcast_length-1))...);
	# horizon_forecast_EWDtv=out[1,:];
	# Error_EWDtv=out[2,:];

	# res=[RV_h horizon_forecast_HAR horizon_forecast_EWD horizon_forecast_AR3tv horizon_forecast_HARtv horizon_forecast_EWDtv]

	res=[horizon_forecast_RW]

	push!(forecasts,res)

end
output_bson = Dict("forecasts" => forecasts, "tt" => tt,"horizon" => horizon)
BSON.bson("results_RV_SP500_RW_predictions_$tt-$horizon.bson", output_bson)

println("Horizon 5 completed. ", now())
flush(stdout)


# ########## HORIZON 22 ##########################

# @everywhere horizon=22

# ### Chose parameters
# @everywhere maxAR					= 15;   # original with AR=5
# @everywhere kernel_width_for_const 	= 0.05; # deterministic (constant) forecast
# @everywhere kernel_width_IRF		= 0.2;  # IRFs on errors
# @everywhere kernel_width_forecast 	= 0.4;  # forecast of constant
# @everywhere AR_lag_forecast 		= 1;	# AR lag choice for forecast of constant
# @everywhere kernel_width_HAR		= 0.4; 	# kernel for TVP-AR3 TVP-HAR model 
# @everywhere JMAX=7;  

# # @everywhere maxAREWD				= 10;   # original with AR=5
# # @everywhere JMAXEWD=6;  

# @everywhere tt=1000;

# forecasts=[]
# for k=1:crossection

# 	println(now(),"     stock  ", k,"   h=",horizon,"   tt=",tt)
# 	flush(stdout)

# 	@everywhere rvfx = data[:,$k];

# 	@everywhere fcast_length = length(rvfx)-tt-21-horizon; #length of forecast sample

# 	# @everywhere (horizon_forecast_RW,Error_RW) = RW(rvfx,tt,fcast_length,horizon);

# 	# @everywhere (horizon_forecast_HAR,Error_HAR) = HAR(rvfx,tt,fcast_length,horizon);

# 	@everywhere (horizon_forecast_AR5,Error_AR5) = ARX(rvfx,tt,fcast_length,horizon,5);

# 	# out0=hcat(pmap(i -> EWD_parallel(i,rvfx,tt,maxAR,JMAX,horizon), 0:(fcast_length-1))...);
# 	# horizon_forecast_EWD=out0[1,:];
# 	# RV_h=out0[2,:];
# 	# Error_EWD=out0[3,:];

# 	# out0=hcat(pmap(i -> EWD_parallel(i,rvfx,tt,maxAREWD,JMAXEWD,horizon), 0:(fcast_length-1))...);
# 	# horizon_forecast_EWD=out0[1,:];
# 	# RV_h=out0[2,:];
# 	# Error_EWD=out0[3,:];

# 	# out=hcat(pmap(i -> ARX_tvLS_parallel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR,5), 0:(fcast_length-1))...);
# 	# horizon_forecast_AR5tv=out[1,:];
# 	# Error_AR5tv=out[2,:];

# 	# out=hcat(pmap(i -> HAR_tvLS_parralel(i,rvfx,tt,fcast_length,horizon,kernel_width_HAR), 0:(fcast_length-1))...);
# 	# horizon_forecast_HARtv=out[1,:];
# 	# Error_HARtv=out[2,:];

# 	# out=hcat(pmap(i -> EWD_tvLS_parallel(i,rvfx,tt,maxAR,JMAX,horizon,kernel_width_for_const,kernel_width_IRF,kernel_width_forecast,AR_lag_forecast), 0:(fcast_length-1))...);
# 	# horizon_forecast_EWDtv=out[1,:];
# 	# Error_EWDtv=out[2,:];

# 	res=[horizon_forecast_AR5]

# 	push!(forecasts,res)

# end
# output_bson = Dict("forecasts" => forecasts, "tt" => tt,"horizon" => horizon)
# BSON.bson("results_RV_SP500_AR5_predictions_$tt-$horizon.bson", output_bson)

# println("Horizon 22 completed. ", now())
# flush(stdout)








