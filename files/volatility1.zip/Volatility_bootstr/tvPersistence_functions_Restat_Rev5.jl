
#**************************************************************************
# by Jozef Barunik
#**************************************************************************
function UCSV_sim(N,rho,muh,phih,sigh,mug,phig,sigg)
    #
    # Simulates N observations of UCSV of Stock and Watson (2007) with 500 observations as burnin
    #
    # INPUTS:  N           number of simulated observations t=1,...,N
    #          
    #          rho         persistence of tau_t
    #
    #          muh         mean of log-variance h
    #          phih        persistence of log-variance h
    #          sigh        stdev of log-variance h
    #
    #          mug         mean of log-variance g
    #          phig        persistence of log-variance g
    #          sigg        stdev of log-variance g
    #
    # OUTPUTS:  y_t        final process y_t = tau_t + u_t
    #           tau_t      transition equation
    #           u_t        noise of y_t
    #           stdh_t     volatility of u_t
    #           stdg_t     volatility of eps_t
    #
    
    wh = randn(N + 500)
    wg = randn(N + 500)

    y = ones(N + 500) * 1
    tau = ones(N + 500) * 1

    u = zeros(N + 500)
    eps0 = zeros(N + 500)

    epsh = randn(N + 500)
    epsg = randn(N + 500)

    h = ones(N + 500) * -1.0
    g = ones(N + 500) * -1.0

    for t in collect(2:(N + 500))

        h[t] = muh+phih*(h[t-1]-muh) + sqrt(sigh)*epsh[t]
        u[t] = wh[t]*sqrt(exp(h[t]))

        g[t] = mug+phig*(g[t-1]-mug) + sqrt(sigg)*epsg[t]
        eps0[t] = wg[t]*sqrt(exp(g[t]))

        tau[t] = rho*tau[t] + eps0[t]

        y[t] = tau[t] + u[t]
    end

    return (y[501:(N+500)],tau[501:(N+500)],u[501:(N+500)],sqrt.(exp.(h[501:(N+500)])),sqrt.(exp.(g[501:(N+500)])))
end

function UCSV_sim2(N,rho1,rho2,muh,phih,sigh,mug1,phig1,sigg1,mug2,phig2,sigg2)
    
    wh = randn(N + 500)
    wg1 = randn(N + 500)
    wg2 = randn(N + 500)

    y = ones(N + 500) * 1
    tau1 = ones(N + 500) * 1
    tau2 = ones(N + 500) * 1

    u = zeros(N + 500)
    eps01 = zeros(N + 500)
    eps02 = zeros(N + 500)

    epsh = randn(N + 500)
    epsg1 = randn(N + 500)
    epsg2 = randn(N + 500)

    h = ones(N + 500) * -1.0
    g1 = ones(N + 500) * -1.0
    g2 = ones(N + 500) * -1.0

    for t in collect(2:(N + 500))

        h[t] = muh+phih*(h[t-1]-muh) + sqrt(sigh)*epsh[t]
        u[t] = wh[t]*sqrt(exp(h[t]))

        g1[t] = mug1+phig1*(g1[t-1]-mug1) + sqrt(sigg1)*epsg1[t]
        eps01[t] = wg1[t]*sqrt(exp(g1[t]))
        
        g2[t] = mug2+phig2*(g2[t-1]-mug2) + sqrt(sigg2)*epsg2[t]
        eps02[t] = wg2[t]*sqrt(exp(g2[t]))

        tau1[t] = rho1*tau1[t-1] + eps01[t]
        tau2[t] = rho2*tau2[t-1] + eps02[t]

        y[t] = tau1[t] + tau2[t] + u[t]
    end

    return (y[501:(N+500)],tau1[501:(N+500)],tau2[501:(N+500)],u[501:(N+500)],sqrt.(exp.(h[501:(N+500)])),sqrt.(exp.(g1[501:(N+500)])),sqrt.(exp.(g2[501:(N+500)])))
end


function AR_sin1(e)
    y=zeros(1268);
    spp=zeros(1268);
    for t=1:1268
        spp[t]=-sin(t/(1268/5))
    end
    
    y[1]=e[1]
    for t=2:1268
        y[t]=0.95*spp[t]*y[t-1]+e[t];
    end
    return y 
end

function AR_sin2(e)
    y=zeros(1268);
    spp=zeros(1268);
    for tt=1:1268
        spp[tt]=sin(tt/(1268/10))
    end
    
    y[1]=e[1]
    for t=2:1268
        y[t]=0.95*spp[t]*y[t-1]+e[t];
    end
    return y 
end

function AR_sin3(e)
    y=zeros(1268);
    spp=zeros(1268);
    for tt=1:1268
        spp[tt]=sin(tt/(1268/20))
    end
    
    y[1]=e[1]
    for t=2:1268
        y[t]=0.95*spp[t]*y[t-1]+e[t];
    end
    return y 
end

function simulAR1_mixture1(e1,e2)
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=2:1268
        y1[t]=0.3*y1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=2:1268
        y2[t]=0.2*y2[t-1]+e2[t];
    end
    return y=y1+y2
end

function simulAR1_mixture2(e1,e2)
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=2:1268
        y1[t]=0.3*y1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=2:1268
        y2[t]=-0.2*y2[t-1]+e2[t];
    end
    return y=y1+y2
end

function simulAR1_mixture3(e1,e2,e3)
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=2:1268
        y1[t]=0.3*y1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=2:1268
        y2[t]=0.2*y2[t-1]+e2[t];
    end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=2:1268
        y3[t]=0.1*y3[t-1]+e3[t];
    end
    return y=y1+y2+y3
end

function simulAR1_mixture4(e1,e2,e3)
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=2:1268
        y1[t]=0.6*y1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=2:1268
        y2[t]=0.8*y2[t-1]+e2[t];
    end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=2:1268
        y3[t]=-0.5*y3[t-1]+e3[t];
    end
    return y=y1+y2+y3
end

function simulAR1_mixture5(e1,e2,e3,e4)
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=4:1268
        y1[t]=0.6*y1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=4:1268
        y2[t]=0.4*y2[t-3]+e2[t];
    end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=4:1268
        y3[t]=-0.5*y3[t-1]+e3[t];
    end
    y4=zeros(1268);
    y4[1]=e4[1]
    for t=4:1268
        y4[t]=0.7*y4[t-2]+e4[t];
    end
    return y=y1+y2+y3+y4
end

function simulAR1_mixture_lags_1(e1,e2,e3,e4)
    #### SAME NOISE #####
    y1=zeros(1268);
    y1[1]=e1[1]
    for t=9:1268
        y1[t]=0.8*e1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e1[1]
    for t=9:1268
        y2[t]=0.4*e1[t-1]+0.4*e1[t-2]+e1[t];
    end
    y3=zeros(1268);
    y3[1]=e1[1]
    for t=9:1268
        y3[t]=0.8*e1[t-1]+0.6*e1[t-2]+0.4*e1[t-3]+0.2*e1[t-4]+e1[t];
    end
    # y4=zeros(1268);
    # y4[1]=e4[1]
    # for t=9:1268
    #     y4[t]=0.7*y4[t-8]+e4[t];
    # end
    return y=y1+y2+y3
end

function simulAR1_mixture_lags_2(e1,e2,e3,e)

    ys=zeros(1268);
    spp=zeros(1268);
    for tt=1:1268
        spp[tt]=sin(tt/(1268/10))
    end
    
    ys[1]=e[1]
    for t=9:1268
        ys[t]=0.95*spp[t]*ys[t-1]+e[t];
    end

    y1=zeros(1268);
    y1[1]=e1[1]
    for t=9:1268
        y1[t]=0.8*e1[t-1]+e1[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=9:1268
        y2[t]=0.4*e2[t-1]+0.4*e2[t-2]+e2[t];
    end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=9:1268
        y3[t]=0.8*e3[t-1]+0.6*e3[t-2]+0.4*e3[t-3]+0.4*e3[t-4]+e3[t];
    end

    return y=y1+y2+y3+ys
end



function simulAR1_sin_MA_1(e1,e2,e3,e)

    ys=zeros(1268);
    spp1=zeros(1268);
    spp2=zeros(1268);
    for tt=1:1268
        spp1[tt]=sin(tt/(1268/20))*0.9
        spp2[tt]=sin(tt/(1268/10))*0.9
    end
    
    # ys[1]=e[1]
    # for t=9:1268
    #     ys[t]=0.95*spp[t]*ys[t-1]+e[t];
    # end

    y1=zeros(1268);
    y1[1]=e1[1]
    for t=9:1268
        y1[t]=spp1[t]*e1[t-1]+spp1[t]*e1[t-2]+e1[t];
    end
    # y2=zeros(1268);
    # y2[1]=e2[1]
    # for t=9:1268
    #     y2[t]=0.4*e2[t-1]+0.4*e2[t-2]+e2[t];
    # end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=9:1268
        y3[t]=spp2[t]*e3[t-1]+spp2[t]*e3[t-2]+spp2[t]*e3[t-3]+spp2[t]*e3[t-4]+spp2[t]*e3[t-5]+spp2[t]*e3[t-6]+spp2[t]*e3[t-7]+spp2[t]*e3[t-8]e3[t];
    end

    return y=y1+y3
end




function AR_break_mix_2(e,e2,e3)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:800
        y[t]=-0.7*y[t-1]+e[t];
    end
    for t=801:1268
        y[t]=0.8*y[t-1]+e[t];
    end
    y2=zeros(1268);
    y2[1]=e2[1]
    for t=2:1268
        y2[t]=0.4*y2[t-1]+e2[t];
    end
    y3=zeros(1268);
    y3[1]=e3[1]
    for t=2:1268
        y3[t]=0.6*y3[t-1]+e3[t];
    end
    return y+y2+y3 
end


function AR_050(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:1268
        y[t]=0.5*y[t-1]+e[t];
    end
    return y 
end

function AR_075(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:1268
        y[t]=0.75*y[t-1]+e[t];
    end
    return y 
end

function AR_090(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:1268
        y[t]=0.9*y[t-1]+e[t];
    end
    return y 
end

############################### BREAKS ##############################

function AR_break_2(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:800
        y[t]=-0.8*y[t-1]+e[t];
    end
    for t=801:1268
        y[t]=0.8*y[t-1]+e[t];
    end
    return y 
end

function AR_break_2_2(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:600
        y[t]=-0.8*y[t-1]+e[t];
    end
    for t=651:950
        y[t]=0.8*y[t-1]+e[t];
    end
    for t=951:1268
        y[t]=-0.8*y[t-1]+e[t];
    end
    return y 
end


function AR_break_3(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:600
        y[t]=0.8*y[t-1]+e[t];
    end
    for t=601:800
        y[t]=-0.8*y[t-1]+e[t];
    end
    for t=801:1000
        y[t]=0.8*y[t-1]+e[t];
    end
    for t=1001:1268
        y[t]=-0.8*y[t-1]+e[t];
    end

    return y 
end

function AR_break_3b(e)
    y=zeros(1268);
    y[1]=e[1]
    for t=2:600
        y[t]=-0.8*y[t-1]+e[t];
    end
    for t=601:800
        y[t]=0.8*y[t-1]+e[t];
    end
    for t=801:1000
        y[t]=-0.8*y[t-1]+e[t];
    end
    for t=1001:1268
        y[t]=0.8*y[t-1]+e[t];
    end

    return y 
end

# function AR_break_4(e)
#     y=zeros(1268);
#     y[1]=e[1]
#     for t=2:600
#         y[t]=0.8*y[t-1]+e[t];
#     end
#     for t=601:800
#         y[t]=-0.8*y[t-1]+e[t];
#     end
#     for t=801:1000
#         y[t]=0.8*y[t-1]+e[t];
#     end
#     for t=1001:1100
#         y[t]=-0.8*y[t-1]+e[t];
#     end
#     for t=1101:1268
#         y[t]=0.8*y[t-1]+e[t];
#     end
#     return y 
# end




function ratio(error,t1,t2,loss,num_los)
    
    benchmark=1
    num_loss=num_los
    
    if loss == "RMSE"
    
        rat=Float64.(hcat([[sqrt(mean(error[j][t1:t2,k].^2))/sqrt(mean(error[j][t1:t2,benchmark].^2)) for j=1:size(error)[1]] for k=1:num_loss]...)')
        rat=rat[Not(benchmark),:];
    elseif loss == "MAE"
        rat=Float64.(hcat([[mean(abs.(error[j][t1:t2,k]))/mean(abs.(error[j][t1:t2,benchmark])) for j=1:size(error)[1]] for k=1:num_loss]...)')
        rat=rat[Not(benchmark),:];
    elseif loss == "MMEO"
        rat=Float64.(hcat([[(1/length(error[1][t1:t2,k])*(sum(abs.((error[j][t1:t2,k].<0).*error[j][t1:t2,k]))+sum(sqrt.(abs.((error[j][t1:t2,k].>0).*error[j][t1:t2,k])))))/
                        (1/length(error[1][t1:t2,benchmark])*(sum(abs.((error[j][t1:t2,benchmark].<0).*error[j][t1:t2,benchmark]))+sum(sqrt.(abs.((error[j][t1:t2,benchmark].>0).*error[j][t1:t2,benchmark])))))  
                        for j=1:size(error)[1]] for k=1:num_loss]...)')
        rat=rat[Not(benchmark),:];
    elseif loss == "MMEU"
        rat=Float64.(hcat([[(1/length(error[1][t1:t2,k])*(sum(abs.((error[j][t1:t2,k].>0).*error[j][t1:t2,k]))+sum(sqrt.(abs.((error[j][t1:t2,k].<0).*error[j][t1:t2,k])))))/
                        (1/length(error[1][t1:t2,benchmark])*(sum(abs.((error[j][t1:t2,benchmark].>0).*error[j][t1:t2,benchmark]))+sum(sqrt.(abs.((error[j][t1:t2,benchmark].<0).*error[j][t1:t2,benchmark])))))  
                        for j=1:size(error)[1]] for k=1:num_loss]...)')
        rat=rat[Not(benchmark),:];
    elseif loss == "MMEUpercentage"
        rat=Float64.(hcat([[sum(error[j][t1:t2,k].<0)/length(error[1][t1:t2,k]) for j=1:size(error)[1]] for k=1:num_loss]...)')
    end
    
        return rat
end


function OLSestimator(y,x)
    return (transpose(x)*x) \ (transpose(x)*y)
end

function OLSestimatorconst(y,x)
    x=[ones(size(x)[1]) x]
    return (transpose(x)*x) \ (transpose(x)*y)
end



function stat_eval(RV_h,err,forecast,fcast_length)
    
    # Statistics EWD
    MAE=mean(abs.(err))
    MSE=sqrt(mean(err.^2))

    dataD = DataFrame(Y=RV_h[1:fcast_length], X=forecast)
    MZols = lm(@formula(Y ~ X), dataD);

    return [MAE;MSE;coeftable(MZols).cols[1];r2(MZols)]
end



function IRFalpha(y,x,maxAR,M)

    b=OLSestimator(y,x)
    Eta=y-x*b;
    sigma2=(Eta'*Eta)./(length(y)-maxAR)
    sigma=sqrt.(sigma2)
    Eps=Eta./sigma;

    alphaR=zeros(M)
    alphaR[1]=sigma

    for n=1:(length(alphaR)-1) 
        hstart=max(n-maxAR,0);
        temp=0;
        for h=hstart:n-1 
            temp=temp+alphaR[h+1]*b[n-h]; 
        end
        alphaR[n+1]=temp;
    end
    return (alphaR,Eps)
end

function ARlags(X, p)
    #AR regression to estimate the AR coefficients
    y=X[1:end-p]
    xx = zeros(length(y),p)
    for i=1:length(y)
        xx[i,:]=X[i+1:i+p]; #fill the matrix with lags
    end
    return (y,xx)
end


function IRFalpha_tvp_LLS(y,x,maxAR,M,kernel_width)
    
    # New localized linear LS estimate
    R"aa <- tvOLS($x,$y, bw = $kernel_width)$coefficients"
    b_tvp_all=convert(Array{Float64},R"aa")

    Eta_tvp=zeros(length(y))
    for i=1:length(y)
        Eta_tvp[i] = y[i]-sum(b_tvp_all[i,:].*x[i,:]);
    end

    sigma2_tvp=(Eta_tvp'*Eta_tvp)./(length(y)-maxAR)
    sigma_tvp=sqrt.(sigma2_tvp)
    Eps_tvp=Eta_tvp./sigma_tvp;


    alphaR_tvp=zeros(M);
    alphaR_tvp[1]=sigma_tvp;

    for n=1:(length(alphaR_tvp)-1) 
        hstart=max(n-maxAR,0);
        temp=0;
        for h=hstart:n-1 
            temp=temp+alphaR_tvp[h+1]*b_tvp_all[1,n-h];    # choses last position of kernel!!!
        end
        alphaR_tvp[n+1]=temp;
    end

    return (alphaR_tvp,Eps_tvp)
end



function normker(T, H)
  ww = zeros(T, T)
  for j in 1:T
    for i in 1:T
      z = (i - j)/H
      ww[i,j] = (1.0 / sqrt(2.0 * pi)) * exp((-1.0 / 2.0) * (z * z))  # Normal
      #ww[i,j] = (2.0 / pi ) * (1.0 / (exp(z) + exp(-z))) # sigmoid
      #ww[i,j] = 1.0 / (exp(z)+2.0+exp(-z)) # Logistic
      #ww[i,j] = 1.0 - abs(z)  # traingular
      #ww[i,j] = (3.0/4.0)*(1.0-(z * z)) # epan
    end     
  end 

  s = sum(ww, dims=2)
  adjw = zeros(T, T)  

  for k in 1:T
    adjw[k, :] = ww[k, :] / s[k]
  end

  cons = sum(adjw .^ 2.0, dims = 2)

  for k in 1:T
    adjw[k, :] = (1.0 / cons[k]) * (adjw[k, :])
  end

  return adjw
end


function IRFscale(T,maxAR,alpha0,Eps,KMAX,J)
    # input:  vector alpha of classical Wold innovations
    #         with length 2^JMAX * constant
    #         T sample length
    #         maxAR max lag in the baseline AR
    #         Eps vector of unit variance classical Wold innovations in reverse order
    #         KMAX=2^(JMAX+3) maximum lag on scales
    #         J scale
    # output: vector betaScale of multiscale IRF at scale J with length length(alpha)/(2^J)
    #         vector EpsScale of details at scale J in reverse order with length T-maxAR-2^J+1
    #         vector gScale of component at scale J in reverse order with length T-maxAR-KMAX+1
    #         vector chronGScale is gScale in chronological order
    #         vector decimGScale of decimated component at scale J in reverse order with length floor(length(gScale)/2^J)

    # all processes have ZERO MEAN
   
    M=length(alpha0);
    betaScale=zeros(Int(M./(2.0.^J)));
    for k=0:Int(floor(M/(2^J))-1)
        betaScale[k+1]=(sum(alpha0[k*2^J+1:k*2^J+2^(J-1)]) - sum(alpha0[k*2^J+2^(J-1)+1:k*2^J+2^J]))./sqrt(2^J);
    end
    
    EpsScale=zeros(T-maxAR-2^J+1);
    for t=0:1:(length(EpsScale)-1)
        EpsScale[t+1]= (sum(Eps[t+1:t+2^(J-1)])-sum(Eps[t+2^(J-1)+1:t+2^J]))./sqrt(2^J);
    end
    
    gScale=zeros(T-maxAR-KMAX+1); 
    for t=0:1:(T-maxAR-KMAX)
            for k=0:1:(Int(KMAX/(2^J)-1))
                gScale[t+1]+=betaScale[k+1].*EpsScale[t+k*2^J+1]
            end
    end 
    chronGScale=reverse(gScale);
    
    #decimGScale=zeros(Int(floor(length(gScale)/2^J)));
    #for i=1:1:length(gScale)
    #    if mod(i-1,2^J)==0
    #        decimGScale[Int((i-1)/2^J+1)]=gScale[i];
    #    end
    #end
    
    decimGScale=[];
    for i=1:1:length(gScale)
        if mod(i-1,2^J)==0
            push!(decimGScale,gScale[i]);
        end
    end
    
    return (betaScale,EpsScale,gScale,chronGScale,decimGScale)
end


function IRFforecast_horizon(T,maxAR,alpha0,Eps,KMAX,J,horizon)
    
    # input:  vector alpha of classical Wold innovations
    #         with length 2^JMAX * constant
    #         T sample length
    #         maxAR max lag in the baseline AR
    #         Eps vector of unit variance classical Wold innovations in reverse order
    #         KMAX=2^(JMAX+3) maximum lag on scales
    #         J scale
    #         horizon max lag in forecasts
    # output: matrix betaPlus of multiscale IRF Beta k,p at scale J with length length(alpha)/(2^J), p goes from 1 to horizon 
    #         (see Appendix of Ortu Severino Tamoni Tebaldi)
    #         vector gScale of forecast for the sum of following week values of scale J in reverse order with length T-maxAR-KMAX+1

    # all processes have ZERO MEAN
   
    M=length(alpha0);
    betaPlus=zeros(Int(floor((M-horizon)/(2^J)))-1,horizon); #collects betak,p
    for p=1:horizon #p are the steps ahead as in Appendix of Ortu Severino Tamoni Tebaldi
        for k=0:(Int(floor((M-horizon)/(2^J)))-2)
            betaPlus[k+1,p]=(sum(alpha0[k*2^J+1+p:k*2^J+2^(J-1)+p])-sum(alpha0[k*2^J+2^(J-1)+1+p:k*2^J+2^J+p]))/sqrt(2^J);
        end                     
    end
    
    EpsScale=zeros(T-maxAR-2^J+1);
    for t=0:1:(length(EpsScale)-1)
        EpsScale[t+1]= (sum(Eps[t+1:t+2^(J-1)])-sum(Eps[t+2^(J-1)+1:t+2^J]))./sqrt(2^J);
    end
    
    gScale=zeros(T-maxAR-KMAX+1,horizon); #now gscale has to contain all the p step ahead forecasts
    for p=1:horizon
        for t=0:1:(T-maxAR-KMAX)    
            for k=0:1:(Int(floor((KMAX-horizon)/(2^J)))-2)
                gScale[t+1,p]+=betaPlus[k+1,p]*EpsScale[t+k*2^J+1];
            end
        end
    end 
     gScale=sum(gScale,dims=2) #we make row-wise sums
    
    return (betaPlus, gScale)
end


function RW(data0,tt,fcast_length,horizon)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);

    for ii=0:(fcast_length-1)
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
        
        forecasts_ar1 =[]
        forecasts_ar1 = est_sample_tvp[end];
        
        horizon_forecast_AR[ii+1] = forecasts_ar1;
 
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
 
    end
    return (horizon_forecast_AR,Error_Jcomp_tvp)
end

function ARX(data0,tt,fcast_length,horizon,x)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);

    for ii=0:(fcast_length-1)
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
        
        
        forecasts_ar1 =[]
        for_ar1=[]
       R"forecasts_ar1<- predict(Arima($est_sample_tvp, order = c($x,0,0),include.constant=TRUE), n.ahead=$horizon)$pred[1:$horizon]" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        forecasts_ar1 = mean(for_ar1)
        
        horizon_forecast_AR[ii+1] = forecasts_ar1
 
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
 
    end
    return (horizon_forecast_AR,Error_Jcomp_tvp)
end


function AR1(data0,tt,fcast_length,horizon)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);

    for ii=0:(fcast_length-1)
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
        
        
        forecasts_ar1 =[]
        for_ar1=[]
       R"forecasts_ar1<- predict(Arima($est_sample_tvp, order = c(1,0,0),include.constant=TRUE), n.ahead=$horizon)$pred[1:$horizon]" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        forecasts_ar1 = mean(for_ar1)
        
        horizon_forecast_AR[ii+1] = forecasts_ar1
 
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
 
    end
    return (horizon_forecast_AR,Error_Jcomp_tvp)
end

function AR2(data0,tt,fcast_length,horizon)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);

    for ii=0:(fcast_length-1)
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
        
        
        forecasts_ar1 =[]
        for_ar1=[]
       R"forecasts_ar1<- predict(Arima($est_sample_tvp, order = c(2,0,0),include.constant=TRUE), n.ahead=$horizon)$pred[1:$horizon]" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        forecasts_ar1 = mean(for_ar1)
        
        horizon_forecast_AR[ii+1] = forecasts_ar1
 
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
 
    end
    return (horizon_forecast_AR,Error_Jcomp_tvp)
end


function AR1_parallel(ii,data0,tt,fcast_length,horizon)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end


#     horizon_forecast_AR= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);

#     for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
            
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- predict(Arima($est_sample_tvp, order = c(1,0,0),include.constant=TRUE), n.ahead=$horizon)$pred[1:$horizon]" 

        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        horizon_forecast_AR = mean(for_ar1)
    
        # error with J components
        Error_Jcomp_tvp=  (horizon_forecast_AR-RVh[fcast_length-ii])
 
    #end
    return [horizon_forecast_AR;Error_Jcomp_tvp]
end



function AR3(data0,tt,fcast_length,horizon)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);

    for ii=0:(fcast_length-1)
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
        
        
        forecasts_ar1 =[]
        for_ar1=[]
       R"forecasts_ar1<- predict(Arima($est_sample_tvp, order = c(3,0,0),include.constant=TRUE), n.ahead=$horizon)$pred[1:$horizon]" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        forecasts_ar1 = mean(for_ar1)
        
        horizon_forecast_AR[ii+1] = forecasts_ar1
 
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
 
    end
    return (horizon_forecast_AR,Error_Jcomp_tvp)
end

##### TVP-AR(3) with const forecast #########
function AR3_tvLS(data0,tt,fcast_length,horizon,kernel_width_ARtvp)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end
    
    horizon_forecast_AR= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);

    for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
           
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- tvReg::forecast(tvAR($est_sample_tvp,p=3,bw = $kernel_width_ARtvp),n.ahead=$horizon)" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")
        forecasts_ar1 = mean(for_ar1)
        horizon_forecast_AR[ii+1] = forecasts_ar1

        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_AR[ii+1]-RVh[fcast_length-ii])
        
    end
    return [horizon_forecast_AR, Error_Jcomp_tvp]
end

function ARX_tvLS_parallel(ii,data0,tt,fcast_length,horizon,kernel_width_ARtvp,x)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
#     horizon_forecast_AR= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);

#     for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
            
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- tvReg::forecast(tvAR($est_sample_tvp,p=$x,bw = $kernel_width_ARtvp),n.ahead=$horizon)" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        horizon_forecast_AR = mean(for_ar1)
    
        # error with J components
        Error_Jcomp_tvp=  (horizon_forecast_AR-RVh[fcast_length-ii])
 
    #end
    return [horizon_forecast_AR;Error_Jcomp_tvp]
end


function AR1_tvLS_parallel(ii,data0,tt,fcast_length,horizon,kernel_width_ARtvp)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
#     horizon_forecast_AR= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);

#     for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
            
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- tvReg::forecast(tvAR($est_sample_tvp,p=1,bw = $kernel_width_ARtvp),n.ahead=$horizon)" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        horizon_forecast_AR = mean(for_ar1)
    
        # error with J components
        Error_Jcomp_tvp=  (horizon_forecast_AR-RVh[fcast_length-ii])
 
    #end
    return [horizon_forecast_AR;Error_Jcomp_tvp]
end

function AR2_tvLS_parallel(ii,data0,tt,fcast_length,horizon,kernel_width_ARtvp)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
#     horizon_forecast_AR= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);

#     for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
            
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- tvReg::forecast(tvAR($est_sample_tvp,p=2,bw = $kernel_width_ARtvp),n.ahead=$horizon)" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        horizon_forecast_AR = mean(for_ar1)
    
        # error with J components
        Error_Jcomp_tvp=  (horizon_forecast_AR-RVh[fcast_length-ii])
 
    #end
    return [horizon_forecast_AR;Error_Jcomp_tvp]
end


function AR3_tvLS_parallel(ii,data0,tt,fcast_length,horizon,kernel_width_ARtvp)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    
#     horizon_forecast_AR= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);

#     for ii=0:(fcast_length-1)
    
        #!!!!! REVERSE ? !!!!! 
        est_sample_tvp = reverse(r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)])
            
        forecasts_ar1 =[]
        for_ar1=[]
        R"forecasts_ar1<- tvReg::forecast(tvAR($est_sample_tvp,p=3,bw = $kernel_width_ARtvp),n.ahead=$horizon)" 
        for_ar1=convert(Array{Float64},R"forecasts_ar1")   
        horizon_forecast_AR = mean(for_ar1)
    
        # error with J components
        Error_Jcomp_tvp=  (horizon_forecast_AR-RVh[fcast_length-ii])
 
    #end
    return [horizon_forecast_AR;Error_Jcomp_tvp]
end


function HAR(data0,tt,fcast_length,horizon)

    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR
    r=reverse(chronR);

    RVh = zeros(length(r)-horizon+1,1);
        for i=1:length(RVh)
            RVh[i]=mean(r[i:i+horizon-1])
        end

    RVd = r[1:end-22];
    RVw = zeros(length(RVd));
    for i=1:length(RVd)
       RVw[i]= (r[i]+r[i+1]+r[i+2]+r[i+3]+r[i+4])/5;
    end

    RVm = zeros(length(RVd));
    for i=1:length(RVd) 
       temp=0;
       for h=0:21
           temp = temp + r[i+h];
       end
       RVm[i]= temp./22;
    end

    horizon_forecast_corsi=zeros(fcast_length);
    daily_onestep=zeros(fcast_length,horizon);
    const_HAR=zeros(fcast_length,horizon);

    Error_HAR=zeros(fcast_length);

    for ii=0:(fcast_length-1)

        RVd_estim = RVd[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];  #is the moving window of TT obs, moves towards RVd(0)
        RVw_estim = RVw[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];
        RVm_estim = RVm[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];

        Rmat = [ones(length(RVd_estim)-1) RVd_estim[2:end] RVw_estim[2:end] RVm_estim[2:end]]
        betaHAR=OLSestimator(RVd_estim[1:end-1],Rmat)

        #One-step ahead out of sample forecast, forecasts RVd(fcast_length+4)
        daily_onestep[ii+1,1]= betaHAR[1] + betaHAR[2]*RVd_estim[1] + betaHAR[3]*RVw_estim[1] + betaHAR[4]*RVm_estim[1]; 

        if horizon >=2
            for p=2:min(5,horizon)
                daily_onestep[ii+1,p]= betaHAR[1] + betaHAR[2]*daily_onestep[ii+1,p-1] + betaHAR[3]*0.2*(sum(daily_onestep[ii+1,1:p-1])+sum(RVd_estim[1:5-p+1])) + betaHAR[4]*(1/22)*(sum(daily_onestep[ii+1,1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon >= 6
            for p=6:min(22,horizon)
                daily_onestep[ii+1,p]= betaHAR[1] + betaHAR[2]*daily_onestep[ii+1,p-1] + betaHAR[3]*0.2*(sum(daily_onestep[ii+1,p-5:p-1])) + betaHAR[4]*(1/22)*(sum(daily_onestep[ii+1,1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon>= 23
            for p=23:horizon
                daily_onestep[ii+1,p]= betaHAR[1] + betaHAR[2]*daily_onestep[ii+1,p-1] + betaHAR[3]*0.2*(sum(daily_onestep[ii+1,p-5:p-1])) + betaHAR[4]*(1/22)*(sum(daily_onestep[ii+1,p-22:p-1]));
            end
        end

        horizon_forecast_corsi[ii+1] = horizon^(-1)*sum(daily_onestep[(ii+1),:]); 
        Error_HAR[ii+1]=(horizon_forecast_corsi[ii+1]-RVh[fcast_length-ii])
        const_HAR[ii+1]=betaHAR[1]
        
    end
    return (horizon_forecast_corsi,Error_HAR,const_HAR)
end

function HAR_tvLS(data0,tt,fcast_length,horizon,kernel_width)

    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR
    r=reverse(chronR);

    RVh = zeros(length(r)-horizon+1,1);
        for i=1:length(RVh)
            RVh[i]=mean(r[i:i+horizon-1])
        end

    RVd = r[1:end-22];
    RVw = zeros(length(RVd));
    for i=1:length(RVd)
       RVw[i]= (r[i]+r[i+1]+r[i+2]+r[i+3]+r[i+4])/5;
    end

    RVm = zeros(length(RVd));
    for i=1:length(RVd) 
       temp=0;
       for h=0:21
           temp = temp + r[i+h];
       end
       RVm[i]= temp./22;
    end

    horizon_forecast_corsiTVP=zeros(fcast_length);
    daily_onestepTVP=zeros(fcast_length,horizon);
    Error_HARTVP=zeros(fcast_length);

    for ii=0:(fcast_length-1)

        RVd_estim = RVd[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];  #is the moving window of TT obs, moves towards RVd(0)
        RVw_estim = RVw[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];
        RVm_estim = RVm[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];
    
        Rmat = [ones(length(RVd_estim)-1) RVd_estim[2:end] RVw_estim[2:end] RVm_estim[2:end]]
        # !!!!!!!!!!!!!!!!!!!!!!!!!!
#         Rmat = [ones(length(RVd_estim)-1) RVd_estim[1:end-1] RVw_estim[1:end-1] RVm_estim[1:end-1]]

        # new TVP estimation
        y=RVd_estim[1:end-1]
        R"aa <- tvOLS(as.matrix($Rmat),$y, bw = $kernel_width)$coefficients"
        tvp_ols=convert(Array{Float64},R"aa")

        #One-step ahead out of sample forecast, forecasts RVd(fcast_length+4)
        daily_onestepTVP[ii+1,1]= tvp_ols[1,1] + tvp_ols[1,2]*RVd_estim[1] + tvp_ols[1,3]*RVw_estim[1] + tvp_ols[1,4]*RVm_estim[1]; 

        if horizon >=2
            for p=2:min(5,horizon)
                daily_onestepTVP[ii+1,p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[ii+1,p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[ii+1,1:p-1])+sum(RVd_estim[1:5-p+1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[ii+1,1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon >= 6
            for p=6:min(22,horizon)
                daily_onestepTVP[ii+1,p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[ii+1,p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[ii+1,p-5:p-1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[ii+1,1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon>= 23
            for p=23:horizon
                daily_onestepTVP[ii+1,p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[ii+1,p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[ii+1,p-5:p-1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[ii+1,p-22:p-1]));
            end
        end

        horizon_forecast_corsiTVP[ii+1] = horizon^(-1)*sum(daily_onestepTVP[(ii+1),:]); 
        Error_HARTVP[ii+1]=(horizon_forecast_corsiTVP[ii+1]-RVh[fcast_length-ii])
 end
    return [horizon_forecast_corsiTVP,Error_HARTVP]
end




function HAR_tvLS_parralel(ii,data0,tt,fcast_length,horizon,kernel_width)

    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR
    r=reverse(chronR);

    RVh = zeros(length(r)-horizon+1,1);
        for i=1:length(RVh)
            RVh[i]=mean(r[i:i+horizon-1])
        end

    RVd = r[1:end-22];
    RVw = zeros(length(RVd));
    for i=1:length(RVd)
       RVw[i]= (r[i]+r[i+1]+r[i+2]+r[i+3]+r[i+4])/5;
    end

    RVm = zeros(length(RVd));
    for i=1:length(RVd) 
       temp=0;
       for h=0:21
           temp = temp + r[i+h];
       end
       RVm[i]= temp./22;
    end

    #horizon_forecast_corsiTVP=zeros(fcast_length);
    daily_onestepTVP=zeros(horizon);

    #Error_HARTVP=zeros(fcast_length);

    #for ii=0:(fcast_length-1)

        RVd_estim = RVd[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];  #is the moving window of TT obs, moves towards RVd(0)
        RVw_estim = RVw[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];
        RVm_estim = RVm[fcast_length+horizon-ii: fcast_length + tt+horizon-1-ii];
    
        Rmat = [ones(length(RVd_estim)-1) RVd_estim[2:end] RVw_estim[2:end] RVm_estim[2:end]]

        # new TVP estimation
        y=RVd_estim[1:end-1]
        R"aa <- tvOLS(as.matrix($Rmat),$y, bw = $kernel_width)$coefficients"
        tvp_ols=convert(Array{Float64},R"aa")

        #One-step ahead out of sample forecast, forecasts RVd(fcast_length+4)
        daily_onestepTVP[1]= tvp_ols[1,1] + tvp_ols[1,2]*RVd_estim[1] + tvp_ols[1,3]*RVw_estim[1] + tvp_ols[1,4]*RVm_estim[1]; 

        if horizon >=2
            for p=2:min(5,horizon)
                daily_onestepTVP[p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[1:p-1])+sum(RVd_estim[1:5-p+1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon >= 6
            for p=6:min(22,horizon)
                daily_onestepTVP[p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[p-5:p-1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[1:p-1])+ sum(RVd_estim[1:22-p+1]));
            end
        end

        if horizon>= 23
            for p=23:horizon
                daily_onestepTVP[p]= tvp_ols[1,1] + tvp_ols[1,2]*daily_onestepTVP[p-1] + tvp_ols[1,3]*0.2*(sum(daily_onestepTVP[p-5:p-1])) + tvp_ols[1,4]*(1/22)*(sum(daily_onestepTVP[p-22:p-1]));
            end
        end

        horizon_forecast_corsiTVP = horizon^(-1)*sum(daily_onestepTVP); 
        Error_HARTVP=(horizon_forecast_corsiTVP-RVh[fcast_length-ii])
 #end
    return [horizon_forecast_corsiTVP;Error_HARTVP]
end


##### EWD decomposition

function EWD(data0,tt,maxAR,JMAX,horizon)

    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    M=Int.(2^(JMAX)*(floor((tt -maxAR)/(2^(JMAX)))-1));
    KMAX = M;

    horizon_forecast_Jcomp= zeros(fcast_length);
    Error_Jcomp=zeros(fcast_length);
    RV_h=zeros(fcast_length);

    for ii=0:(fcast_length-1)

        est_sample = r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)]

        # AR regression to estimate the AR coefficients
        # alpha coefficients and the Eps for the current sample
        (truncR,Rmat)=ARlags(est_sample, maxAR)
        (alphaR,Eps)=IRFalpha(truncR,Rmat,maxAR,M);

        # Estimate the decomposition
        betaRj=[]
        rj=[]
        for j in 1:JMAX
            (betaR, _ , r0, _ , _)=IRFscale(tt,maxAR,alphaR,Eps,KMAX,j);
            push!(betaRj,betaR)
            push!(rj,r0)
        end

        # Estimate coefficients of regression model
        b_Jcomp=OLSestimatorconst(est_sample[1:length(rj[JMAX])],hcat(rj...))

        # We forecast the sum horizon-step ahead 
        betaFj=[]
        rfj=[]
        for j in 1:JMAX
            (betaF,rf)=IRFforecast_horizon(tt,maxAR,alphaR,Eps,KMAX,j,horizon);
            push!(betaFj,betaF)
            push!(rfj,rf)
        end

        RFmat_Jcomp=[ones(size(hcat(rfj...))[1]) hcat(rfj...)];
        horizon_forecast_Jcomp[ii+1]=(horizon^(-1).*RFmat_Jcomp[1,:])'*[horizon*b_Jcomp[1]; b_Jcomp[2:end]];

        # error with J components
        RV_h[ii+1]=RVh[fcast_length-ii];
        Error_Jcomp[ii+1]=  (horizon_forecast_Jcomp[ii+1]-RV_h[ii+1]);

    end
    
    return (horizon_forecast_Jcomp,RV_h,Error_Jcomp)
end


function EWD_parallel(ii,data0,tt,maxAR,JMAX,horizon)

    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    M=Int.(2^(JMAX)*(floor((tt -maxAR)/(2^(JMAX)))-1));
    KMAX = M;

#     horizon_forecast_Jcomp= zeros(fcast_length);
#     Error_Jcomp=zeros(fcast_length);
#     RV_h=zeros(fcast_length);

#     for ii=0:(fcast_length-1)

        est_sample = r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)]

        # AR regression to estimate the AR coefficients
        # alpha coefficients and the Eps for the current sample
        (truncR,Rmat)=ARlags(est_sample, maxAR)
        (alphaR,Eps)=IRFalpha(truncR,Rmat,maxAR,M);

        # Estimate the decomposition
        betaRj=[]
        rj=[]
        for j in 1:JMAX
            (betaR, _ , r0, _ , _)=IRFscale(tt,maxAR,alphaR,Eps,KMAX,j);
            push!(betaRj,betaR)
            push!(rj,r0)
        end

        # Estimate coefficients of regression model
        b_Jcomp=OLSestimatorconst(est_sample[1:length(rj[JMAX])],hcat(rj...))

        # We forecast the sum horizon-step ahead 
        betaFj=[]
        rfj=[]
        for j in 1:JMAX
            (betaF,rf)=IRFforecast_horizon(tt,maxAR,alphaR,Eps,KMAX,j,horizon);
            push!(betaFj,betaF)
            push!(rfj,rf)
        end

        RFmat_Jcomp=[ones(size(hcat(rfj...))[1]) hcat(rfj...)];
    
        horizon_forecast_Jcomp=(horizon^(-1).*RFmat_Jcomp[1,:])'*[horizon*b_Jcomp[1]; b_Jcomp[2:end]];

        # error with J components
        RV_h=RVh[fcast_length-ii];
        Error_Jcomp=horizon_forecast_Jcomp-RV_h;

#     end
    
    return [horizon_forecast_Jcomp;RV_h;Error_Jcomp]
end





function EWD_tvLS(data0,tt,maxAR,JMAX,horizon,kernel_width_for_const,kernel_width_IRF,kernel_width_forecast,AR_lag_forecast)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    M=Int.(2^(JMAX)*(floor((tt-maxAR)/(2^(JMAX)))-1))
    KMAX = M

    horizon_forecast_Jcomp_tvp= zeros(fcast_length);
    Error_Jcomp_tvp=zeros(fcast_length);
    errs0_last=zeros(fcast_length);
    forecasted_constant=zeros(fcast_length);
    variance_scales=zeros(fcast_length,JMAX);
    first_forecasted_beta_scales=zeros(fcast_length,JMAX);
    vv =zeros(JMAX);

    for ii=0:(fcast_length-1)
        est_sample_tvp = r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)]
        
        # new trend estimation
        x=ones(length(est_sample_tvp))
        R"aa <- tvOLS(as.matrix($x),$est_sample_tvp, bw = $kernel_width_for_const)$coefficients"
        tvp_const=convert(Array{Float64},R"aa")
        errs0=est_sample_tvp.-tvp_const
    
        
        (truncR,Rmat)=ARlags(errs0, maxAR);
        #(alphaR_tvp,Eps_tvp,tvp_const) = IRFalpha_tvp(truncR,Rmat,maxAR,M,kernel_width)
        (alphaR_tvp,Eps_tvp) = IRFalpha_tvp_LLS(truncR,Rmat,maxAR,M,kernel_width_IRF)


        # Estimate the decomposition
        betaRj_tvp=[]
        rj_tvp=[]
        for j in 1:JMAX
            (betaR, _ , r0, _ , _)=IRFscale(tt,maxAR,alphaR_tvp,Eps_tvp,KMAX,j);
            push!(betaRj_tvp,betaR)
            push!(rj_tvp,r0)
        end
        
        #################### Variance on Scales ###################
        
        # Estimate coefficients of regression model
        b_Jcomp_tvp=OLSestimator(est_sample_tvp[1:length(rj_tvp[JMAX])],[tvp_const[1:length(rj_tvp[JMAX])] hcat(rj_tvp...)])
   
        forecasts_ar =[]
        for_ar=[]
        rev=vec(reverse(tvp_const));

        R"forecasts_ar<- tvReg::forecast(tvAR($rev,p=$AR_lag_forecast,bw = $kernel_width_forecast),n.ahead=$horizon)" 
    
        for_ar=convert(Array{Float64},R"forecasts_ar")  
        for_const = mean(for_ar)
        
        
        ######################## EWD FORECAST #####################
        
        # We forecast the sum horizon-step ahead 
        betaFj_tvp=[]
        rfj_tvp=[]
        for j in 1:JMAX
            (betaF,rf)=IRFforecast_horizon(tt,maxAR,alphaR_tvp,Eps_tvp,KMAX,j,horizon);
            push!(betaFj_tvp,betaF)
            push!(rfj_tvp,rf)
        end
        
        RFmat_Jcomp_tvp=[for_const.*ones(size(hcat(rfj_tvp...))[1]) hcat(rfj_tvp...)]; # with const pred
        
        horizon_forecast_Jcomp_tvp[ii+1]=(horizon^(-1).*RFmat_Jcomp_tvp[1,:])'*[horizon*b_Jcomp_tvp[1]; b_Jcomp_tvp[2:end]];
        
        # error with J components
        Error_Jcomp_tvp[ii+1]=  (horizon_forecast_Jcomp_tvp[ii+1]-RVh[fcast_length-ii])
        
    end
    return (horizon_forecast_Jcomp_tvp,Error_Jcomp_tvp)
end


function EWD_tvLS_parallel(ii,data0,tt,maxAR,JMAX,horizon,kernel_width_for_const,kernel_width_IRF,kernel_width_forecast,AR_lag_forecast)
    
    T=length(data0)
    muR=mean(data0)
    chronR=data0.-muR;
    r=reverse(chronR);

    fcast_length = T-tt-21-horizon; #length of forecast sample

    RVh = zeros(length(r)-horizon+1,1);
    for i=1:length(RVh)
        RVh[i]=mean(r[i:i+horizon-1])
    end

    M=Int.(2^(JMAX)*(floor((tt-maxAR)/(2^(JMAX)))-1))
    KMAX = M

#     horizon_forecast_Jcomp_tvp= zeros(fcast_length);
#     Error_Jcomp_tvp=zeros(fcast_length);
#     errs0_last=zeros(fcast_length);
#     forecasted_constant=zeros(fcast_length);
#     variance_scales=zeros(fcast_length,JMAX);
#     first_forecasted_beta_scales=zeros(fcast_length,JMAX);
#     vv =zeros(JMAX);

#     for ii=0:(fcast_length-1)
        est_sample_tvp = r[(fcast_length+horizon - ii): (fcast_length+tt+horizon-1-ii)]
        
        # new trend estimation
        x=ones(length(est_sample_tvp))
        R"aa <- tvOLS(as.matrix($x),$est_sample_tvp, bw = $kernel_width_for_const)$coefficients"
        tvp_const=convert(Array{Float64},R"aa")
        errs0=est_sample_tvp.-tvp_const
    
        
        (truncR,Rmat)=ARlags(errs0, maxAR);
        (alphaR_tvp,Eps_tvp) = IRFalpha_tvp_LLS(truncR,Rmat,maxAR,M,kernel_width_IRF)


        # Estimate the decomposition
        betaRj_tvp=[]
        rj_tvp=[]
        for j in 1:JMAX
            (betaR, _ , r0, _ , _)=IRFscale(tt,maxAR,alphaR_tvp,Eps_tvp,KMAX,j);
            push!(betaRj_tvp,betaR)
            push!(rj_tvp,r0)
        end

        
        ################# Estimate coefficients of regression model ################
        b_Jcomp_tvp=OLSestimator(est_sample_tvp[1:length(rj_tvp[JMAX])],[tvp_const[1:length(rj_tvp[JMAX])] hcat(rj_tvp...)])
   
        forecasts_ar =[]
        for_ar=[]
        rev=vec(reverse(tvp_const));

        ############# Forecast tvp_const that does not enter EWD ...############
        R"forecasts_ar<- tvReg::forecast(tvAR($rev,p=$AR_lag_forecast,bw = $kernel_width_forecast),n.ahead=$horizon)" 
    
        for_ar=convert(Array{Float64},R"forecasts_ar")  
        for_const = mean(for_ar)
    
        
        ######################## EWD FORECAST #####################
        
        # We forecast the sum horizon-step ahead 
        betaFj_tvp=[]
        rfj_tvp=[]
        for j in 1:JMAX
            (betaF,rf)=IRFforecast_horizon(tt,maxAR,alphaR_tvp,Eps_tvp,KMAX,j,horizon);
            push!(betaFj_tvp,betaF)
            push!(rfj_tvp,rf)
        end
    
        ######### forecasted constant x EWD forecast ##############
    
        RFmat_Jcomp_tvp=[for_const.*ones(size(hcat(rfj_tvp...))[1]) hcat(rfj_tvp...)]; # with const pred
        
        horizon_forecast_Jcomp_tvp=(horizon^(-1).*RFmat_Jcomp_tvp[1,:])'*[horizon*b_Jcomp_tvp[1]; b_Jcomp_tvp[2:end]];
        
        # error with J components
        Error_Jcomp_tvp=horizon_forecast_Jcomp_tvp-RVh[fcast_length-ii]

#     end
    return [horizon_forecast_Jcomp_tvp;Error_Jcomp_tvp]
end

